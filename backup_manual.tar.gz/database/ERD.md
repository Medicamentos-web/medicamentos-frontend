# Modelo de Datos (ERD) - Gestión de Medicamentos Multifamiliar

## Diagrama relacional (multi-tenant)

```
                    ┌─────────────┐
                    │   users     │
                    ├─────────────┤
                    │ id (PK)     │
                    │ email       │
                    │ password_   │
                    │   hash      │
                    │ name        │
                    │ created_at  │
                    │ updated_at  │
                    └──────┬──────┘
                           │
                           │ 1
                           │
                    ┌──────┴──────┐
                    │             │ N
              ┌─────┴─────┐ ┌─────┴─────────────┐
              │  families │ │  family_members   │
              ├───────────┤ ├───────────────────┤
              │ id (PK)   │◄│ family_id (FK)    │
              │ name      │ │ user_id (FK)      │
              │ invite_   │ │ role              │
              │   code    │ │ joined_at         │
              │ created_  │ └─────────┬─────────┘
              │   by(FK)  │           │
              │ created_at│           │ 1
              │ updated_at│          │
              └─────┬─────┘          │
                    │                │ N
                    │ 1              │
         ┌──────────┴────────┐       │
         │                   │       │
    ┌────┴────┐        ┌─────┴───────┴─────┐
    │medicines│        │  dose_schedules   │
    ├─────────┤        ├───────────────────┤
    │ id (PK) │◄───────│ medicine_id (FK)  │
    │ family_ │        │ family_member_id  │
    │   id(FK)│        │   (FK)            │
    │ name    │        │ time_of_day       │
    │ stock   │        │ days_of_week      │
    │ unit    │        │ notes             │
    │ expiry_ │        │ active            │
    │   date  │        │ created_at        │
    │ created_│        │ updated_at        │
    │   at    │        └───────────────────┘
    │ updated_│
    │   at    │
    └─────────┘
```

## Tablas

| Tabla           | Descripción |
|-----------------|-------------|
| `users`         | Usuarios del sistema (auth). Un usuario puede pertenecer a varias familias. |
| `families`      | Familias (tenants). Cada familia tiene su propio inventario y miembros. |
| `family_members`| Relación N:M entre users y families, con rol (owner, admin, member). |
| `medicines`     | Inventario de medicamentos por familia (family_id). |
| `dose_schedules`| Calendario de tomas: qué miembro toma qué medicina y cuándo. |

## Índices para escalabilidad

- `families(invite_code)` UNIQUE
- `family_members(family_id)`, `family_members(user_id)`
- `medicines(family_id)`, `medicines(family_id, expiry_date)`
- `dose_schedules(family_id)`, `dose_schedules(family_member_id)`
