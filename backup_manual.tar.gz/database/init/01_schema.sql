-- Esquema inicial: Gestión de Medicamentos Multifamiliar (Multi-tenant)
-- Ejecutado automáticamente al primer arranque del contenedor (carpeta init)

-- =============================================================================
-- FAMILIAS (tenant root)
-- =============================================================================
CREATE TABLE families (
  id         SERIAL PRIMARY KEY,
  name       VARCHAR(255) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =============================================================================
-- USUARIOS (pertenecen a una familia)
-- =============================================================================
CREATE TABLE users (
  id         SERIAL PRIMARY KEY,
  family_id  INTEGER NOT NULL REFERENCES families(id) ON DELETE CASCADE,
  name       VARCHAR(255) NOT NULL,
  first_name VARCHAR(120),
  last_name  VARCHAR(120),
  birth_date DATE,
  street     VARCHAR(255),
  house_number VARCHAR(32),
  postal_code VARCHAR(32),
  city       VARCHAR(120),
  email      VARCHAR(255) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role       VARCHAR(20) NOT NULL DEFAULT 'user' CHECK (role IN ('admin', 'superuser', 'user')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (family_id, email)
);

CREATE INDEX idx_users_family_id ON users(family_id);

-- =============================================================================
-- MEDICO DE CABECERA (solo información)
-- =============================================================================
CREATE TABLE family_doctors (
  id         SERIAL PRIMARY KEY,
  family_id  INTEGER NOT NULL REFERENCES families(id) ON DELETE CASCADE,
  first_name VARCHAR(120) NOT NULL,
  last_name  VARCHAR(120) NOT NULL,
  email      VARCHAR(255),
  street     VARCHAR(255),
  house_number VARCHAR(32),
  postal_code VARCHAR(32),
  city       VARCHAR(120),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_family_doctors_family_id ON family_doctors(family_id);

-- =============================================================================
-- MEDICAMENTOS (inventario por familia)
-- =============================================================================
CREATE TABLE medicines (
  id              SERIAL PRIMARY KEY,
  family_id       INTEGER NOT NULL REFERENCES families(id) ON DELETE CASCADE,
  name            VARCHAR(255) NOT NULL,
  dosage          VARCHAR(100) NOT NULL,
  current_stock   INTEGER NOT NULL DEFAULT 0 CHECK (current_stock >= 0),
  expiration_date DATE,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_medicines_family_id ON medicines(family_id);

-- =============================================================================
-- SCHEDULES (programación de tomas)
-- =============================================================================
CREATE TABLE schedules (
  id         SERIAL PRIMARY KEY,
  medicine_id INTEGER NOT NULL REFERENCES medicines(id) ON DELETE CASCADE,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  dose_time  TIME NOT NULL,
  frequency  VARCHAR(50) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_schedules_medicine_id ON schedules(medicine_id);
CREATE INDEX idx_schedules_user_id ON schedules(user_id);

-- =============================================================================
-- REGISTRO DE TOMAS
-- =============================================================================
CREATE TABLE dose_logs (
  id          SERIAL PRIMARY KEY,
  schedule_id INTEGER NOT NULL REFERENCES schedules(id) ON DELETE CASCADE,
  taken_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  status      VARCHAR(20) NOT NULL CHECK (status IN ('taken', 'missed'))
);

CREATE INDEX idx_dose_logs_schedule_id ON dose_logs(schedule_id);
