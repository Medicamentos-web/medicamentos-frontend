import DateTimePicker from "@react-native-community/datetimepicker";
import Constants from "expo-constants";
import * as Notifications from "expo-notifications";
import React, { useEffect, useMemo, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  Image,
  Animated,
  Easing,
  Platform,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Modal,
  Linking,
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import { CameraView, useCameraPermissions } from "expo-camera";
import * as ScreenOrientation from "expo-screen-orientation";
import * as ImageManipulator from "expo-image-manipulator";

const API_URL =
  Constants.expoConfig?.extra?.API_URL || "http://192.168.178.138:4000";
const DISPLAY_TIMEZONE = "Europe/Zurich";

const STRINGS: Record<string, Record<string, string>> = {
  es: {
    access_patient: "Acceso paciente",
    family_id: "Family ID",
    email: "Email",
    password: "Password",
    enter: "Entrar",
    enter_offline: "Entrar sin conexión",
    residents: "Residentes",
    alerts: "Alertas",
    view_alerts: "Ver alertas",
    view_less: "Ver menos",
    refresh_alerts: "Actualizar",
    sos: "SOS",
    doctor_contact: "Contacto médico",
    no_stock_alerts: "Sin alertas de stock",
    scan_med: "Escanear medicamento",
    scan_subtitle: "Toma una foto o sube desde la galería.",
    camera: "Cámara",
    gallery: "Galería",
    last_scan: "Ver último escaneo",
    blocks_title: "Bloques de tiempo",
    blocks_subtitle: "Resumen por horario",
    pending: "pendientes",
    total: "total",
    day_doses: "tomas",
    stock: "Stock",
    confirm: "Confirmar",
    taken: "Tomado ✅",
    update_dose: "Actualizar dosis",
    pending_change: "Cambio pendiente",
    upload: "Importar",
    close: "Cerrar",
    dose_update: "Actualizar dosis",
    new_dose: "Nueva dosis",
    effective_date: "Fecha efectiva (YYYY-MM-DD)",
    send_request: "Enviar solicitud",
    sending: "Enviando...",
    dose_request_sent: "Solicitud enviada. Quedó pendiente de revisión.",
    dose_request_error: "No se pudo enviar la solicitud.",
    dose_request_fill: "Completa la nueva dosis.",
    offline_mode: "Modo sin conexión. Mostrando última sincronización.",
    load_day: "Cargar",
    show_day: "Ver tomas del día",
    hide_day: "Ocultar tomas",
    date_prev: "◀",
    date_next: "▶",
    patient: "Paciente",
    logout: "Salir",
    new_patient: "Nuevo paciente",
    live_caption: "En directo, con tu paciente",
    forgot_password: "Olvide mi contraseña",
    reset_password: "Restablecer contraseña",
    reset_email: "Email de la cuenta",
    reset_token: "Token recibido por email",
    reset_new_password: "Nueva contraseña",
    send_code: "Enviar código",
    reset_submit: "Cambiar contraseña",
    reset_sent: "Si el email existe, enviamos el token.",
    reset_done: "Contraseña actualizada.",
    reset_error: "No se pudo completar.",
    reset_missing: "Completa todos los campos.",
  },
  "de-CH": {
    access_patient: "Patientenzugang",
    family_id: "Familien-ID",
    email: "E-Mail",
    password: "Passwort",
    enter: "Einloggen",
    enter_offline: "Offline anmelden",
    residents: "Bewohner",
    alerts: "Warnungen",
    view_alerts: "Warnungen anzeigen",
    view_less: "Weniger anzeigen",
    refresh_alerts: "Aktualisieren",
    sos: "SOS",
    doctor_contact: "Arztkontakt",
    no_stock_alerts: "Keine Lagerwarnungen",
    scan_med: "Medikament scannen",
    scan_subtitle: "Foto machen oder aus Galerie wählen.",
    camera: "Kamera",
    gallery: "Galerie",
    last_scan: "Letzten Scan ansehen",
    blocks_title: "Zeitblöcke",
    blocks_subtitle: "Zusammenfassung nach Uhrzeit",
    pending: "offen",
    total: "gesamt",
    day_doses: "Einnahmen",
    stock: "Bestand",
    confirm: "Bestätigen",
    taken: "Eingenommen ✅",
    update_dose: "Dosis ändern",
    pending_change: "Ausstehende Änderung",
    upload: "Importieren",
    close: "Schliessen",
    dose_update: "Dosis ändern",
    new_dose: "Neue Dosis",
    effective_date: "Gültig ab (YYYY-MM-DD)",
    send_request: "Anfrage senden",
    sending: "Senden...",
    dose_request_sent: "Anfrage gesendet. Wartet auf Prüfung.",
    dose_request_error: "Anfrage konnte nicht gesendet werden.",
    dose_request_fill: "Neue Dosis eingeben.",
    offline_mode: "Offline-Modus. Letzte Synchronisierung.",
    load_day: "Laden",
    show_day: "Tagesplan anzeigen",
    hide_day: "Tagesplan ausblenden",
    date_prev: "◀",
    date_next: "▶",
    patient: "Patient",
    logout: "Abmelden",
    new_patient: "Neuer Patient",
    live_caption: "Live mit Ihrem Patienten",
    forgot_password: "Passwort vergessen",
    reset_password: "Passwort zurücksetzen",
    reset_email: "Konto-E-Mail",
    reset_token: "Token aus E-Mail",
    reset_new_password: "Neues Passwort",
    send_code: "Code senden",
    reset_submit: "Passwort ändern",
    reset_sent: "Wenn die E-Mail existiert, wurde der Token gesendet.",
    reset_done: "Passwort aktualisiert.",
    reset_error: "Konnte nicht abgeschlossen werden.",
    reset_missing: "Bitte alle Felder ausfüllen.",
  },
  en: {
    access_patient: "Patient access",
    family_id: "Family ID",
    email: "Email",
    password: "Password",
    enter: "Sign in",
    enter_offline: "Offline sign in",
    residents: "Residents",
    alerts: "Alerts",
    view_alerts: "View alerts",
    view_less: "View less",
    refresh_alerts: "Refresh",
    sos: "SOS",
    doctor_contact: "Doctor contact",
    no_stock_alerts: "No stock alerts",
    scan_med: "Scan medication",
    scan_subtitle: "Take a photo or choose from gallery.",
    camera: "Camera",
    gallery: "Gallery",
    last_scan: "View last scan",
    blocks_title: "Time blocks",
    blocks_subtitle: "Summary by time",
    pending: "pending",
    total: "total",
    day_doses: "doses",
    stock: "Stock",
    confirm: "Confirm",
    taken: "Taken ✅",
    update_dose: "Update dose",
    pending_change: "Pending change",
    upload: "Import",
    close: "Close",
    dose_update: "Update dose",
    new_dose: "New dose",
    effective_date: "Effective date (YYYY-MM-DD)",
    send_request: "Send request",
    sending: "Sending...",
    dose_request_sent: "Request sent. Pending review.",
    dose_request_error: "Could not send request.",
    dose_request_fill: "Fill in the new dose.",
    offline_mode: "Offline mode. Showing last sync.",
    load_day: "Load",
    show_day: "Show today's doses",
    hide_day: "Hide doses",
    date_prev: "◀",
    date_next: "▶",
    patient: "Patient",
    logout: "Logout",
    new_patient: "New patient",
    live_caption: "Live with your patient",
    forgot_password: "Forgot password",
    reset_password: "Reset password",
    reset_email: "Account email",
    reset_token: "Token from email",
    reset_new_password: "New password",
    send_code: "Send code",
    reset_submit: "Change password",
    reset_sent: "If the email exists, we sent a token.",
    reset_done: "Password updated.",
    reset_error: "Could not complete.",
    reset_missing: "Fill in all fields.",
  },
};

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

type MedItem = {
  id: number;
  nombre: string;
  dosis?: string;
  frecuencia?: string;
  hora: string;
  stock: number;
  completado: boolean;
  pending_dose?: boolean;
  requested_dosage?: string | null;
  effective_date?: string | null;
};

type AlertItem = {
  id: number;
  type: string;
  level: string;
  message: string;
  created_at: string;
  med_name?: string | null;
  med_dosage?: string | null;
  dose_time?: string | null;
  alert_date?: string | null;
  schedule_id?: number | null;
};

export default function HomeScreen() {
  const [familyId, setFamilyId] = useState("1");
  const [email, setEmail] = useState("ana.lopez@gmail.com");
  const [password, setPassword] = useState("");
  const [token, setToken] = useState("");
  const [userId, setUserId] = useState<number | null>(null);
  const [userName, setUserName] = useState("");
  const [cachedSession, setCachedSession] = useState<any>(null);
  const [language, setLanguage] = useState<"es" | "de-CH" | "en">("es");
  const [meds, setMeds] = useState<Record<string, MedItem[]>>({});
  const [error, setError] = useState("");
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [showMeds, setShowMeds] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);
  const [activeBlock, setActiveBlock] = useState<string | null>(null);
  const [showAlerts, setShowAlerts] = useState(false);
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [lastAlertId, setLastAlertId] = useState<number>(0);
  const [alertsLoading, setAlertsLoading] = useState(false);
  const [alertsUpdatedAt, setAlertsUpdatedAt] = useState<string>("");
  const [highlightScheduleId, setHighlightScheduleId] = useState<number | null>(null);
  const [pendingAlertId, setPendingAlertId] = useState<number | null>(null);
  const [stickyScheduleId, setStickyScheduleId] = useState<number | null>(null);
  const [stickyAlertId, setStickyAlertId] = useState<number | null>(null);
  const [lastNotifyAt, setLastNotifyAt] = useState(0);
  const [showSos, setShowSos] = useState(false);
  const [doctor, setDoctor] = useState<any>(null);
  const [sosMessage, setSosMessage] = useState("");
  const [isOffline, setIsOffline] = useState(false);
  const [lastSync, setLastSync] = useState<string>("");
  const [scanVisible, setScanVisible] = useState(false);
  const [scanUri, setScanUri] = useState<string | null>(null);
  const [scanUploading, setScanUploading] = useState(false);
  const [scanError, setScanError] = useState("");
  const [scanResult, setScanResult] = useState<any>(null);
  const [scanMode, setScanMode] = useState<"camera" | "preview">("preview");
  const [scanReady, setScanReady] = useState(false);
  const [cameraReady, setCameraReady] = useState(false);
  const [scanChecking, setScanChecking] = useState(false);
  const [scanStatus, setScanStatus] = useState("Alinea la etiqueta dentro del marco");
  const [frameInset, setFrameInset] = useState(22);
  const [frameDirection, setFrameDirection] = useState(1);
  const [scanAutoCaptured, setScanAutoCaptured] = useState(false);
  const [scanAutoImported, setScanAutoImported] = useState(false);
  const [scanDetectedText, setScanDetectedText] = useState("");
  const [scanDetectedFull, setScanDetectedFull] = useState("");
  const [orientationDegrees, setOrientationDegrees] = useState(0);
  const [cameraLayout, setCameraLayout] = useState({ width: 0, height: 0 });
  const [scanSkipNameCheck, setScanSkipNameCheck] = useState(false);
  const [scanDebugOcr, setScanDebugOcr] = useState(false);
  const [scanBirthDate, setScanBirthDate] = useState("");
  const [doseModalVisible, setDoseModalVisible] = useState(false);
  const [doseMed, setDoseMed] = useState<MedItem | null>(null);
  const [doseValue, setDoseValue] = useState("");
  const [doseDate, setDoseDate] = useState("");
  const [doseSubmitting, setDoseSubmitting] = useState(false);
  const [doseMessage, setDoseMessage] = useState("");
  const [resetVisible, setResetVisible] = useState(false);
  const [resetEmail, setResetEmail] = useState("");
  const [resetToken, setResetToken] = useState("");
  const [resetNewPassword, setResetNewPassword] = useState("");
  const [resetLoading, setResetLoading] = useState(false);
  const [resetMessage, setResetMessage] = useState("");
  const [permission, requestPermission] = useCameraPermissions();
  const cameraRef = React.useRef<any>(null);
  const pulseAnim = React.useRef(new Animated.Value(0)).current;

  const displayLocale = language === "de-CH" ? "de-CH" : language === "en" ? "en-US" : "es-ES";
  const t = (key: string) => STRINGS[language]?.[key] || STRINGS.es[key] || key;

  const dateLabel = selectedDate.toLocaleDateString(displayLocale, {
    weekday: "long",
    day: "2-digit",
    month: "short",
    timeZone: DISPLAY_TIMEZONE,
  });

  const headers = useMemo(
    () => ({
      "Content-Type": "application/json",
      Authorization: token ? `Bearer ${token}` : "",
    }),
    [token]
  );

  const formatDateKey = (value: Date) =>
    value.toLocaleDateString("en-CA", { timeZone: DISPLAY_TIMEZONE });

  const cacheKey = useMemo(() => {
    const dateKey = formatDateKey(selectedDate);
    return `meds:${familyId}:${userId || "0"}:${dateKey}`;
  }, [familyId, userId, selectedDate]);

  const doctorKey = useMemo(() => {
    return `doctor:${familyId}:${userId || "0"}`;
  }, [familyId, userId]);

  useEffect(() => {
    AsyncStorage.getItem("session")
      .then((value) => {
        if (value) {
          setCachedSession(JSON.parse(value));
        }
      })
      .catch(() => null);
  }, []);

  useEffect(() => {
    AsyncStorage.getItem("lang")
      .then((value) => {
        if (value === "es" || value === "de-CH" || value === "en") {
          setLanguage(value);
        }
      })
      .catch(() => null);
  }, []);

  useEffect(() => {
    AsyncStorage.getItem("last_alert_id")
      .then((value) => {
        const parsed = Number(value || 0);
        if (Number.isFinite(parsed)) setLastAlertId(parsed);
      })
      .catch(() => null);
  }, []);

  const setLang = async (value: "es" | "de-CH" | "en") => {
    setLanguage(value);
    await AsyncStorage.setItem("lang", value);
  };

  const loadMeds = async () => {
    if (!userId || !token) return;
    setError("");
    const date = formatDateKey(selectedDate);
    try {
      const res = await fetch(
        `${API_URL}/api/meds-by-date?user_id=${userId}&family_id=${familyId}&date=${date}`,
        { headers }
      );
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "No se pudo cargar.");
        throw new Error("load-failed");
      }
      setIsOffline(false);
      const syncStamp = new Date().toISOString();
      setLastSync(syncStamp);
      await AsyncStorage.setItem(cacheKey, JSON.stringify({ data, syncStamp }));
      const groups: Record<string, MedItem[]> = {
        "Mañana": [],
        "Mediodía": [],
        "Tarde": [],
        "Noche": [],
      };
      data.forEach((med: any) => {
        const hour = parseInt(med.hora?.split(":")[0] || "0", 10);
        const item: MedItem = {
          id: med.id,
          nombre: med.nombre,
          dosis: med.dosis,
          frecuencia: med.frecuencia,
          hora: med.hora,
          stock: med.stock,
          completado: med.estado === "tomado",
          pending_dose: med.pending_dose,
          requested_dosage: med.requested_dosage,
          effective_date: med.effective_date,
        };
        if (hour >= 5 && hour < 12) groups["Mañana"].push(item);
        else if (hour >= 12 && hour < 16) groups["Mediodía"].push(item);
        else if (hour >= 16 && hour < 20) groups["Tarde"].push(item);
        else groups["Noche"].push(item);
      });
      setMeds(groups);
      return;
    } catch {
      const cached = await AsyncStorage.getItem(cacheKey);
      if (cached) {
        const parsed = JSON.parse(cached);
        const groups: Record<string, MedItem[]> = {
          "Mañana": [],
          "Mediodía": [],
          "Tarde": [],
          "Noche": [],
        };
        parsed.data.forEach((med: any) => {
          const hour = parseInt(med.hora?.split(":")[0] || "0", 10);
          const item: MedItem = {
            id: med.id,
            nombre: med.nombre,
            dosis: med.dosis,
            frecuencia: med.frecuencia,
            hora: med.hora,
            stock: med.stock,
            completado: med.estado === "tomado",
          pending_dose: med.pending_dose,
          requested_dosage: med.requested_dosage,
          effective_date: med.effective_date,
          };
          if (hour >= 5 && hour < 12) groups["Mañana"].push(item);
          else if (hour >= 12 && hour < 16) groups["Mediodía"].push(item);
          else if (hour >= 16 && hour < 20) groups["Tarde"].push(item);
          else groups["Noche"].push(item);
        });
        setMeds(groups);
        setLastSync(parsed.syncStamp || "");
        setIsOffline(true);
        setError("Sin conexión. Mostrando última sincronización.");
      }
      return;
    }
  };

  const loadAlerts = async () => {
    if (!userId || !token) return;
    setAlertsLoading(true);
    try {
      const res = await fetch(
        `${API_URL}/api/alerts?family_id=${familyId}`,
        { headers }
      );
      const data = await res.json();
      if (res.ok) {
        const list = Array.isArray(data) ? data : [];
        setAlerts(list);
        setAlertsUpdatedAt(new Date().toISOString());
        if (list.length) {
          const firstDue = list.find((a: any) => a.type === "dose_due" && a.schedule_id);
          if (firstDue?.schedule_id) {
            setStickyScheduleId(Number(firstDue.schedule_id));
            setStickyAlertId(Number(firstDue.id));
          }
          const newest = Math.max(...list.map((a) => Number(a.id || 0)));
          if (newest > lastAlertId) {
            const top = list[0];
            const dose = top.med_dosage ? ` · ${top.med_dosage}` : "";
            const time = top.dose_time ? ` · ${top.dose_time}` : "";
            const date = top.alert_date ? ` · ${top.alert_date}` : "";
            Notifications.scheduleNotificationAsync({
              content: {
                title: "Alerta de medicación",
                body: `${top.med_name || "Medicamento"}${dose}${time}${date}`,
                data: { schedule_id: top.schedule_id, alert_id: top.id },
              },
              trigger: null,
            }).catch(() => null);
            setLastAlertId(newest);
            await AsyncStorage.setItem("last_alert_id", String(newest));
          }
        }
      }
    } catch {
      // sin conexión: no actualiza
    } finally {
      setAlertsLoading(false);
    }
  };

  useEffect(() => {
    if (token && userId) {
      loadMeds();
      loadAlerts();
    }
  }, [token, userId, selectedDate]);

  useEffect(() => {
    if (!userId) return;
    AsyncStorage.getItem(cacheKey)
      .then((cached) => {
        if (!cached) return;
        const parsed = JSON.parse(cached);
        if (!parsed?.data) return;
        const groups: Record<string, MedItem[]> = {
          "Mañana": [],
          "Mediodía": [],
          "Tarde": [],
          "Noche": [],
        };
        parsed.data.forEach((med: any) => {
          const hour = parseInt(med.hora?.split(":")[0] || "0", 10);
          const item: MedItem = {
            id: med.id,
            nombre: med.nombre,
            dosis: med.dosis,
            frecuencia: med.frecuencia,
            hora: med.hora,
            stock: med.stock,
            completado: med.estado === "tomado",
          pending_dose: med.pending_dose,
          requested_dosage: med.requested_dosage,
          effective_date: med.effective_date,
          };
          if (hour >= 5 && hour < 12) groups["Mañana"].push(item);
          else if (hour >= 12 && hour < 16) groups["Mediodía"].push(item);
          else if (hour >= 16 && hour < 20) groups["Tarde"].push(item);
          else groups["Noche"].push(item);
        });
        setMeds(groups);
        setLastSync(parsed.syncStamp || "");
      })
      .catch(() => null);
  }, [cacheKey, userId]);

  useEffect(() => {
    if (!userId) return;
    AsyncStorage.getItem(doctorKey)
      .then((cached) => {
        if (!cached) return;
        setDoctor(JSON.parse(cached));
      })
      .catch(() => null);
  }, [doctorKey, userId]);

  useEffect(() => {
    const nameLine = userName ? userName : "Paciente";
    const dateLine = new Date().toLocaleDateString("es-ES");
    setSosMessage(
      `Estimado/a Dr./Dra.,\n\nLe escribo por una consulta relacionada con mi medicación actual. ¿Podemos coordinar una revisión?\n\nPaciente: ${nameLine}\nFecha: ${dateLine}\n`
    );
  }, [userName]);

  useEffect(() => {
    let mounted = true;
    Notifications.getPermissionsAsync()
      .then((status) => {
        if (status.status !== "granted") {
          return Notifications.requestPermissionsAsync();
        }
        return status;
      })
      .catch(() => null);
    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    const sub = Notifications.addNotificationResponseReceivedListener((response) => {
      const data = response?.notification?.request?.content?.data as any;
      if (data?.schedule_id) {
        focusMed(Number(data.schedule_id), data?.alert_id);
      } else {
        setShowAlerts(true);
      }
    });
    return () => sub.remove();
  }, [meds, activeBlock]);

  const weekDays = useMemo(() => {
    const base = new Date();
    base.setHours(0, 0, 0, 0);
    const start = new Date(base);
    start.setDate(base.getDate() - 3);
    return Array.from({ length: 7 }).map((_, idx) => {
      const date = new Date(start);
      date.setDate(start.getDate() + idx);
      return {
        key: formatDateKey(date),
        date,
        label: date.toLocaleDateString(displayLocale, {
          weekday: "short",
          timeZone: DISPLAY_TIMEZONE,
        }),
        day: date.getDate(),
      };
    });
  }, [selectedDate]);

  const blockSummary = useMemo(() => {
    const blocks = Object.entries(meds).map(([name, items]) => {
      const total = items.length;
      const pending = items.filter((item) => !item.completado).length;
      const color =
        name === "Mañana"
          ? "#38bdf8"
          : name === "Mediodía"
          ? "#f59e0b"
          : name === "Tarde"
          ? "#6366f1"
          : "#10b981";
      return { name, total, pending, color };
    });
    return blocks;
  }, [meds]);

  const activeItems = useMemo(() => {
    if (!activeBlock) return [];
    return meds[activeBlock] || [];
  }, [activeBlock, meds]);

  const loadDoctor = async () => {
    if (!userId || !token) return;
    try {
      const res = await fetch(
        `${API_URL}/api/doctor?family_id=${familyId}&user_id=${userId}`,
        { headers }
      );
      const data = await res.json();
      if (res.ok) {
        setDoctor(data);
        await AsyncStorage.setItem(doctorKey, JSON.stringify(data));
      } else {
        setDoctor(null);
      }
    } catch {
      const cached = await AsyncStorage.getItem(doctorKey);
      if (cached) {
        setDoctor(JSON.parse(cached));
      }
    }
  };

  const pendingDue = useMemo(() => {
    const now = new Date();
    const nowMinutes = now.getHours() * 60 + now.getMinutes();
    const items = Object.values(meds).flat();
    return items.filter((item) => {
      if (item.completado) return false;
      const [h, m] = item.hora.split(":").map((v) => parseInt(v, 10));
      const doseMinutes = (h || 0) * 60 + (m || 0);
      return doseMinutes <= nowMinutes;
    });
  }, [meds]);

  const pendingAny = useMemo(() => {
    const items = Object.values(meds).flat();
    return items.filter((item) => !item.completado);
  }, [meds]);

  useEffect(() => {
    if (pendingAny.length && !stickyScheduleId) {
      setStickyScheduleId(pendingAny[0].id);
    }
  }, [pendingAny, stickyScheduleId]);

  useEffect(() => {
    if (pendingDue.length && !stickyScheduleId) {
      setStickyScheduleId(pendingDue[0].id);
    }
  }, [pendingDue, stickyScheduleId]);

  const focusMed = (scheduleId: number, alertId?: number) => {
    const blocks = Object.entries(meds);
    for (const [blockName, items] of blocks) {
      if (items.some((item) => item.id === scheduleId)) {
        setActiveBlock(blockName);
        setShowMeds(true);
        setHighlightScheduleId(scheduleId);
        if (alertId) setPendingAlertId(alertId);
        return;
      }
    }
    setShowMeds(true);
    setHighlightScheduleId(scheduleId);
    if (alertId) setPendingAlertId(alertId);
  };

  useEffect(() => {
    if (!pendingDue.length) return;
    const now = Date.now();
    if (now - lastNotifyAt < 15 * 60 * 1000) return;
    const first = pendingDue[0];
    const dateLabelShort = formatDateKey(selectedDate);
    const doseInfo = first?.dosis ? ` · ${first.dosis}` : "";
    Notifications.scheduleNotificationAsync({
      content: {
        title: "Tomas pendientes",
        body: `${first?.nombre || "Medicamento"}${doseInfo} · ${first?.hora || "--:--"} · ${dateLabelShort}`,
        data: { schedule_id: first?.id, alert_id: null },
      },
      trigger: null,
    }).catch(() => null);
    setLastNotifyAt(now);
  }, [pendingDue, lastNotifyAt, selectedDate]);

  const lowStock = useMemo(() => {
    const items = Object.values(meds).flat();
    return items.filter((item) => item.stock <= 5);
  }, [meds]);

  const login = async () => {
    setError("");
    const res = await fetch(`${API_URL}/auth/login`, {
      method: "POST",
      headers,
      body: JSON.stringify({
        family_id: Number(familyId),
        email,
        password,
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error || "Login inválido.");
      return;
    }
    setToken(data.token);
    setUserId(data.user.id);
    setUserName(data.user.name || data.user.email || "");
    await AsyncStorage.setItem(
      "session",
      JSON.stringify({
        token: data.token,
        userId: data.user.id,
        userName: data.user.name || data.user.email || "",
        familyId,
        email,
      })
    );
  };

  const loginOffline = async () => {
    if (!cachedSession) {
      setError("No hay sesión guardada.");
      return;
    }
    setToken(cachedSession.token || "");
    setUserId(cachedSession.userId || null);
    setUserName(cachedSession.userName || "");
    setError(t("offline_mode"));
  };

  const toggleMed = async (med: MedItem) => {
    const newStatus = med.completado ? "pendiente" : "tomado";
    if (newStatus !== "tomado") {
      setError("No se permite deshacer la toma.");
      return;
    }
    const date = formatDateKey(selectedDate);
    const today = formatDateKey(new Date());
    if (date > today) {
      setError("No se pueden confirmar tomas futuras.");
      return;
    }
    const res = await fetch(`${API_URL}/api/meds-toggle`, {
      method: "POST",
      headers,
      body: JSON.stringify({
        schedule_id: med.id,
        status: newStatus,
        family_id: Number(familyId),
        date,
      }),
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error || "No se pudo confirmar.");
      return;
    }
    if (res.ok && pendingAlertId) {
      await fetch(`${API_URL}/api/alerts/read`, {
        method: "POST",
        headers,
        body: JSON.stringify({
          alert_id: pendingAlertId,
          family_id: Number(familyId),
        }),
      }).catch(() => null);
      setPendingAlertId(null);
    }
    if (res.ok && stickyScheduleId === med.id) {
      if (stickyAlertId) {
        await fetch(`${API_URL}/api/alerts/read`, {
          method: "POST",
          headers,
          body: JSON.stringify({
            alert_id: stickyAlertId,
            family_id: Number(familyId),
          }),
        }).catch(() => null);
      }
      setStickyScheduleId(null);
      setStickyAlertId(null);
    }
    await loadMeds();
  };

  const openDoseModal = (med: MedItem) => {
    setDoseMed(med);
    setDoseValue(med.dosis || "");
    setDoseDate(formatDateKey(new Date()));
    setDoseMessage("");
    setDoseModalVisible(true);
  };

  const submitDoseChange = async () => {
    if (!doseMed || !token || !doseValue.trim()) {
      setDoseMessage("Completa la nueva dosis.");
      return;
    }
    setDoseSubmitting(true);
    setDoseMessage("");
    try {
      const res = await fetch(`${API_URL}/api/dose-change-requests`, {
        method: "POST",
        headers,
        body: JSON.stringify({
          family_id: Number(familyId),
          schedule_id: doseMed.id,
          new_dosage: doseValue.trim(),
          effective_date: doseDate.trim(),
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setDoseMessage(data.error || t("dose_request_error"));
        return;
      }
      setDoseMessage(t("dose_request_sent"));
    } catch {
      setDoseMessage(t("dose_request_error"));
    } finally {
      setDoseSubmitting(false);
    }
  };

  const requestReset = async () => {
    if (!resetEmail.trim()) {
      setResetMessage(t("reset_missing"));
      return;
    }
    setResetLoading(true);
    setResetMessage("");
    try {
      const res = await fetch(`${API_URL}/auth/forgot`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ family_id: Number(familyId), email: resetEmail.trim() }),
      });
      await res.json().catch(() => ({}));
      setResetMessage(t("reset_sent"));
    } catch {
      setResetMessage(t("reset_error"));
    } finally {
      setResetLoading(false);
    }
  };

  const submitReset = async () => {
    if (!resetToken.trim() || !resetNewPassword.trim()) {
      setResetMessage(t("reset_missing"));
      return;
    }
    setResetLoading(true);
    setResetMessage("");
    try {
      const res = await fetch(`${API_URL}/auth/reset`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          token: resetToken.trim(),
          new_password: resetNewPassword.trim(),
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setResetMessage(data.error || t("reset_error"));
        return;
      }
      setResetMessage(t("reset_done"));
    } catch {
      setResetMessage(t("reset_error"));
    } finally {
      setResetLoading(false);
    }
  };

  const openScanModal = () => {
    setScanError("");
    setScanResult(null);
    setScanMode("preview");
    setScanAutoCaptured(false);
    setScanAutoImported(false);
    setScanDetectedText("");
    setScanDetectedFull("");
    setScanSkipNameCheck(false);
    setScanDebugOcr(false);
    setScanBirthDate("");
    setScanVisible(true);
  };

  const pickFromCamera = async () => {
    setScanError("");
    setScanResult(null);
    setScanMode("preview");
    setScanReady(false);
    setCameraReady(false);
    setScanStatus("Foto lista para importar");
    setFrameInset(22);
    setFrameDirection(1);
    setScanAutoCaptured(false);
    setScanAutoImported(false);
    setScanDetectedText("");
    setScanSkipNameCheck(false);
    setScanDetectedFull("");
    setScanDebugOcr(false);
    setScanBirthDate("");
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      setScanError("Permiso de cámara requerido.");
      setScanVisible(true);
      return;
    }
    const result = await ImagePicker.launchCameraAsync({
      quality: 0.9,
      allowsEditing: true,
    });
    if (!result.canceled && result.assets?.length) {
      setScanUri(result.assets[0].uri);
      setScanVisible(true);
    } else {
      setScanVisible(true);
    }
  };

  const pickFromLibrary = async () => {
    setScanError("");
    setScanResult(null);
    setScanMode("preview");
    setScanStatus("Alinea la etiqueta dentro del marco");
    setFrameInset(22);
    setFrameDirection(1);
    setScanAutoCaptured(false);
    setScanAutoImported(false);
    setScanDetectedText("");
    setScanSkipNameCheck(false);
    setScanDetectedFull("");
    setScanDebugOcr(false);
    setScanBirthDate("");
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) {
      setScanError("Permiso de galería requerido.");
      setScanVisible(true);
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      quality: 0.7,
      allowsEditing: true,
    });
    if (!result.canceled && result.assets?.length) {
      setScanUri(result.assets[0].uri);
      setScanVisible(true);
    }
  };

  useEffect(() => {
    if (scanMode !== "camera" || scanReady) {
      pulseAnim.setValue(0);
      return;
    }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 800,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 0,
          duration: 800,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [scanMode, scanReady, pulseAnim]);

  useEffect(() => {
    let subscription: ScreenOrientation.Subscription | null = null;
    const setFromOrientation = (orientation: ScreenOrientation.Orientation) => {
      if (
        orientation === ScreenOrientation.Orientation.LANDSCAPE_LEFT ||
        orientation === ScreenOrientation.Orientation.LANDSCAPE_RIGHT ||
        orientation === ScreenOrientation.Orientation.LANDSCAPE ||
        orientation === ScreenOrientation.Orientation.LANDSCAPE_UP
      ) {
        setOrientationDegrees(90);
      } else if (orientation === ScreenOrientation.Orientation.PORTRAIT_DOWN) {
        setOrientationDegrees(180);
      } else {
        setOrientationDegrees(0);
      }
    };
    ScreenOrientation.getOrientationAsync()
      .then(setFromOrientation)
      .catch(() => setOrientationDegrees(0));
    subscription = ScreenOrientation.addOrientationChangeListener((event) => {
      setFromOrientation(event.orientationInfo.orientation);
    });
    return () => {
      if (subscription) {
        ScreenOrientation.removeOrientationChangeListener(subscription);
      }
    };
  }, []);

  useEffect(() => {
    if (scanMode !== "camera" || !scanVisible || !cameraReady || !userId || !token) {
      return;
    }
    let active = true;
    const interval = setInterval(async () => {
      if (!active || scanChecking || scanUploading) return;
      setScanChecking(true);
      try {
        const photo = await captureFullForValidate();
        if (!photo?.uri) {
          setScanChecking(false);
          return;
        }
        const form = new FormData();
        form.append("family_id", String(familyId));
        form.append("user_id", String(userId));
        form.append("fast_ocr", "1");
        if (scanBirthDate) {
          form.append("birth_date", scanBirthDate);
        }
        form.append("file", {
          uri: photo.uri,
          name: "scan.jpg",
          type: "image/jpeg",
        } as any);
        const res = await fetch(`${API_URL}/api/import-scan-validate`, {
          method: "POST",
          headers: {
            Authorization: token ? `Bearer ${token}` : "",
          },
          body: form,
        });
        const data = await res.json().catch(() => ({}));
        if (res.ok && data.match) {
          setScanReady(true);
          setScanStatus("Listo para escanear");
          setFrameInset(18);
          setScanDetectedText("");
          setScanDetectedFull("");
        } else {
          setScanReady(false);
          setScanDetectedText(data.detected_text || "");
          setScanDetectedFull(data.detected_text_full || "");
          const minInset = 12;
          const maxInset = 36;
          setFrameInset((prev) => {
            let next = prev + frameDirection * 4;
            if (next <= minInset) {
              next = minInset;
              setFrameDirection(1);
            } else if (next >= maxInset) {
              next = maxInset;
              setFrameDirection(-1);
            }
            return next;
          });
          if (frameInset <= 16) setScanStatus("Aleja un poco el móvil");
          else if (frameInset >= 32) setScanStatus("Acerca el texto al marco");
          else setScanStatus("Alinea la etiqueta dentro del marco");
        }
      } catch {
        setScanReady(false);
        setScanStatus("Alinea la etiqueta dentro del marco");
        setScanDetectedText("");
        setScanDetectedFull("");
      } finally {
        setScanChecking(false);
      }
    }, 600);
    return () => {
      active = false;
      clearInterval(interval);
    };
  }, [scanMode, scanVisible, cameraReady, userId, token, familyId, scanChecking, scanUploading]);

  useEffect(() => {
    if (
      scanMode !== "camera" ||
      !scanReady ||
      !cameraReady ||
      scanAutoCaptured ||
      scanUploading
    ) {
      return;
    }
    (async () => {
      try {
        const photo = await captureAndCrop(0.95);
        if (photo?.uri) {
          setScanUri(photo.uri);
          setScanMode("preview");
          setScanReady(false);
          setScanAutoCaptured(true);
          setScanStatus("Foto lista para importar");
          setScanDetectedText("");
          setScanDetectedFull("");
        }
      } catch {
        setScanError("No se pudo capturar la foto.");
      }
    })();
  }, [scanMode, scanReady, cameraReady, scanAutoCaptured, scanUploading]);

  // En productivo no auto-importamos para evitar bloqueos

  const uploadScan = async () => {
    if (!scanUri || !userId || !token) {
      setScanError("Faltan datos para importar.");
      return;
    }
    setScanUploading(true);
    setScanError("");
    try {
      const processed = await ImageManipulator.manipulateAsync(
        scanUri,
        [{ resize: { width: 1000 } }],
        { compress: 0.6, format: ImageManipulator.SaveFormat.JPEG }
      );
      const form = new FormData();
      form.append("family_id", String(familyId));
      form.append("user_id", String(userId));
      form.append("fast_ocr", "1");
      if (scanBirthDate) {
        form.append("birth_date", scanBirthDate);
      }
      form.append("file", {
        uri: processed.uri,
        name: "scan.jpg",
        type: "image/jpeg",
      } as any);

      const tryUpload = async () => {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 120000);
        try {
          const res = await fetch(`${API_URL}/api/import-scan`, {
            method: "POST",
            headers: {
              Authorization: token ? `Bearer ${token}` : "",
            },
            body: form,
            signal: controller.signal,
          });
          const data = await res.json().catch(() => ({}));
          return { res, data };
        } finally {
          clearTimeout(timeout);
        }
      };

      let result = await tryUpload();
      if (!result.res.ok) {
        // reintento rápido una vez
        await new Promise((r) => setTimeout(r, 1000));
        result = await tryUpload();
      }

      if (!result.res.ok) {
        setScanError(result.data.error || "No se pudo importar.");
        if (result.data.detected_text) {
          setScanDetectedText(result.data.detected_text);
        }
        if (result.data.detected_text_full) {
          setScanDetectedFull(result.data.detected_text_full);
        }
      } else {
        setScanResult(result.data);
        if (result.data.detected_text_full) {
          setScanDetectedFull(result.data.detected_text_full);
        }
        await loadMeds();
      }
    } catch {
      setScanError("Tiempo de espera o error de red al importar.");
    } finally {
      setScanUploading(false);
    }
  };

  const captureAndCrop = async (quality = 0.85) => {
    const photo = await cameraRef.current?.takePictureAsync({ quality });
    if (!photo?.uri) return null;
    if (!cameraLayout.width || !cameraLayout.height) return photo;
    const scaleX = (photo.width || cameraLayout.width) / cameraLayout.width;
    const scaleY = (photo.height || cameraLayout.height) / cameraLayout.height;
    const cropInset = frameInset;
    const cropTop = cropInset;
    const cropLeft = cropInset;
    const cropWidth = cameraLayout.width - cropInset * 2;
    const cropHeight = cameraLayout.height - cropInset * 2 - 28;
    const crop = {
      originX: Math.max(0, Math.round(cropLeft * scaleX)),
      originY: Math.max(0, Math.round(cropTop * scaleY)),
      width: Math.max(1, Math.round(cropWidth * scaleX)),
      height: Math.max(1, Math.round(cropHeight * scaleY)),
    };
    try {
      const result = await ImageManipulator.manipulateAsync(
        photo.uri,
        [{ crop }, { resize: { width: 1400 } }],
        { compress: 0.92, format: ImageManipulator.SaveFormat.JPEG }
      );
      return { ...photo, uri: result.uri };
    } catch {
      return photo;
    }
  };

  const captureFullForValidate = async () => {
    const photo = await cameraRef.current?.takePictureAsync({ quality: 1 });
    if (!photo?.uri) return null;
    return photo;
  };

  if (!token) {
    return (
      <SafeAreaView style={styles.screen}>
        <View style={styles.card}>
          <Text style={styles.title}>{t("access_patient")}</Text>
          {error ? <Text style={styles.error}>{error}</Text> : null}
          <Text style={styles.label}>{t("family_id")}</Text>
          <TextInput style={styles.input} value={familyId} onChangeText={setFamilyId} />
          <Text style={styles.label}>{t("email")}</Text>
          <TextInput style={styles.input} value={email} onChangeText={setEmail} />
          <Text style={styles.label}>{t("password")}</Text>
          <TextInput
            style={styles.input}
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />
          <TouchableOpacity style={styles.button} onPress={login}>
            <Text style={styles.buttonText}>{t("enter")}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.linkButton}
            onPress={() => {
              setResetEmail(email);
              setResetMessage("");
              setResetVisible(true);
            }}
          >
            <Text style={styles.linkButtonText}>{t("forgot_password")}</Text>
          </TouchableOpacity>
          {cachedSession ? (
            <TouchableOpacity style={styles.buttonAlt} onPress={loginOffline}>
              <Text style={styles.buttonAltText}>{t("enter_offline")}</Text>
            </TouchableOpacity>
          ) : null}
          <View style={styles.langRow}>
            {(["de-CH", "es", "en"] as const).map((lng) => (
              <TouchableOpacity
                key={lng}
                style={[styles.langButton, language === lng && styles.langButtonActive]}
                onPress={() => setLang(lng)}
              >
                <Text style={[styles.langButtonText, language === lng && styles.langButtonTextActive]}>
                  {lng === "de-CH" ? "DE-CH" : lng.toUpperCase()}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.topBar}>
          <View>
            <Text style={styles.brand}>ELDERCARE_V2</Text>
            <Text style={styles.caption}>{t("live_caption")}</Text>
          </View>
          <View style={styles.topActions}>
            <Text style={styles.patientName}>
              {userName ? userName : t("patient")}
            </Text>
            <View style={styles.pillDark}>
              <Text style={styles.pillDarkText}>{t("new_patient")}</Text>
            </View>
            <TouchableOpacity
              style={styles.logoutButton}
              onPress={() => {
                setToken("");
                setUserId(null);
                setUserName("");
              }}
            >
              <Text style={styles.logoutText}>{t("logout")}</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.statusRow}>
          <View style={styles.statCard}>
            <Text style={styles.statLabel}>{t("residents")}</Text>
            <Text style={styles.statValue}>1</Text>
          </View>
          <TouchableOpacity
            style={[styles.statCard, styles.statCardDark]}
            onPress={() => setShowAlerts((prev) => !prev)}
          >
            <Text style={styles.statLabelDark}>{t("alerts")}</Text>
            <Text style={styles.statValueDark}>
              {showAlerts ? t("view_less") : t("view_alerts")}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.statCard, styles.statCardDark]}
            onPress={loadAlerts}
          >
            <Text style={styles.statLabelDark}>{t("refresh_alerts")}</Text>
            <Text style={styles.statValueDark}>
              {alertsLoading ? "..." : "Alertas"}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.statCard, styles.statCardSos]}
            onPress={async () => {
              await loadDoctor();
              setShowSos(true);
            }}
          >
            <Text style={styles.statLabelBlue}>SOS</Text>
            <Text style={styles.statValueBlue}>{t("doctor_contact")}</Text>
          </TouchableOpacity>
        </View>

        {showAlerts ? (
          <View style={styles.alertsCard}>
            {alertsUpdatedAt ? (
              <Text style={styles.alertUpdated}>
                Actualizado: {new Date(alertsUpdatedAt).toLocaleTimeString()}
              </Text>
            ) : null}
            {alerts.length ? (
              alerts.map((item) => (
                <View key={item.id} style={styles.alertRow}>
                  <Text style={styles.alertName}>
                    {item.med_name || item.message}
                    {item.med_dosage ? ` · ${item.med_dosage}` : ""}
                  </Text>
                  <Text style={styles.alertValue}>
                    {item.dose_time ? `${item.dose_time} · ` : ""}
                    {item.alert_date || ""}
                  </Text>
                </View>
              ))
            ) : (
              <Text style={styles.alertEmpty}>{t("no_stock_alerts")}</Text>
            )}
          </View>
        ) : null}

        <View style={styles.scanCard}>
          <Text style={styles.scanTitle}>{t("scan_med")}</Text>
          <Text style={styles.scanSubtitle}>
            {t("scan_subtitle")}
          </Text>
          <View style={styles.scanActions}>
            <TouchableOpacity style={styles.scanButton} onPress={pickFromCamera}>
              <Text style={styles.scanButtonText}>{t("camera")}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.scanButtonAlt} onPress={pickFromLibrary}>
              <Text style={styles.scanButtonTextAlt}>{t("gallery")}</Text>
            </TouchableOpacity>
          </View>
          <TouchableOpacity style={styles.scanLink} onPress={openScanModal}>
            <Text style={styles.scanLinkText}>{t("last_scan")}</Text>
          </TouchableOpacity>
        </View>

        <Modal visible={scanVisible} transparent animationType="slide">
          <View style={styles.modalOverlay}>
            <View style={styles.modalCard}>
              <Text style={styles.modalTitle}>
                {scanMode === "camera" ? "Alinear cámara" : "Importar desde escaneo"}
              </Text>
              {scanMode === "camera" ? (
                <View
                  style={styles.cameraWrap}
                  onLayout={(event) => {
                    const { width, height } = event.nativeEvent.layout;
                    if (width && height) setCameraLayout({ width, height });
                  }}
                >
                  <CameraView
                    ref={cameraRef}
                    style={styles.cameraView}
                    onCameraReady={() => setCameraReady(true)}
                  />
                  <View
                    style={[
                      styles.scanOverlay,
                      { transform: [{ rotate: `${orientationDegrees}deg` }] },
                    ]}
                  >
                    <View
                      style={[
                        styles.scanFrame,
                        {
                          top: frameInset,
                          left: frameInset,
                          right: frameInset,
                          bottom: frameInset + 28,
                        },
                        scanReady ? styles.scanFrameReady : styles.scanFrameAlert,
                      ]}
                    />
                    {!scanReady ? (
                      <Animated.View
                        style={[
                          styles.scanFramePulse,
                          {
                            top: frameInset,
                            left: frameInset,
                            right: frameInset,
                            bottom: frameInset + 28,
                          },
                          { opacity: pulseAnim },
                        ]}
                      />
                    ) : null}
                    <Text style={styles.scanHint}>
                      {scanStatus}
                    </Text>
                  </View>
                </View>
              ) : scanUri ? (
                <Image source={{ uri: scanUri }} style={styles.scanPreview} />
              ) : (
                <Text style={styles.modalText}>Sin imagen seleccionada.</Text>
              )}
              {scanError ? <Text style={styles.error}>{scanError}</Text> : null}
              {scanError ? (
                <View style={styles.scanBirthRow}>
                  <Text style={styles.scanBirthLabel}>Validar por fecha (YYYY-MM-DD)</Text>
                  <TextInput
                    style={styles.scanBirthInput}
                    placeholder="1971-10-24"
                    value={scanBirthDate}
                    onChangeText={setScanBirthDate}
                  />
                </View>
              ) : null}
              {/* Modo producción: sin toggles de test/debug */}
              {scanDetectedText ? (
                <View style={styles.scanDetectedBox}>
                  <Text style={styles.scanDetectedTitle}>Texto detectado</Text>
                  <Text style={styles.scanDetectedText}>{scanDetectedText}</Text>
                </View>
              ) : null}
              {scanDetectedFull ? (
                <View style={styles.scanDetectedBox}>
                  <Text style={styles.scanDetectedTitle}>OCR completo</Text>
                  <TextInput
                    style={styles.scanDetectedFull}
                    value={scanDetectedFull}
                    editable={false}
                    multiline
                  />
                </View>
              ) : null}
              {scanResult ? (
                <View style={styles.scanResultBox}>
                  <Text style={styles.scanResultText}>
                    {scanResult.action === "merged"
                      ? "Se actualizó el stock."
                      : "Medicamento creado."}
                  </Text>
                  <Text style={styles.modalText}>
                    {scanResult.extracted?.name} · {scanResult.extracted?.dosage}
                  </Text>
                </View>
              ) : null}
              {scanMode === "camera" ? (
                <View style={styles.modalActions}>
                  <TouchableOpacity
                    style={[
                      styles.modalActionButtonDark,
                      (!scanReady || !cameraReady) && { opacity: 0.6 },
                    ]}
                    onPress={async () => {
                      if (!scanReady || !cameraReady) return;
                      try {
                        const photo = await cameraRef.current?.takePictureAsync({
                          quality: 0.7,
                        });
                        if (photo?.uri) {
                          setScanUri(photo.uri);
                          setScanMode("preview");
                          setScanReady(false);
                        }
                      } catch {
                        setScanError("No se pudo capturar la foto.");
                      }
                    }}
                  >
                    <Text style={styles.modalActionTextDark}>
                      {scanReady ? "Capturar" : "Ajustando..."}
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.modalButton}
                    onPress={() => setScanVisible(false)}
                  >
                    <Text style={styles.modalButtonText}>Cancelar</Text>
                  </TouchableOpacity>
                </View>
              ) : (
                <View style={styles.modalActions}>
                  <TouchableOpacity
                    style={styles.modalActionButton}
                    onPress={uploadScan}
                    disabled={scanUploading}
                  >
                    <Text style={styles.modalActionText}>
                      {scanUploading ? "Subiendo..." : "Importar"}
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.modalActionButtonDark}
                    onPress={() => setScanVisible(false)}
                  >
                    <Text style={styles.modalActionTextDark}>Cerrar</Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          </View>
        </Modal>

        <Modal visible={doseModalVisible} transparent animationType="slide">
          <View style={styles.modalOverlay}>
            <View style={styles.modalCard}>
              <Text style={styles.modalTitle}>{t("dose_update")}</Text>
              <Text style={styles.modalText}>
                {doseMed ? doseMed.nombre : "Medicamento"} {doseMed?.dosis ? `· ${doseMed.dosis}` : ""}
              </Text>
              <Text style={styles.modalLabel}>{t("new_dose")}</Text>
              <TextInput
                style={styles.modalInput}
                placeholder="Ej: 60 mg"
                value={doseValue}
                onChangeText={setDoseValue}
              />
              <Text style={styles.modalLabel}>{t("effective_date")}</Text>
              <TextInput
                style={styles.modalInput}
                placeholder="2026-02-02"
                value={doseDate}
                onChangeText={setDoseDate}
              />
              {doseMessage ? <Text style={styles.modalText}>{doseMessage}</Text> : null}
              <View style={styles.modalActions}>
                <TouchableOpacity
                  style={styles.modalActionButton}
                  onPress={submitDoseChange}
                  disabled={doseSubmitting}
                >
                  <Text style={styles.modalActionText}>
                    {doseSubmitting ? t("sending") : t("send_request")}
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.modalActionButtonDark}
                  onPress={() => setDoseModalVisible(false)}
                >
                  <Text style={styles.modalActionTextDark}>{t("close")}</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>

        <Modal visible={resetVisible} transparent animationType="slide">
          <View style={styles.modalOverlay}>
            <View style={styles.modalCard}>
              <Text style={styles.modalTitle}>{t("reset_password")}</Text>
              <Text style={styles.modalLabel}>{t("reset_email")}</Text>
              <TextInput
                style={styles.modalInput}
                placeholder="name@email.com"
                value={resetEmail}
                onChangeText={setResetEmail}
                autoCapitalize="none"
              />
              <TouchableOpacity
                style={styles.modalActionButton}
                onPress={requestReset}
                disabled={resetLoading}
              >
                <Text style={styles.modalActionText}>
                  {resetLoading ? t("sending") : t("send_code")}
                </Text>
              </TouchableOpacity>
              <Text style={styles.modalLabel}>{t("reset_token")}</Text>
              <TextInput
                style={styles.modalInput}
                placeholder="token"
                value={resetToken}
                onChangeText={setResetToken}
                autoCapitalize="none"
              />
              <Text style={styles.modalLabel}>{t("reset_new_password")}</Text>
              <TextInput
                style={styles.modalInput}
                placeholder="********"
                value={resetNewPassword}
                onChangeText={setResetNewPassword}
                secureTextEntry
              />
              {resetMessage ? <Text style={styles.modalText}>{resetMessage}</Text> : null}
              <View style={styles.modalActions}>
                <TouchableOpacity
                  style={styles.modalActionButton}
                  onPress={submitReset}
                  disabled={resetLoading}
                >
                  <Text style={styles.modalActionText}>
                    {resetLoading ? t("sending") : t("reset_submit")}
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.modalActionButtonDark}
                  onPress={() => setResetVisible(false)}
                >
                  <Text style={styles.modalActionTextDark}>{t("close")}</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>

        <Modal visible={showSos} transparent animationType="slide">
          <View style={styles.modalOverlay}>
            <View style={styles.modalCard}>
              <Text style={styles.modalTitle}>Médico de cabecera</Text>
              {doctor ? (
                <>
                  <Text style={styles.modalText}>
                    {doctor.first_name} {doctor.last_name}
                  </Text>
                  <Text style={styles.modalText}>
                    {doctor.street} {doctor.house_number}
                  </Text>
                  <Text style={styles.modalText}>
                    {doctor.postal_code} {doctor.city}
                  </Text>
                  <Text style={styles.modalText}>Email: {doctor.email || "-"}</Text>
                  <Text style={styles.modalText}>Tel: {doctor.phone || "-"}</Text>
                  <Text style={styles.modalLabel}>Mensaje para el médico</Text>
                  <TextInput
                    style={styles.modalInput}
                    multiline
                    value={sosMessage}
                    onChangeText={setSosMessage}
                  />
                  <View style={styles.modalActions}>
                    <TouchableOpacity
                      style={styles.modalActionButton}
                      onPress={() => {
                        if (!doctor.phone) return;
                        Linking.openURL(`tel:${doctor.phone}`);
                      }}
                    >
                      <Text style={styles.modalActionText}>Llamar</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={styles.modalActionButtonDark}
                      onPress={() => {
                        if (!doctor.email) return;
                        const subject = encodeURIComponent("Consulta médica");
                        const body = encodeURIComponent(sosMessage);
                        Linking.openURL(`mailto:${doctor.email}?subject=${subject}&body=${body}`);
                      }}
                    >
                      <Text style={styles.modalActionTextDark}>Enviar email</Text>
                    </TouchableOpacity>
                  </View>
                </>
              ) : (
                <Text style={styles.modalText}>Sin datos de médico.</Text>
              )}
              <TouchableOpacity
                style={styles.modalButton}
                onPress={() => setShowSos(false)}
              >
                <Text style={styles.modalButtonText}>Cerrar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Dashboard</Text>
          <Text style={styles.sectionSubtitle}>
            Vista general · {dateLabel}
          </Text>
        </View>
        {isOffline ? (
          <View style={styles.offlineBanner}>
            <Text style={styles.offlineText}>Sin conexión</Text>
            <Text style={styles.offlineSub}>
              Última sincronización: {lastSync ? new Date(lastSync).toLocaleString("es-ES") : "N/A"}
            </Text>
          </View>
        ) : null}
        {(stickyScheduleId || pendingAny.length) ? (
          <View style={styles.dueBanner}>
            <Text style={styles.dueText}>
              Tienes {pendingAny.length} toma(s) pendientes.
            </Text>
            <TouchableOpacity
              style={styles.dueButton}
              onPress={() =>
                focusMed(
                  Number(stickyScheduleId || pendingAny[0].id),
                  stickyAlertId || undefined
                )
              }
            >
              <Text style={styles.dueButtonText}>Confirmar ahora</Text>
            </TouchableOpacity>
          </View>
        ) : null}

        <View style={styles.calendarRow}>
          <Text style={styles.calendarTitle}>Calendario</Text>
          <TouchableOpacity
            style={styles.calendarButton}
            onPress={() => setShowCalendar((prev) => !prev)}
          >
            <Text style={styles.calendarButtonText}>
              {showCalendar ? "Ocultar" : "Abrir"}
            </Text>
          </TouchableOpacity>
        </View>

        {showCalendar ? (
          <View style={styles.calendarPicker}>
            <DateTimePicker
              value={selectedDate}
              mode="date"
              display={Platform.OS === "ios" ? "inline" : "default"}
              onChange={(_, date) => {
                if (date) setSelectedDate(date);
                if (Platform.OS !== "ios") setShowCalendar(false);
              }}
            />
          </View>
        ) : null}

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.weekRow}
        >
          {weekDays.map((item) => {
            const isActive =
              item.date.toDateString() === selectedDate.toDateString();
            const isToday = item.date.toDateString() === new Date().toDateString();
            return (
              <TouchableOpacity
                key={item.key}
                style={[
                  styles.dayPill,
                  isActive && styles.dayPillActive,
                  isToday && styles.dayPillToday,
                ]}
                onPress={() => setSelectedDate(item.date)}
              >
                <Text
                  style={[
                    styles.dayLabel,
                    isActive && styles.dayLabelActive,
                    isToday && styles.dayLabelToday,
                  ]}
                >
                  {item.label}
                </Text>
                <Text
                  style={[
                    styles.dayNumber,
                    isActive && styles.dayNumberActive,
                    isToday && styles.dayNumberToday,
                  ]}
                >
                  {item.day}
                </Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>{t("blocks_title")}</Text>
          <Text style={styles.sectionSubtitle}>
            {t("blocks_subtitle")}
          </Text>
        </View>

        <View style={styles.blockGrid}>
          {blockSummary.map((block) => (
            <TouchableOpacity
              key={block.name}
              style={[
                styles.blockCard,
                activeBlock === block.name && styles.blockCardActive,
              ]}
              onPress={() =>
                setActiveBlock((prev) => (prev === block.name ? null : block.name))
              }
            >
              <View style={[styles.blockDot, { backgroundColor: block.color }]} />
              <Text style={styles.blockName}>{block.name}</Text>
              <Text style={styles.blockMeta}>
                {block.pending} {t("pending")} · {block.total} {t("total")}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {activeBlock ? (
          <View style={styles.blockList}>
            <Text style={styles.blockListTitle}>
              {activeBlock} · {activeItems.length} {t("day_doses")}
            </Text>
            {activeItems.map((med) => (
                <TouchableOpacity
                  key={med.id}
                  style={[
                    styles.medCard,
                    med.completado && styles.medCardDone,
                    highlightScheduleId === med.id && styles.medCardHighlight,
                  ]}
                  onPress={() => toggleMed(med)}
                >
                  <Text style={styles.medName}>
                    {med.nombre} {med.dosis ? `· ${med.dosis}` : ""}
                  </Text>
                  <View style={styles.medMetaRow}>
                    <Text style={styles.medInfo}>
                      {med.hora} · Dosis {med.frecuencia || "1"}
                    </Text>
                    <Text
                      style={[
                        styles.medStock,
                        med.stock <= 10 && styles.medStockLow,
                      ]}
                    >
                      Stock {med.stock}
                    </Text>
                  </View>
                  {med.pending_dose ? (
                    <Text style={styles.medPending}>
                      Cambio pendiente: {med.requested_dosage || "N/A"}
                      {med.effective_date ? ` · ${med.effective_date}` : ""}
                    </Text>
                  ) : null}
                  <TouchableOpacity
                    style={styles.medDoseLink}
                    onPress={() => openDoseModal(med)}
                  >
                    <Text style={styles.medDoseLinkText}>Actualizar dosis</Text>
                  </TouchableOpacity>
                <View
                  style={[
                    styles.medButton,
                    med.completado && styles.medButtonDone,
                  ]}
                >
                  <Text style={styles.medButtonText}>
                    {med.completado ? "Tomado ✅" : "Confirmar"}
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        ) : null}

        <TouchableOpacity
          style={styles.toggleButton}
          onPress={() => setShowMeds((prev) => !prev)}
        >
          <Text style={styles.toggleButtonText}>
            {showMeds ? t("hide_day") : t("show_day")}
          </Text>
        </TouchableOpacity>

        {showMeds ? (
          <>
            <View style={styles.dateRow}>
              <TouchableOpacity
                style={styles.dateButton}
                onPress={() =>
                  setSelectedDate(new Date(selectedDate.getTime() - 86400000))
                }
              >
            <Text style={styles.dateButtonText}>{t("date_prev")}</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.dateButtonPrimary}
                onPress={loadMeds}
              >
            <Text style={styles.dateButtonPrimaryText}>{t("load_day")}</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.dateButton}
                onPress={() =>
                  setSelectedDate(new Date(selectedDate.getTime() + 86400000))
                }
              >
            <Text style={styles.dateButtonText}>{t("date_next")}</Text>
              </TouchableOpacity>
            </View>

            {Object.entries(meds).map(([block, items]) =>
              items.length ? (
                <View key={block} style={styles.block}>
                  <Text style={styles.blockTitle}>
                    {block} · {items.length} tomas
                  </Text>
                  {items.map((med) => (
              <TouchableOpacity
                key={med.id}
                style={[
                  styles.medCard,
                  med.completado && styles.medCardDone,
                  highlightScheduleId === med.id && styles.medCardHighlight,
                ]}
                onPress={() => toggleMed(med)}
              >
                <Text style={styles.medName}>
                  {med.nombre} {med.dosis ? `· ${med.dosis}` : ""}
                </Text>
                <View style={styles.medMetaRow}>
                  <Text style={styles.medInfo}>
                    {med.hora} · Dosis {med.frecuencia || "1"}
                  </Text>
                  <Text
                    style={[
                      styles.medStock,
                      med.stock <= 10 && styles.medStockLow,
                    ]}
                  >
                      {t("stock")} {med.stock}
                  </Text>
                </View>
                {med.pending_dose ? (
                  <Text style={styles.medPending}>
                      {t("pending_change")}: {med.requested_dosage || "N/A"}
                    {med.effective_date ? ` · ${med.effective_date}` : ""}
                  </Text>
                ) : null}
                <TouchableOpacity
                  style={styles.medDoseLink}
                  onPress={() => openDoseModal(med)}
                >
                    <Text style={styles.medDoseLinkText}>{t("update_dose")}</Text>
                </TouchableOpacity>
                      <View
                        style={[
                          styles.medButton,
                          med.completado && styles.medButtonDone,
                        ]}
                      >
                        <Text style={styles.medButtonText}>
                    {med.completado ? t("taken") : t("confirm")}
                        </Text>
                      </View>
                    </TouchableOpacity>
                  ))}
                </View>
              ) : null
            )}
          </>
        ) : null}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: "#F2F4F8",
  },
  container: {
    padding: 20,
    paddingBottom: 40,
  },
  card: {
    backgroundColor: "#fff",
    margin: 24,
    padding: 24,
    borderRadius: 24,
  },
  title: {
    fontSize: 20,
    fontWeight: "800",
  },
  label: {
    marginTop: 12,
    fontSize: 12,
    color: "#64748b",
    textTransform: "uppercase",
    letterSpacing: 1,
  },
  input: {
    borderWidth: 1,
    borderColor: "#e2e8f0",
    borderRadius: 16,
    padding: 12,
    marginTop: 6,
  },
  button: {
    marginTop: 18,
    backgroundColor: "#007AFF",
    padding: 14,
    borderRadius: 18,
    alignItems: "center",
  },
  buttonAlt: {
    marginTop: 10,
    backgroundColor: "#e2e8f0",
    padding: 12,
    borderRadius: 18,
    alignItems: "center",
  },
  buttonText: {
    color: "#fff",
    fontWeight: "800",
    textTransform: "uppercase",
  },
  buttonAltText: {
    color: "#0f172a",
    fontWeight: "700",
    textTransform: "uppercase",
  },
  linkButton: {
    marginTop: 10,
    alignSelf: "center",
  },
  linkButtonText: {
    color: "#2563eb",
    fontSize: 13,
    fontWeight: "600",
  },
  langRow: {
    marginTop: 14,
    flexDirection: "row",
    gap: 8,
  },
  langButton: {
    backgroundColor: "#f1f5f9",
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 10,
  },
  langButtonActive: {
    backgroundColor: "#0f172a",
  },
  langButtonText: {
    color: "#0f172a",
    fontSize: 11,
    fontWeight: "700",
  },
  langButtonTextActive: {
    color: "#fff",
  },
  error: {
    color: "#ef4444",
    marginTop: 8,
  },
  topBar: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  brand: {
    fontSize: 18,
    fontWeight: "800",
    color: "#111827",
  },
  caption: {
    color: "#9ca3af",
    marginTop: 4,
  },
  topActions: {
    alignItems: "flex-end",
  },
  patientName: {
    color: "#111827",
    fontWeight: "700",
    fontSize: 12,
    marginBottom: 6,
  },
  pillDark: {
    backgroundColor: "#111827",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
  },
  pillDarkText: {
    color: "#fff",
    fontSize: 10,
    fontWeight: "700",
    textTransform: "uppercase",
  },
  logoutButton: {
    marginTop: 8,
    backgroundColor: "#ef4444",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
  },
  logoutText: {
    color: "#fff",
    fontSize: 10,
    fontWeight: "700",
    textTransform: "uppercase",
  },
  statusRow: {
    flexDirection: "row",
    gap: 12,
    marginTop: 18,
  },
  statCard: {
    flex: 1,
    backgroundColor: "#fff",
    borderRadius: 20,
    padding: 14,
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.08,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 6 },
    elevation: 3,
  },
  statCardDark: {
    backgroundColor: "#111827",
  },
  statCardBlue: {
    backgroundColor: "#2563eb",
  },
  statCardSos: {
    backgroundColor: "#facc15",
  },
  statLabel: {
    color: "#94a3b8",
    fontSize: 10,
    textTransform: "uppercase",
    fontWeight: "700",
  },
  statValue: {
    marginTop: 6,
    fontSize: 18,
    fontWeight: "800",
    color: "#111827",
  },
  statLabelDark: {
    color: "#93c5fd",
    fontSize: 10,
    textTransform: "uppercase",
    fontWeight: "700",
  },
  statValueDark: {
    marginTop: 6,
    fontSize: 12,
    fontWeight: "800",
    color: "#fff",
  },
  statLabelBlue: {
    color: "#0f172a",
    fontSize: 10,
    textTransform: "uppercase",
    fontWeight: "700",
  },
  statValueBlue: {
    marginTop: 6,
    fontSize: 12,
    fontWeight: "800",
    color: "#0f172a",
  },
  alertsCard: {
    marginTop: 12,
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 12,
  },
  scanCard: {
    marginTop: 12,
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 16,
  },
  scanTitle: {
    fontSize: 14,
    fontWeight: "800",
    color: "#111827",
  },
  scanSubtitle: {
    marginTop: 6,
    color: "#64748b",
  },
  scanActions: {
    flexDirection: "row",
    gap: 10,
    marginTop: 12,
  },
  scanButton: {
    flex: 1,
    backgroundColor: "#0ea5e9",
    paddingVertical: 10,
    borderRadius: 12,
    alignItems: "center",
  },
  scanButtonAlt: {
    flex: 1,
    backgroundColor: "#e2e8f0",
    paddingVertical: 10,
    borderRadius: 12,
    alignItems: "center",
  },
  scanButtonText: {
    fontWeight: "700",
    color: "#fff",
  },
  scanButtonTextAlt: {
    fontWeight: "700",
    color: "#0f172a",
  },
  scanLink: {
    marginTop: 10,
    alignSelf: "flex-start",
  },
  scanLinkText: {
    color: "#2563eb",
    fontWeight: "700",
  },
  scanPreview: {
    width: "100%",
    height: 200,
    borderRadius: 12,
    marginTop: 10,
  },
  cameraWrap: {
    marginTop: 10,
    borderRadius: 14,
    overflow: "hidden",
    position: "relative",
  },
  cameraView: {
    width: "100%",
    height: 260,
  },
  scanOverlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  scanFrame: {
    position: "absolute",
    borderWidth: 2,
    borderRadius: 12,
  },
  scanFrameAlert: {
    borderColor: "#ef4444",
  },
  scanFrameReady: {
    borderColor: "#22c55e",
  },
  scanFramePulse: {
    position: "absolute",
    borderWidth: 2,
    borderRadius: 12,
    borderColor: "#ef4444",
  },
  scanHint: {
    position: "absolute",
    bottom: 12,
    left: 0,
    right: 0,
    textAlign: "center",
    color: "#fff",
    fontWeight: "700",
    textShadowColor: "rgba(0,0,0,0.4)",
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 4,
  },
  scanResultBox: {
    marginTop: 10,
    backgroundColor: "#ecfdf5",
    borderRadius: 12,
    padding: 10,
  },
  scanDetectedBox: {
    marginTop: 10,
    backgroundColor: "#fff7ed",
    borderRadius: 12,
    padding: 10,
    borderWidth: 1,
    borderColor: "#fed7aa",
  },
  scanBirthRow: {
    marginTop: 10,
  },
  scanBirthLabel: {
    color: "#0f172a",
    fontWeight: "700",
  },
  scanBirthInput: {
    marginTop: 6,
    borderWidth: 1,
    borderColor: "#e2e8f0",
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  scanToggleRow: {
    marginTop: 10,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  scanToggleLabel: {
    color: "#0f172a",
    fontWeight: "700",
  },
  scanDetectedTitle: {
    fontWeight: "700",
    color: "#9a3412",
  },
  scanDetectedText: {
    marginTop: 6,
    color: "#7c2d12",
    fontSize: 12,
  },
  scanDetectedFull: {
    marginTop: 8,
    color: "#7c2d12",
    fontSize: 12,
    minHeight: 120,
    borderWidth: 1,
    borderColor: "#fed7aa",
    borderRadius: 10,
    padding: 8,
  },
  scanResultText: {
    color: "#047857",
    fontWeight: "700",
  },
  alertRow: {
    flexDirection: "column",
    gap: 4,
    marginBottom: 10,
  },
  alertName: {
    color: "#111827",
    fontWeight: "600",
    flexWrap: "wrap",
  },
  alertValue: {
    color: "#ef4444",
    fontWeight: "700",
    flexWrap: "wrap",
  },
  alertUpdated: {
    color: "#64748b",
    fontSize: 12,
    marginBottom: 6,
  },
  alertEmpty: {
    color: "#10b981",
    fontWeight: "700",
  },
  dueBanner: {
    marginTop: 12,
    backgroundColor: "#fff7ed",
    borderWidth: 1,
    borderColor: "#fdba74",
    borderRadius: 14,
    padding: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 8,
  },
  dueText: {
    color: "#9a3412",
    fontWeight: "700",
    flex: 1,
  },
  dueButton: {
    backgroundColor: "#f59e0b",
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 12,
  },
  dueButtonText: {
    color: "#fff",
    fontWeight: "700",
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(15, 23, 42, 0.6)",
    justifyContent: "center",
    padding: 24,
  },
  modalCard: {
    backgroundColor: "#fff",
    borderRadius: 20,
    padding: 20,
  },
  modalTitle: {
    fontSize: 16,
    fontWeight: "800",
    marginBottom: 8,
  },
  modalText: {
    color: "#334155",
    marginTop: 4,
  },
  modalLabel: {
    marginTop: 12,
    fontSize: 12,
    fontWeight: "700",
    color: "#64748b",
    textTransform: "uppercase",
  },
  modalInput: {
    marginTop: 6,
    borderWidth: 1,
    borderColor: "#e2e8f0",
    borderRadius: 12,
    padding: 10,
    minHeight: 90,
    textAlignVertical: "top",
  },
  modalActions: {
    marginTop: 12,
    flexDirection: "row",
    gap: 10,
  },
  modalActionButton: {
    flex: 1,
    backgroundColor: "#facc15",
    paddingVertical: 10,
    borderRadius: 12,
    alignItems: "center",
  },
  modalActionText: {
    fontWeight: "700",
    color: "#0f172a",
    textTransform: "uppercase",
  },
  modalActionButtonDark: {
    flex: 1,
    backgroundColor: "#111827",
    paddingVertical: 10,
    borderRadius: 12,
    alignItems: "center",
  },
  modalActionTextDark: {
    fontWeight: "700",
    color: "#fff",
    textTransform: "uppercase",
  },
  modalButton: {
    marginTop: 16,
    backgroundColor: "#111827",
    paddingVertical: 10,
    borderRadius: 14,
    alignItems: "center",
  },
  modalButtonText: {
    color: "#fff",
    fontWeight: "700",
    textTransform: "uppercase",
  },
  sectionHeader: {
    marginTop: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "800",
    color: "#111827",
  },
  sectionSubtitle: {
    color: "#64748b",
    marginTop: 4,
  },
  toggleButton: {
    marginTop: 16,
    backgroundColor: "#111827",
    paddingVertical: 12,
    borderRadius: 16,
    alignItems: "center",
  },
  toggleButtonText: {
    color: "#fff",
    fontWeight: "700",
    textTransform: "uppercase",
  },
  offlineBanner: {
    marginTop: 12,
    backgroundColor: "#fef3c7",
    borderRadius: 14,
    padding: 10,
  },
  offlineText: {
    fontWeight: "800",
    color: "#92400e",
  },
  offlineSub: {
    marginTop: 4,
    color: "#92400e",
    fontSize: 12,
  },
  calendarRow: {
    marginTop: 18,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  calendarTitle: {
    fontSize: 14,
    fontWeight: "700",
    color: "#111827",
  },
  calendarButton: {
    backgroundColor: "#e5e7eb",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  calendarButtonText: {
    fontSize: 12,
    fontWeight: "700",
    color: "#111827",
    textTransform: "uppercase",
  },
  calendarPicker: {
    marginTop: 12,
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 10,
  },
  weekRow: {
    gap: 10,
    marginTop: 12,
    paddingBottom: 4,
  },
  dayPill: {
    width: 64,
    paddingVertical: 10,
    borderRadius: 16,
    backgroundColor: "#fff",
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    elevation: 2,
  },
  dayPillActive: {
    backgroundColor: "#111827",
  },
  dayPillToday: {
    borderWidth: 2,
    borderColor: "#60a5fa",
  },
  dayLabel: {
    fontSize: 11,
    textTransform: "uppercase",
    color: "#9ca3af",
    fontWeight: "700",
  },
  dayLabelActive: {
    color: "#93c5fd",
  },
  dayLabelToday: {
    color: "#2563eb",
  },
  dayNumber: {
    marginTop: 6,
    fontSize: 16,
    fontWeight: "800",
    color: "#111827",
  },
  dayNumberActive: {
    color: "#fff",
  },
  dayNumberToday: {
    color: "#2563eb",
  },
  blockGrid: {
    marginTop: 12,
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 12,
  },
  blockCard: {
    width: "47%",
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 12,
    gap: 6,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    elevation: 2,
  },
  blockCardActive: {
    borderWidth: 2,
    borderColor: "#111827",
  },
  blockDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  blockName: {
    fontSize: 13,
    fontWeight: "700",
    color: "#111827",
  },
  blockMeta: {
    marginTop: 6,
    color: "#64748b",
    fontSize: 12,
  },
  blockList: {
    marginTop: 16,
  },
  blockListTitle: {
    fontSize: 14,
    fontWeight: "800",
    color: "#111827",
    marginBottom: 8,
  },
  dateRow: {
    flexDirection: "row",
    gap: 12,
    marginTop: 16,
  },
  dateButton: {
    backgroundColor: "#e5e7eb",
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 14,
  },
  dateButtonText: {
    color: "#111827",
    fontWeight: "700",
  },
  dateButtonPrimary: {
    backgroundColor: "#111827",
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderRadius: 14,
  },
  dateButtonPrimaryText: {
    color: "#fff",
    fontWeight: "700",
  },
  block: {
    marginBottom: 20,
  },
  blockTitle: {
    color: "#475569",
    fontSize: 14,
    fontWeight: "700",
    marginBottom: 8,
  },
  medCard: {
    backgroundColor: "#fff",
    padding: 16,
    borderRadius: 20,
    marginBottom: 12,
  },
  medCardDone: {
    backgroundColor: "#ecfdf5",
    borderWidth: 1,
    borderColor: "#10b981",
  },
  medCardHighlight: {
    borderWidth: 2,
    borderColor: "#f59e0b",
  },
  medName: {
    fontSize: 16,
    fontWeight: "700",
  },
  medInfo: {
    color: "#64748b",
    marginTop: 6,
  },
  medMetaRow: {
    marginTop: 6,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  medStock: {
    color: "#111827",
    fontWeight: "700",
  },
  medStockLow: {
    color: "#ef4444",
  },
  medPending: {
    marginTop: 6,
    color: "#b45309",
    fontSize: 12,
    fontWeight: "600",
  },
  medDoseLink: {
    marginTop: 6,
    alignSelf: "flex-start",
    backgroundColor: "#e2e8f0",
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 12,
  },
  medDoseLinkText: {
    color: "#0f172a",
    fontSize: 12,
    fontWeight: "600",
  },
  medButton: {
    marginTop: 12,
    backgroundColor: "#007AFF",
    padding: 12,
    borderRadius: 16,
    alignItems: "center",
  },
  medButtonDone: {
    backgroundColor: "#10b981",
  },
  medButtonText: {
    color: "#fff",
    fontWeight: "700",
    textTransform: "uppercase",
  },
});
