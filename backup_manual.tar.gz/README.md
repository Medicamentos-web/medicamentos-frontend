# Gestión de Medicamentos Multifamiliar

## Requisitos

- Docker Desktop (Windows)
- Node.js 18+ (para ejecutar el healthcheck y la UI)

## Paso a paso (primer arranque en localhost)

1. Abre una terminal en la raíz del proyecto.
2. Inicia PostgreSQL con Docker:
   - `docker compose up -d`
3. Verifica que se creó la carpeta de datos:
   - Deberías ver `postgres_data` dentro del proyecto con archivos nuevos.
4. Instala dependencias de Node.js:
   - `npm install`
5. Ejecuta el healthcheck:
   - `npm run healthcheck`
6. Inicia la interfaz web (Next.js):
   - `npm run dev`
7. Abre la app en el navegador:
   - `http://localhost:3000`

## Variables de entorno (UI)

Crea un archivo `.env.local` en la raíz con estas variables (o usa los valores por defecto):

```
DB_HOST=localhost
DB_PORT=5432
DB_USER=medicamentos
DB_PASSWORD=medicamentos_secret
DB_NAME=medicamentos
DEFAULT_FAMILY_ID=1
INVENTORY_MAX_STOCK=30
```

## Notas importantes

- El esquema SQL se ejecuta **solo la primera vez** que PostgreSQL inicializa el directorio de datos.
- Si necesitas reinicializar desde cero, detén los contenedores y elimina el contenido de `postgres_data` (o renómbralo para respaldo).
- Credenciales por defecto (para desarrollo local):
  - Usuario: `medicamentos`
  - Password: `medicamentos_secret`
  - DB: `medicamentos`
  - Host: `localhost`
  - Puerto: `5432`

## Estructura del proyecto

```
medicamentos_v3/
├── backend/
│   └── .gitkeep
├── app/
│   ├── layout.jsx
│   ├── page.jsx
│   └── globals.css
├── components/
│   └── ui/
├── docker-compose.yml
├── healthcheck.js
├── jsconfig.json
├── lib/
│   ├── data.js
│   ├── db.js
├── package.json
├── postcss.config.js
├── public/
│   └── pill-placeholder.svg
├── database/
│   ├── ERD.md
│   └── init/
│       └── 01_schema.sql
└── postgres_data/   (se crea automáticamente con Docker)
```
