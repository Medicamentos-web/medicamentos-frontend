const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

export async function updateMedStock(scheduleId, status, familyId, date) {
  const res = await fetch(`${apiUrl}/api/meds-toggle`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify({
      schedule_id: scheduleId,
      status,
      family_id: familyId,
      date,
    }),
  });
  return res.ok;
}
