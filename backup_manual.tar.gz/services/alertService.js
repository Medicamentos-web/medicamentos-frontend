const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

export async function getAlerts(familyId) {
  const res = await fetch(`${apiUrl}/api/alerts?family_id=${familyId}`, {
    credentials: "include",
  });
  if (!res.ok) return [];
  return res.json();
}
