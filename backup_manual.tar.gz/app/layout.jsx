import "./globals.css";

export const metadata = {
  title: "Gestión de Medicamentos Multifamiliar",
  description: "Dashboard familiar de tomas, inventario y estado diario.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <head>
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#0a0c0e" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
      </head>
      <body className="min-h-screen bg-slate-50">
        <div className="mx-auto w-full max-w-3xl px-4 pb-16 pt-6 sm:px-6">
          {children}
        </div>
      </body>
    </html>
  );
}
