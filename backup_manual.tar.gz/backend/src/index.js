const express = require("express");
const bcrypt = require("bcryptjs");
const crypto = require("crypto");
const nodemailer = require("nodemailer");
const webpush = require("web-push");
const { execFile } = require("child_process");
const os = require("os");
const path = require("path");
const fs = require("fs");
const multer = require("multer");
const PDFDocument = require("pdfkit");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const cors = require("cors");
const { Pool } = require("pg");

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
const allowedOrigins = [
  /^http:\/\/localhost:\d+$/,
  /^http:\/\/192\.168\.\d+\.\d+:\d+$/,
];

app.use(
  cors({
    origin: (origin, callback) => {
      if (!origin) return callback(null, true);
      const ok = allowedOrigins.some((regex) => regex.test(origin));
      return ok ? callback(null, true) : callback(new Error("CORS bloqueado"));
    },
    credentials: true,
  })
);

const JWT_SECRET = process.env.JWT_SECRET || "dev_secret_change";
const TOKEN_NAME = "medicamentos_token";
const DEV_SHOW_RESET_TOKEN = process.env.DEV_SHOW_RESET_TOKEN === "true";

const pool = new Pool({
  host: process.env.DB_HOST || "localhost",
  port: Number(process.env.DB_PORT || 5432),
  user: process.env.DB_USER || "medicamentos",
  password: process.env.DB_PASSWORD || "medicamentos_secret",
  database: process.env.DB_NAME || "medicamentos",
});

const ADMIN_EMAIL = process.env.ADMIN_EMAIL || "";
const VAPID_PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY || "";
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY || "";
const DEFAULT_TEMP_PASSWORD = process.env.DEFAULT_TEMP_PASSWORD || "123456";
const LOW_STOCK_THRESHOLD = Number(process.env.LOW_STOCK_THRESHOLD || 10);

const mailTransport =
  process.env.SMTP_HOST && process.env.SMTP_USER
    ? nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: Number(process.env.SMTP_PORT || 587),
        secure: false,
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS,
        },
      })
    : null;

const pushKeys =
  VAPID_PUBLIC_KEY && VAPID_PRIVATE_KEY
    ? { publicKey: VAPID_PUBLIC_KEY, privateKey: VAPID_PRIVATE_KEY }
    : webpush.generateVAPIDKeys();

webpush.setVapidDetails(
  "mailto:" + (ADMIN_EMAIL || "admin@example.com"),
  pushKeys.publicKey,
  pushKeys.privateKey
);

const uploadDir = path.join(os.tmpdir(), "med-imports");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}
const upload = multer({ dest: uploadDir });
const medicalRecordsDir = path.join("/data/imports", "medical_records");
if (!fs.existsSync(medicalRecordsDir)) {
  fs.mkdirSync(medicalRecordsDir, { recursive: true });
}

async function ensureAuthTables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS password_resets (
      id SERIAL PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      token VARCHAR(64) NOT NULL UNIQUE,
      expires_at TIMESTAMPTZ NOT NULL,
      used_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
  await pool.query(
    "CREATE INDEX IF NOT EXISTS idx_password_resets_user_id ON password_resets(user_id)"
  );
}

ensureAuthTables().catch((error) => {
  console.error("ERROR: No se pudo crear password_resets:", error.message);
});

async function ensureUserColumns() {
  await pool.query(
    `ALTER TABLE users ADD COLUMN IF NOT EXISTS must_change_password BOOLEAN NOT NULL DEFAULT false`
  );
  await pool.query(
    `UPDATE users SET must_change_password = false WHERE must_change_password IS NULL`
  );
}

ensureUserColumns().catch((error) => {
  console.error("ERROR: No se pudo actualizar users:", error.message);
});

async function ensureUserProfileColumns() {
  await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS first_name VARCHAR(120)`);
  await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS last_name VARCHAR(120)`);
  await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS birth_date DATE`);
  await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS street VARCHAR(255)`);
  await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS house_number VARCHAR(32)`);
  await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS postal_code VARCHAR(32)`);
  await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS city VARCHAR(120)`);
}

ensureUserProfileColumns().catch((error) => {
  console.error("ERROR: No se pudo actualizar perfil de users:", error.message);
});

async function ensureDoctorTables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS family_doctors (
      id SERIAL PRIMARY KEY,
      family_id INTEGER NOT NULL REFERENCES families(id) ON DELETE CASCADE,
      first_name VARCHAR(120) NOT NULL,
      last_name VARCHAR(120) NOT NULL,
      email VARCHAR(255),
      street VARCHAR(255),
      house_number VARCHAR(32),
      postal_code VARCHAR(32),
      city VARCHAR(120),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
  await pool.query(
    "CREATE INDEX IF NOT EXISTS idx_family_doctors_family_id ON family_doctors(family_id)"
  );
}

ensureDoctorTables().catch((error) => {
  console.error("ERROR: No se pudo crear family_doctors:", error.message);
});

async function ensureAlertTables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS alerts (
      id SERIAL PRIMARY KEY,
      family_id INTEGER NOT NULL REFERENCES families(id) ON DELETE CASCADE,
      user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
      type VARCHAR(32) NOT NULL,
      level VARCHAR(16) NOT NULL DEFAULT 'info',
      message TEXT NOT NULL,
      med_name VARCHAR(255),
      med_dosage VARCHAR(120),
      dose_time VARCHAR(16),
      alert_date DATE,
      schedule_id INTEGER REFERENCES schedules(id) ON DELETE SET NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      read_at TIMESTAMPTZ
    );
  `);
  await pool.query(`ALTER TABLE alerts ADD COLUMN IF NOT EXISTS med_name VARCHAR(255)`);
  await pool.query(`ALTER TABLE alerts ADD COLUMN IF NOT EXISTS med_dosage VARCHAR(120)`);
  await pool.query(`ALTER TABLE alerts ADD COLUMN IF NOT EXISTS dose_time VARCHAR(16)`);
  await pool.query(`ALTER TABLE alerts ADD COLUMN IF NOT EXISTS alert_date DATE`);
  await pool.query(`ALTER TABLE alerts ADD COLUMN IF NOT EXISTS schedule_id INTEGER`);
  await pool.query(
    "CREATE INDEX IF NOT EXISTS idx_alerts_family_id ON alerts(family_id)"
  );
  await pool.query(
    "CREATE INDEX IF NOT EXISTS idx_alerts_user_id ON alerts(user_id)"
  );
}

ensureAlertTables().catch((error) => {
  console.error("ERROR: No se pudo crear alerts:", error.message);
});

async function ensureAuditTables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS medicine_audits (
      id SERIAL PRIMARY KEY,
      medicine_id INTEGER REFERENCES medicines(id) ON DELETE SET NULL,
      family_id INTEGER NOT NULL REFERENCES families(id) ON DELETE CASCADE,
      user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      action VARCHAR(16) NOT NULL,
      notes TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
  await pool.query(
    "CREATE INDEX IF NOT EXISTS idx_medicine_audits_family_id ON medicine_audits(family_id)"
  );
}

ensureAuditTables().catch((error) => {
  console.error("ERROR: No se pudo crear medicine_audits:", error.message);
});

async function ensureWeeklyReminders() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS weekly_reminders (
      id SERIAL PRIMARY KEY,
      family_id INTEGER NOT NULL REFERENCES families(id) ON DELETE CASCADE,
      week_start DATE NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE (family_id, week_start)
    );
  `);
}

ensureWeeklyReminders().catch((error) => {
  console.error("ERROR: No se pudo crear weekly_reminders:", error.message);
});

async function ensureScheduleColumns() {
  await pool.query(
    `ALTER TABLE schedules ADD COLUMN IF NOT EXISTS days_of_week VARCHAR(14) DEFAULT '1234567'`
  );
  await pool.query(
    `ALTER TABLE schedules ADD COLUMN IF NOT EXISTS start_date DATE`
  );
  await pool.query(
    `ALTER TABLE schedules ADD COLUMN IF NOT EXISTS end_date DATE`
  );
  await pool.query(
    `UPDATE schedules SET days_of_week = '1234567' WHERE days_of_week IS NULL`
  );
}

ensureScheduleColumns().catch((error) => {
  console.error("ERROR: No se pudo actualizar schedules:", error.message);
});

async function ensureCheckoutTables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS daily_checkouts (
      id SERIAL PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      family_id INTEGER NOT NULL REFERENCES families(id) ON DELETE CASCADE,
      day DATE NOT NULL,
      sent_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE (user_id, day)
    );
  `);
}

ensureCheckoutTables().catch((error) => {
  console.error("ERROR: No se pudo crear daily_checkouts:", error.message);
});

async function ensurePushTables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS push_subscriptions (
      id SERIAL PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      family_id INTEGER NOT NULL REFERENCES families(id) ON DELETE CASCADE,
      endpoint TEXT NOT NULL,
      p256dh TEXT NOT NULL,
      auth TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE (user_id, endpoint)
    );
  `);
}

ensurePushTables().catch((error) => {
  console.error("ERROR: No se pudo crear push_subscriptions:", error.message);
});

async function ensureImportTables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS import_batches (
      id SERIAL PRIMARY KEY,
      family_id INTEGER NOT NULL REFERENCES families(id) ON DELETE CASCADE,
      user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      source_file TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
  await pool.query(
    `ALTER TABLE medicines ADD COLUMN IF NOT EXISTS import_batch_id INTEGER REFERENCES import_batches(id) ON DELETE SET NULL`
  );
  await pool.query(
    "CREATE INDEX IF NOT EXISTS idx_medicines_import_batch_id ON medicines(import_batch_id)"
  );
}

ensureImportTables().catch((error) => {
  console.error("ERROR: No se pudo crear import_batches:", error.message);
});

async function ensureDeletionLogs() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS deletion_logs (
      id SERIAL PRIMARY KEY,
      family_id INTEGER NOT NULL REFERENCES families(id) ON DELETE CASCADE,
      user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      deleted_count INTEGER NOT NULL DEFAULT 0,
      snapshot JSONB NOT NULL DEFAULT '[]'::jsonb,
      deleted_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
  await pool.query(
    "CREATE INDEX IF NOT EXISTS idx_deletion_logs_family_id ON deletion_logs(family_id)"
  );
  await pool.query(
    "CREATE INDEX IF NOT EXISTS idx_deletion_logs_user_id ON deletion_logs(user_id)"
  );
  await pool.query(
    "CREATE INDEX IF NOT EXISTS idx_deletion_logs_deleted_at ON deletion_logs(deleted_at)"
  );
}

ensureDeletionLogs().catch((error) => {
  console.error("ERROR: No se pudo crear deletion_logs:", error.message);
});

async function ensureMedicalRecords() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS medical_records (
      id SERIAL PRIMARY KEY,
      family_id INTEGER NOT NULL REFERENCES families(id) ON DELETE CASCADE,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      title VARCHAR(200) NOT NULL,
      record_date DATE,
      file_path TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
  await pool.query(
    "CREATE INDEX IF NOT EXISTS idx_medical_records_family_id ON medical_records(family_id)"
  );
  await pool.query(
    "CREATE INDEX IF NOT EXISTS idx_medical_records_user_id ON medical_records(user_id)"
  );
  await pool.query(
    "CREATE INDEX IF NOT EXISTS idx_medical_records_date ON medical_records(record_date)"
  );
}

ensureMedicalRecords().catch((error) => {
  console.error("ERROR: No se pudo crear medical_records:", error.message);
});

async function ensureDoseChangeRequests() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS dose_change_requests (
      id SERIAL PRIMARY KEY,
      family_id INTEGER NOT NULL REFERENCES families(id) ON DELETE CASCADE,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      schedule_id INTEGER NOT NULL REFERENCES schedules(id) ON DELETE CASCADE,
      medicine_id INTEGER NOT NULL REFERENCES medicines(id) ON DELETE CASCADE,
      current_dosage VARCHAR(120),
      requested_dosage VARCHAR(120) NOT NULL,
      effective_date DATE,
      status VARCHAR(16) NOT NULL DEFAULT 'pending',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
  await pool.query(
    "CREATE INDEX IF NOT EXISTS idx_dose_change_family_id ON dose_change_requests(family_id)"
  );
  await pool.query(
    "CREATE INDEX IF NOT EXISTS idx_dose_change_user_id ON dose_change_requests(user_id)"
  );
  await pool.query(
    "CREATE INDEX IF NOT EXISTS idx_dose_change_status ON dose_change_requests(status)"
  );
}

ensureDoseChangeRequests().catch((error) => {
  console.error("ERROR: No se pudo crear dose_change_requests:", error.message);
});

async function ensureMedicineUserScope() {
  await pool.query(
    `ALTER TABLE medicines ADD COLUMN IF NOT EXISTS user_id INTEGER REFERENCES users(id) ON DELETE CASCADE`
  );
  await pool.query(
    `UPDATE medicines
     SET user_id = sub.user_id
     FROM (
       SELECT s.medicine_id, MIN(s.user_id) AS user_id
       FROM schedules s
       GROUP BY s.medicine_id
     ) sub
     WHERE medicines.id = sub.medicine_id AND medicines.user_id IS NULL`
  );
  await pool.query(
    "CREATE INDEX IF NOT EXISTS idx_medicines_user_id ON medicines(user_id)"
  );
}

ensureMedicineUserScope().catch((error) => {
  console.error("ERROR: No se pudo actualizar medicines.user_id:", error.message);
});

async function ensureDoctorTables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS doctors (
      id SERIAL PRIMARY KEY,
      family_id INTEGER NOT NULL REFERENCES families(id) ON DELETE CASCADE,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      first_name VARCHAR(120) NOT NULL,
      last_name VARCHAR(120) NOT NULL,
      email VARCHAR(255),
      phone VARCHAR(50),
      street VARCHAR(255),
      house_number VARCHAR(50),
      postal_code VARCHAR(32),
      city VARCHAR(120),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE (family_id, user_id)
    );
  `);
}

ensureDoctorTables().catch((error) => {
  console.error("ERROR: No se pudo crear doctors:", error.message);
});

async function sendAdminAlertEmail(subject, html, attachments) {
  if (!mailTransport || !ADMIN_EMAIL) {
    return false;
  }
  await mailTransport.sendMail({
    from: process.env.SMTP_USER,
    to: ADMIN_EMAIL,
    subject,
    html,
    attachments: attachments && attachments.length ? attachments : undefined,
  });
  return true;
}

async function sendUserEmail(email, subject, html) {
  if (!mailTransport || !email) {
    return false;
  }
  await mailTransport.sendMail({
    from: process.env.SMTP_USER,
    to: email,
    subject,
    html,
  });
  return true;
}

async function logMedicineAudit(familyId, userId, medicineId, action, notes) {
  await pool.query(
    `INSERT INTO medicine_audits (medicine_id, family_id, user_id, action, notes)
     VALUES ($1, $2, $3, $4, $5)`,
    [medicineId, familyId, userId || null, action, notes || null]
  );
}

async function sendPushToFamily(familyId, payload) {
  const subs = await pool.query(
    `SELECT endpoint, p256dh, auth FROM push_subscriptions WHERE family_id = $1`,
    [familyId]
  );
  await Promise.all(
    subs.rows.map((sub) =>
      webpush.sendNotification(
        {
          endpoint: sub.endpoint,
          keys: { p256dh: sub.p256dh, auth: sub.auth },
        },
        JSON.stringify(payload)
      )
    )
  );
}

async function sendPushToUser(userId, payload) {
  const subs = await pool.query(
    `SELECT endpoint, p256dh, auth FROM push_subscriptions WHERE user_id = $1`,
    [userId]
  );
  await Promise.all(
    subs.rows.map((sub) =>
      webpush.sendNotification(
        {
          endpoint: sub.endpoint,
          keys: { p256dh: sub.p256dh, auth: sub.auth },
        },
        JSON.stringify(payload)
      )
    )
  );
}

function runOcrOnPdf(filePath, lang = "deu") {
  return new Promise((resolve, reject) => {
    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "med-ocr-"));
    const prefix = path.join(tmpDir, "page");
    execFile("pdftoppm", ["-png", filePath, prefix], (err) => {
      if (err) return reject(err);
      const files = fs
        .readdirSync(tmpDir)
        .filter((f) => f.endsWith(".png"))
        .map((f) => path.join(tmpDir, f));
      let text = "";
      const runNext = (i) => {
        if (i >= files.length) return resolve(text);
        execFile("tesseract", [files[i], "stdout", "-l", lang], (err2, stdout) => {
          if (err2) return reject(err2);
          text += stdout + "\n";
          runNext(i + 1);
        });
      };
      runNext(0);
    });
  });
}

function runOcrOnImage(filePath, { lang = "deu+eng", psm = "6", oem = "1" } = {}) {
  return new Promise((resolve, reject) => {
    execFile(
      "tesseract",
      [filePath, "stdout", "-l", lang, "--oem", String(oem), "--psm", String(psm)],
      (err, stdout) => {
        if (err) return reject(err);
        resolve(stdout || "");
      }
    );
  });
}

async function runOcrOnImageBest(filePath) {
  const attempts = [
    { psm: "6", oem: "1", lang: "deu+eng" },
    { psm: "11", oem: "1", lang: "deu+eng" },
    { psm: "4", oem: "1", lang: "deu+eng" },
    { psm: "7", oem: "3", lang: "deu+eng" },
    { psm: "8", oem: "3", lang: "deu+eng" },
    { psm: "13", oem: "3", lang: "deu+eng" },
  ];
  let best = "";
  for (const opts of attempts) {
    try {
      const text = await runOcrOnImage(filePath, opts);
      if ((text || "").length > best.length) best = text || "";
    } catch {
      // ignora intento fallido
    }
  }
  return best;
}

function normalizeText(value) {
  const raw = String(value || "")
    .replace(/Ä/g, "Ae")
    .replace(/Ö/g, "Oe")
    .replace(/Ü/g, "Ue")
    .replace(/ä/g, "ae")
    .replace(/ö/g, "oe")
    .replace(/ü/g, "ue")
    .replace(/ß/g, "ss");
  return raw
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function patientNameMatches(text, user) {
  const normalized = normalizeText(text);
  const first = normalizeText(user.first_name || user.name?.split(" ")[0]);
  const last = normalizeText(user.last_name || user.name?.split(" ").slice(1).join(" "));
  if (!first || !last) return false;
  if (normalized.includes(first) && normalized.includes(last)) return true;
  const firstInitial = first.slice(0, 1);
  return normalized.includes(last) && normalized.includes(firstInitial);
}

function normalizeDateOnly(value) {
  if (!value) return "";
  const asDate = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(asDate.getTime())) return "";
  return asDate.toISOString().slice(0, 10);
}

function safeFilename(name) {
  return String(name || "archivo.pdf")
    .replace(/[^\w.\-]+/g, "_")
    .slice(0, 120);
}

const DISPLAY_TIMEZONE = process.env.TZ || "Europe/Zurich";
const DISPLAY_LOCALE = "de-CH";

function formatDateTime(value) {
  const asDate = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(asDate.getTime())) return "-";
  return asDate.toLocaleString(DISPLAY_LOCALE, {
    timeZone: DISPLAY_TIMEZONE,
    hour12: false,
  });
}

function formatDateOnlyDisplay(value) {
  const asDate = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(asDate.getTime())) return "-";
  return asDate.toLocaleDateString(DISPLAY_LOCALE, { timeZone: DISPLAY_TIMEZONE });
}

function buildCriticalMedsPdf(
  medicines,
  { title = "Medicamentos críticos", patientName = "Paciente" } = {}
) {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({ margin: 40 });
      const chunks = [];
      doc.on("data", (chunk) => chunks.push(chunk));
      doc.on("end", () => resolve(Buffer.concat(chunks)));
      doc.fontSize(16).text(title);
      doc.moveDown(0.5);
      doc.fontSize(11).text(`Fecha: ${formatDateTime(new Date())}`);
      doc.moveDown();
      doc
        .fontSize(12)
        .text(
          "Estimado/a Dr./Dra.,\n\n" +
            `Le escribo para solicitar una cita y revisar la medicacion de ${patientName}. ` +
            "Adjunto a continuacion la lista de medicamentos con stock bajo para su verificacion.\n"
        );
      doc.moveDown();
      doc.fontSize(12).text("Lista de medicamentos críticos:");
      doc.moveDown(0.3);
      if (!medicines.length) {
        doc.text("No hay medicamentos críticos.");
      } else {
        medicines.forEach((med, idx) => {
          const line = `${idx + 1}. ${med.name} ${
            med.dosage ? `(${med.dosage})` : ""
          } - Stock: ${med.current_stock}`;
          doc.text(line);
        });
      }
      doc.moveDown();
      doc
        .fontSize(12)
        .text(
          "Muchas gracias por su apoyo.\n\nAtentamente,\nEquipo de Gestion de Medicamentos"
        );
      doc.end();
    } catch (error) {
      reject(error);
    }
  });
}

const MED_NAME_HINTS = (process.env.MED_NAME_HINTS || "")
  .split(",")
  .map((v) => v.trim().toLowerCase())
  .filter(Boolean);

const MED_LINE_KEYWORDS =
  /\b(filmtabl|filmtablett|tablett|tablet|tabl|tab|kapsel|caps|capsule|retard|forte|depot|sirup|syrup|tropfen|drops|spray|cream|creme|salbe|gel|loesung|lösung|solution|inj|injekt|suspension|ampul|ampulle|pflaster|patch)\b/i;
const MED_QTY_PATTERN = /\b\d+\s*(stk|tbl|kapsel|caps|pcs|pack|ml)\b/i;
const MED_DOSAGE_PATTERN = /(\d+(?:\.\d+)?)\s*(mg|mcg|g|ml|iu|ie)\b/i;
const OCR_JUNK_PATTERN = /(?:^|\s)(?:[A-Za-zÄÖÜäöüß]\s+){4,}/;
const OCR_JUNK_NO_VOWELS = /^[^aeiouäöüAEIOUÄÖÜ]{6,}$/;
const OCR_PREFIX_PATTERN = /^(sz|ss|ses|ex)\s+/i;
const OCR_SINGLE_TOKEN_PATTERN = /\b[A-Za-zÄÖÜäöüß]\b/g;
const OCR_SHORT_TOKEN_PATTERN = /\b[A-Za-zÄÖÜäöüß]{1,2}\b/g;

function filterOcrLines(lines) {
  const cleaned = [];
  for (const raw of lines || []) {
    const line = String(raw || "").trim();
    if (line.length < 4) continue;
    if (OCR_JUNK_PATTERN.test(line)) continue;
    const singleTokens = (line.match(OCR_SINGLE_TOKEN_PATTERN) || []).length;
    const shortTokens = (line.match(OCR_SHORT_TOKEN_PATTERN) || []).length;
    if (singleTokens >= 4 || shortTokens >= 6) continue;
    if (OCR_JUNK_NO_VOWELS.test(line.replace(/[^A-Za-zÄÖÜäöüß]/g, ""))) continue;
    const normalizedLine = line.replace(OCR_PREFIX_PATTERN, "").trim();
    const lower = normalizedLine.toLowerCase();
    const hasHint = MED_NAME_HINTS.length
      ? MED_NAME_HINTS.some((hint) => lower.includes(hint))
      : false;
    if (
      hasHint ||
      MED_DOSAGE_PATTERN.test(normalizedLine) ||
      MED_QTY_PATTERN.test(normalizedLine) ||
      MED_LINE_KEYWORDS.test(normalizedLine)
    ) {
      cleaned.push(normalizedLine);
      continue;
    }
    const letters = (normalizedLine.match(/[A-Za-zÄÖÜäöüß]/g) || []).length;
    const digits = (normalizedLine.match(/[0-9]/g) || []).length;
    if (letters >= 10 && digits >= 1) {
      cleaned.push(normalizedLine);
      continue;
    }
  }
  return cleaned;
}

function cleanLineForDisplay(line) {
  return String(line || "").replace(OCR_PREFIX_PATTERN, "").trim();
}

function filterOcrLinesForDisplay(lines) {
  return filterOcrLines(lines).map(cleanLineForDisplay);
}

function cleanLineForName(line) {
  return line
    .replace(/^(sz|ss|ses|ex)\s+/i, "")
    .replace(/\s{2,}/g, " ")
    .trim();
}

function extractDosage(lines, preferredIndex = -1) {
  const dosagePattern = /(\d+(?:\.\d+)?)\s*(mg|mcg|g|ml|iu|ie)\b/i;
  const dosagePatternReversed = /\b(mg|mcg|g|ml|iu|ie)\s*(\d+(?:\.\d+)?)/i;
  const dosagePatternCompact = /(\d+(?:\.\d+)?)(mg|mcg|g|ml|iu|ie)\b/i;
  const candidates = [];
  if (preferredIndex >= 0) {
    candidates.push(lines[preferredIndex], lines[preferredIndex + 1], lines[preferredIndex - 1]);
  }
  candidates.push(...lines);
  for (const line of candidates) {
    if (!line) continue;
    const match = line.match(dosagePattern);
    if (match) return `${match[1]} ${match[2]}`;
    const matchCompact = line.match(dosagePatternCompact);
    if (matchCompact) return `${matchCompact[1]} ${matchCompact[2]}`;
    const matchReversed = line.match(dosagePatternReversed);
    if (matchReversed) return `${matchReversed[2]} ${matchReversed[1]}`;
  }
  return "N/A";
}

function extractMedicineName(lines) {
  const datePattern = /\b\d{1,2}\.\d{1,2}\.\d{2,4}\b/;
  const phonePattern = /(tel|telefon|phone|fax|mob|chf|agb|ag|gmbh|spital|klinik)/i;
  const dosagePattern = /\b\d+(?:\.\d+)?\s*(mg|mcg|g|ml|iu|ie)\b/i;
  let best = "Medicamento escaneado";
  let bestScore = -Infinity;
  let hintIndex = -1;
  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line || line.length < 4) continue;
    let score = 0;
    if (dosagePattern.test(line)) score += 4;
    const letters = (line.match(/[A-Za-z]/g) || []).length;
    const digits = (line.match(/[0-9]/g) || []).length;
    score += Math.min(6, letters / 2);
    score -= digits > 8 ? 3 : 0;
    if (datePattern.test(line)) score -= 4;
    if (phonePattern.test(line)) score -= 3;
    if (line === line.toUpperCase()) score += 2;
    if (MED_NAME_HINTS.length) {
      const lower = line.toLowerCase();
      if (MED_NAME_HINTS.some((hint) => lower.includes(hint))) {
        score += 8;
        hintIndex = lines.indexOf(rawLine);
      }
    }
    if (score > bestScore) {
      bestScore = score;
      best = line;
    }
  }
  if (hintIndex >= 0) {
    const hinted = cleanLineForName(lines[hintIndex] || best);
    return hinted || best;
  }
  return cleanLineForName(best) || best;
}

async function upsertMedicineForUser({
  familyId,
  userId,
  name,
  dosage,
  qty,
  expiryDate,
  batchId,
}) {
  const normName = normalizeText(name);
  const normDosage = normalizeText(dosage || "");
  const existing = await pool.query(
    `SELECT id, current_stock, name, dosage FROM medicines
     WHERE family_id = $1 AND user_id = $2`,
    [familyId, userId]
  );
  const dup = existing.rows.find(
    (row) =>
      normalizeText(row.name) === normName &&
      normalizeText(row.dosage || "") === normDosage
  );
  if (dup) {
    const newStock = Number(dup.current_stock || 0) + Number(qty || 0);
    await pool.query(
      `UPDATE medicines SET current_stock = $1 WHERE id = $2`,
      [newStock, dup.id]
    );
    return { id: dup.id, action: "merged" };
  }
  const created = await pool.query(
    `INSERT INTO medicines (family_id, user_id, name, dosage, current_stock, expiration_date, import_batch_id)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     RETURNING id`,
    [familyId, userId, name, dosage, qty || 0, expiryDate || null, batchId || null]
  );
  return { id: created.rows[0].id, action: "created" };
}

async function ensureDefaultScheduleForMedicine({ familyId, userId, medicineId }) {
  const existing = await pool.query(
    `SELECT id FROM schedules WHERE medicine_id = $1 AND user_id = $2 LIMIT 1`,
    [medicineId, userId]
  );
  if (existing.rows.length) return;
  await pool.query(
    `INSERT INTO schedules (medicine_id, user_id, dose_time, frequency, days_of_week)
     VALUES ($1, $2, $3, $4, $5)`,
    [medicineId, userId, "08:00", "1", "1234567"]
  );
}

function getFamilyId(req) {
  const raw =
    req.query.family_id ||
    req.query.familyId ||
    req.headers["x-family-id"] ||
    req.body?.family_id ||
    req.body?.familyId ||
    req.user?.family_id;
  const parsed = Number(raw);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
}

function signToken(user) {
  return jwt.sign(
    {
      sub: user.id,
      family_id: user.family_id,
      role: user.role,
      name: user.name,
      email: user.email,
      must_change_password: !!user.must_change_password,
    },
    JWT_SECRET,
    { expiresIn: "7d" }
  );
}

function authMiddleware(req, _res, next) {
  const bearer = req.headers.authorization?.startsWith("Bearer ")
    ? req.headers.authorization.slice(7)
    : null;
  const token = req.cookies[TOKEN_NAME] || bearer;
  if (!token) {
    req.user = null;
    return next();
  }
  try {
    req.user = jwt.verify(token, JWT_SECRET);
  } catch {
    req.user = null;
  }
  return next();
}

app.use(authMiddleware);

function requireAuth(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ error: "no autenticado" });
  }
  return next();
}

function requireAuthHtml(req, res, next) {
  if (!req.user) {
    return res.redirect("/admin/login");
  }
  return next();
}

function requireRoleHtml(roles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.redirect("/admin/login");
    }
    if (!roles.includes(req.user.role)) {
      return res.status(403).send(`
        <!doctype html>
        <html lang="es">
          <head>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1" />
            <title>Acceso denegado</title>
            <style>
              body { font-family: Inter, Arial, sans-serif; background:#f5f7fb; margin:0; padding:40px; }
              .card { max-width:520px; margin:0 auto; background:#fff; border-radius:20px; padding:24px; box-shadow:0 20px 40px -30px rgba(15,23,42,.4); }
              a { color:#2563eb; text-decoration:none; font-size:13px; }
            </style>
          </head>
          <body>
            <div class="card">
              <h1>Acceso denegado</h1>
              <p>No tienes permisos para ver esta sección.</p>
              <p><a href="/admin/login">Volver al login</a></p>
            </div>
          </body>
        </html>
      `);
    }
    return next();
  };
}

function escapeHtml(value) {
  if (value === null || value === undefined) return "";
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function buildUserName(name, firstName, lastName) {
  if (name) return name.trim();
  const parts = [firstName, lastName].filter(Boolean);
  return parts.length ? parts.join(" ").trim() : "";
}

async function importMedsFromPdf(filePath, familyId, userId, useOcr = false, skipNameCheck = false) {
  const pdfParse = require("pdf-parse");
  const buffer = fs.readFileSync(filePath);
  const pdf = await pdfParse(buffer);
  let text = pdf.text;
  if (useOcr || !text || text.trim().length < 20) {
    text = await runOcrOnPdf(filePath, "deu");
  }
  if (!skipNameCheck) {
    const userResult = await pool.query(
      `SELECT id, name, first_name, last_name FROM users WHERE id = $1 AND family_id = $2`,
      [userId, familyId]
    );
    const user = userResult.rows[0];
    if (!user || !patientNameMatches(text, user)) {
      throw new Error("Nombre de paciente no coincide o no se encontró en la receta.");
    }
  }
  const lines = text
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line && !line.startsWith("Medikament") && !line.startsWith("Seite"));

  const extractQuantity = (line) => {
    const match = line.match(/(\d+)\s*(Stk|ml|Amp|Btl)\b/i);
    if (!match) return { qty: 0, unit: "unidades" };
    return { qty: Number(match[1]), unit: match[2] };
  };
  const extractDosage = (line) => {
    const match = line.match(/(\d+(?:\.\d+)?)\s*(mg|mcg|g|IE\/ml|IU\/ml)\b/i);
    if (!match) return "N/A";
    return `${match[1]} ${match[2]}`;
  };
  const extractExpiry = (line) => {
    const match = line.match(/(\d{2}\.\d{2}\.\d{4})/);
    if (!match) return null;
    const [day, month, year] = match[1].split(".");
    return `${year}-${month}-${day}`;
  };
  const extractName = (line) => {
    const cleaned = line
      .replace(/\d+\s*(Stk|ml|Amp|Btl)\b/gi, "")
      .replace(/\d+(?:\.\d+)?\s*(mg|mcg|g|IE\/ml|IU\/ml)\b/gi, "")
      .replace(/\d{2}\.\d{2}\.\d{4}/g, "")
      .replace(/\b(auf weiteres)\b/gi, "")
      .replace(/[-–]\s*$/, "")
      .trim();
    return cleaned.replace(/\s{2,}/g, " ");
  };
  const parseColumns = (line) => {
    const split = line.split(/auf\s+weiteres/i);
    if (split.length < 2) return { mo: "-", mi: "-", ab: "-", na: "-", extra: "" };
    const right = split[1].trim();
    const parts = right.split(/\s+/);
    return {
      mo: parts[0] || "-",
      mi: parts[1] || "-",
      ab: parts[2] || "-",
      na: parts[3] || "-",
      extra: parts.slice(4).join(" "),
    };
  };

  const batchResult = await pool.query(
    `INSERT INTO import_batches (family_id, user_id, source_file)
     VALUES ($1, $2, $3)
     RETURNING id`,
    [familyId, userId || null, filePath || null]
  );
  const batchId = batchResult.rows[0].id;

  let inserted = 0;
  let warnings = 0;
  const defaultStart = process.env.DEFAULT_SCHEDULE_START_DATE || null;
  for (const line of lines) {
    if (line.startsWith("--")) continue;
    const name = extractName(line);
    if (!name || name.length < 3) continue;
    const dosage = extractDosage(line);
    const { qty } = extractQuantity(line);
    const expiryDate = extractExpiry(line);
    const columns = parseColumns(line);

    const medicineResult = await upsertMedicineForUser({
      familyId,
      userId,
      name,
      dosage,
      qty,
      expiryDate,
      batchId,
    });
    const medicineId = medicineResult.id;
    const scheduleTimes = [
      { key: "mo", time: "08:00" },
      { key: "mi", time: "14:00" },
      { key: "ab", time: "20:00" },
      { key: "na", time: "22:00" },
    ];
    const dayValue = {
      mo: columns.mo,
      mi: columns.mi,
      ab: columns.ab,
      na: columns.na,
    };
    for (const slot of scheduleTimes) {
      const value = dayValue[slot.key];
      if (!value || value === "-" || value === "0") continue;
      await pool.query(
        `INSERT INTO schedules (medicine_id, user_id, dose_time, frequency, days_of_week, start_date)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [medicineId, userId, slot.time, value, "1234567", defaultStart]
      );
    }
    const suspicious = qty === 0 || dosage === "N/A" || !expiryDate;
    if (suspicious) {
      warnings += 1;
      await pool.query(
        `INSERT INTO alerts (family_id, type, level, message, med_name, med_dosage, alert_date)
         VALUES ($1, 'import_warning', 'warning', $2, $3, $4, $5)`,
        [
          familyId,
          `Revisar importación: ${name} (stock: ${qty || 0}, dosis: ${dosage}, caducidad: ${
            expiryDate || "N/A"
          })`,
          name,
          dosage || "N/A",
          new Date().toISOString().slice(0, 10),
        ]
      );
    }
    inserted += 1;
  }
  return { inserted, warnings, batchId };
}

function requireRole(roles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: "no autenticado" });
    }
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: "sin permisos" });
    }
    return next();
  };
}

function resolveFamilyScope(req) {
  const familyId = getFamilyId(req);
  if (req.user?.role === "superuser") {
    return familyId;
  }
  return req.user?.family_id || familyId;
}

app.get("/health", async (_req, res) => {
  try {
    await pool.query("SELECT 1 AS ok");
    res.json({ ok: true });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

app.get("/", (_req, res) => {
  res.json({
    ok: true,
    message: "Backend de Medicamentos Multifamiliar",
    endpoints: [
      "/health",
      "/auth/register",
      "/auth/login",
      "/auth/me",
      "/api/families",
      "/api/users",
      "/api/medicines",
      "/api/schedules",
      "/api/dose-logs",
    ],
  });
});

// =============================================================================
// AUTH
// =============================================================================
app.post("/auth/register", async (req, res) => {
  const {
    family_id,
    name,
    first_name,
    last_name,
    street,
    house_number,
    postal_code,
    city,
    email,
    password,
    role,
  } = req.body || {};
  let safeRole = ["admin", "superuser", "user"].includes(role) ? role : "user";
  if (safeRole === "superuser" && req.user?.role !== "superuser") {
    safeRole = "user";
  }

  const finalName = buildUserName(name, first_name, last_name);
  if (!family_id || !finalName || !email || !password) {
    return res
      .status(400)
      .json({ error: "family_id, nombre, email y password son requeridos" });
  }

  try {
    const family = await pool.query(`SELECT id FROM families WHERE id = $1`, [
      Number(family_id),
    ]);
    if (family.rows.length === 0) {
      return res.status(404).json({ error: "familia no encontrada" });
    }
    const hashed = await bcrypt.hash(password, 10);
    const result = await pool.query(
      `INSERT INTO users (family_id, name, first_name, last_name, street, house_number, postal_code, city, email, password_hash, role)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
       RETURNING id, family_id, name, first_name, last_name, email, role, created_at, must_change_password`,
      [
        Number(family_id),
        finalName,
        first_name || null,
        last_name || null,
        street || null,
        house_number || null,
        postal_code || null,
        city || null,
        email,
        hashed,
        safeRole,
      ]
    );

    const user = result.rows[0];
    const token = signToken(user);
    res.cookie(TOKEN_NAME, token, {
      httpOnly: true,
      sameSite: "lax",
      secure: false,
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });

    res.status(201).json({ user, token });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/auth/login", async (req, res) => {
  const { family_id, email, password } = req.body || {};
  if (!family_id || !email || !password) {
    return res
      .status(400)
      .json({ error: "family_id, email y password son requeridos" });
  }

  try {
    const result = await pool.query(
      `SELECT id, family_id, name, first_name, last_name, email, role, password_hash, must_change_password
       FROM users
       WHERE family_id = $1 AND email = $2`,
      [Number(family_id), email]
    );
    if (result.rows.length === 0) {
      return res.status(401).json({ error: "credenciales inválidas" });
    }

    const user = result.rows[0];
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) {
      return res.status(401).json({ error: "credenciales inválidas" });
    }

    const token = signToken(user);
    res.cookie(TOKEN_NAME, token, {
      httpOnly: true,
      sameSite: "lax",
      secure: false,
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });

    const { password_hash, ...safeUser } = user;
    res.json({ user: safeUser, token });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get("/auth/me", (req, res) => {
  if (!req.user) {
    return res.status(401).json({ error: "no autenticado" });
  }
  res.json({ user: req.user });
});

app.post("/auth/logout", (_req, res) => {
  res.clearCookie(TOKEN_NAME, {
    httpOnly: true,
    sameSite: "lax",
    secure: false,
  });
  res.json({ ok: true });
});

app.post("/auth/forgot", async (req, res) => {
  const { family_id, email } = req.body || {};
  if (!family_id || !email) {
    return res
      .status(400)
      .json({ error: "family_id y email son requeridos" });
  }

  try {
    const userResult = await pool.query(
      `SELECT id FROM users WHERE family_id = $1 AND email = $2`,
      [Number(family_id), email]
    );

    if (userResult.rows.length === 0) {
      return res.json({ ok: true });
    }

    const token = crypto.randomBytes(24).toString("hex");
    const expiresAt = new Date(Date.now() + 30 * 60 * 1000);

    await pool.query(
      `INSERT INTO password_resets (user_id, token, expires_at)
       VALUES ($1, $2, $3)`,
      [userResult.rows[0].id, token, expiresAt]
    );

    if (mailTransport) {
      const resetLink = `${req.protocol}://${req.get("host")}/reset?token=${token}`;
      await sendUserEmail(
        email,
        "Restablecer contraseña",
        `<p>Hemos recibido una solicitud para restablecer tu contraseña.</p>
         <p>Token: <strong>${token}</strong></p>
         <p>Enlace (opcional): ${resetLink}</p>
         <p>Este token vence en 30 minutos.</p>`
      );
    }

    res.json({ ok: true, reset_token: DEV_SHOW_RESET_TOKEN ? token : undefined });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/auth/reset", async (req, res) => {
  const { token, new_password } = req.body || {};
  if (!token || !new_password) {
    return res
      .status(400)
      .json({ error: "token y new_password son requeridos" });
  }

  try {
    const result = await pool.query(
      `SELECT id, user_id, expires_at, used_at
       FROM password_resets
       WHERE token = $1`,
      [token]
    );
    if (result.rows.length === 0) {
      return res.status(400).json({ error: "token inválido" });
    }
    const row = result.rows[0];
    if (row.used_at) {
      return res.status(400).json({ error: "token ya utilizado" });
    }
    if (new Date(row.expires_at) < new Date()) {
      return res.status(400).json({ error: "token expirado" });
    }

    const hash = await bcrypt.hash(new_password, 10);
    await pool.query(`UPDATE users SET password_hash = $1 WHERE id = $2`, [
      hash,
      row.user_id,
    ]);
    await pool.query(`UPDATE password_resets SET used_at = NOW() WHERE id = $1`, [
      row.id,
    ]);

    res.json({ ok: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/auth/change-password", requireAuth, async (req, res) => {
  const { current_password, new_password } = req.body || {};
  if (!current_password || !new_password) {
    return res
      .status(400)
      .json({ error: "current_password y new_password son requeridos" });
  }

  try {
    const result = await pool.query(
      `SELECT id, password_hash FROM users WHERE id = $1`,
      [req.user.sub]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "usuario no encontrado" });
    }
    const ok = await bcrypt.compare(
      current_password,
      result.rows[0].password_hash
    );
    if (!ok) {
      return res.status(401).json({ error: "password actual incorrecto" });
    }
    const hash = await bcrypt.hash(new_password, 10);
    await pool.query(
      `UPDATE users SET password_hash = $1, must_change_password = false WHERE id = $2`,
      [hash, req.user.sub]
    );
    res.json({ ok: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

async function sendWelcomeEmail(email, tempPassword) {
  if (!mailTransport || !email) {
    return false;
  }
  await mailTransport.sendMail({
    from: process.env.SMTP_USER,
    to: email,
    subject: "Tu acceso inicial",
    html: `<p>Tu contraseña temporal es: <strong>${escapeHtml(
      tempPassword
    )}</strong></p><p>Ingresa y cámbiala desde la app.</p>`,
  });
  return true;
}

// =============================================================================
// HTML DASHBOARD (backend)
// =============================================================================
app.get("/admin/login", (_req, res) => {
  const errorMessage = _req.query?.error
    ? "Credenciales inválidas. Intenta nuevamente."
    : "";
  res.send(`
    <!doctype html>
    <html lang="es">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Acceso Admin</title>
        <style>
          body { font-family: Inter, Arial, sans-serif; background:#f5f7fb; margin:0; padding:40px; }
          .card { max-width:420px; margin:0 auto; background:#fff; border-radius:20px; padding:24px; box-shadow:0 20px 40px -30px rgba(15,23,42,.4); }
          h1 { font-size:20px; margin:0 0 8px; }
          label { display:block; font-size:13px; color:#64748b; margin-top:12px; }
          input { width:100%; border:1px solid #e2e8f0; border-radius:14px; padding:12px 14px; margin-top:6px; }
          button { width:100%; margin-top:18px; background:#2563eb; color:#fff; border:0; border-radius:14px; padding:12px 14px; font-weight:600; }
          .note { margin-top:12px; font-size:12px; color:#94a3b8; }
          .error { margin-top:12px; font-size:13px; color:#b91c1c; }
        </style>
      </head>
      <body>
        <div class="card">
          <h1>Acceso administrador</h1>
          <p class="note">Inicia sesión para ver el dashboard del backend.</p>
          ${errorMessage ? `<div class="error">${errorMessage}</div>` : ""}
          <form method="POST" action="/admin/login">
            <label>Family ID</label>
            <input name="family_id" placeholder="1" required />
            <label>Email</label>
            <input name="email" type="email" placeholder="admin@mail.com" required />
            <label>Password</label>
            <input name="password" type="password" placeholder="******" required />
            <button type="submit">Entrar</button>
          </form>
        </div>
      </body>
    </html>
  `);
});

app.post("/admin/login", async (req, res) => {
  const { family_id, email, password } = req.body || {};
  if (!family_id || !email || !password) {
    return res.redirect("/admin/login?error=1");
  }

  try {
    const result = await pool.query(
      `SELECT id, family_id, name, email, role, password_hash
       FROM users
       WHERE family_id = $1 AND email = $2`,
      [Number(family_id), email]
    );
    if (result.rows.length === 0) {
      return res.redirect("/admin/login?error=1");
    }

    const user = result.rows[0];
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) {
      return res.redirect("/admin/login?error=1");
    }

    const token = signToken(user);
    res.cookie(TOKEN_NAME, token, {
      httpOnly: true,
      sameSite: "lax",
      secure: false,
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });
    res.redirect("/dashboard");
  } catch (error) {
    res.redirect("/admin/login?error=1");
  }
});

app.get("/admin/logout", (_req, res) => {
  res.clearCookie(TOKEN_NAME, {
    httpOnly: true,
    sameSite: "lax",
    secure: false,
  });
  res.redirect("/admin/login");
});

app.get("/dashboard", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const usersList = await pool.query(
    `SELECT id, name, email FROM users WHERE family_id = $1 ORDER BY name ASC`,
    [familyId]
  );
  const selectedUserId = Number(req.query?.user_id || req.user.sub);
  const safeUserId = Number.isFinite(selectedUserId)
    ? selectedUserId
    : usersList.rows[0]?.id;
  const [
    usersCount,
    medsCount,
    schedulesCount,
    lastUsers,
    lastMeds,
    alertsCount,
    alertsList,
    lowStockList,
  ] = await Promise.all([
      pool.query("SELECT COUNT(*) FROM users WHERE family_id = $1", [familyId]),
      pool.query("SELECT COUNT(*) FROM medicines WHERE family_id = $1 AND user_id = $2", [
        familyId,
        safeUserId,
      ]),
      pool.query(
        `SELECT COUNT(*) FROM schedules s
         JOIN medicines m ON m.id = s.medicine_id
         JOIN users u ON u.id = s.user_id
         WHERE m.family_id = $1 AND u.family_id = $1 AND s.user_id = $2`,
        [familyId, safeUserId]
      ),
      pool.query(
        `SELECT id, name, email, role, created_at
         FROM users
         WHERE family_id = $1
         ORDER BY created_at DESC
         LIMIT 5`,
        [familyId]
      ),
      pool.query(
        `SELECT id, name, dosage, current_stock, expiration_date, created_at
         FROM medicines
         WHERE family_id = $1 AND user_id = $2
         ORDER BY created_at DESC
         LIMIT 5`,
        [familyId, safeUserId]
      ),
      pool.query(
        `SELECT COUNT(*) FROM alerts
         WHERE family_id = $1 AND read_at IS NULL`,
        [familyId]
      ),
      pool.query(
        `SELECT type, level, message, created_at, med_name, med_dosage, dose_time, alert_date
         FROM alerts
         WHERE family_id = $1
         ORDER BY created_at DESC
         LIMIT 6`,
        [familyId]
      ),
      pool.query(
        `SELECT name, dosage, current_stock
         FROM medicines
         WHERE family_id = $1 AND user_id = $2 AND current_stock <= 10
         ORDER BY current_stock ASC
         LIMIT 6`,
        [familyId, safeUserId]
      ),
    ]);

  res.send(`
    <!doctype html>
    <html lang="es">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Dashboard Backend</title>
        <style>
          :root {
            color-scheme: light;
            --bg: #F6F8FC;
            --card: #FFFFFF;
            --ink: #0F172A;
            --muted: #475569;
            --border: #E2E8F0;
            --accent: #2563EB;
            --success: #16A34A;
            --warning: #F59E0B;
            --danger: #DC2626;
          }
          * { box-sizing: border-box; }
          body { margin:0; font-family: "Inter", Arial, sans-serif; background:var(--bg); color:var(--ink); }
          a { color:inherit; text-decoration:none; }
          .app { display:flex; min-height:100vh; }
          .sidebar { width:260px; background:#fff; border-right:1px solid var(--border); padding:20px 16px; position:sticky; top:0; height:100vh; }
          .sidebar h4 { margin:18px 0 8px; font-size:12px; text-transform:uppercase; letter-spacing:.08em; color:var(--muted); }
          .nav { display:flex; flex-direction:column; gap:6px; }
          .nav a { display:flex; align-items:center; gap:10px; padding:10px 12px; border-radius:12px; color:var(--ink); }
          .nav a.active { background:#EEF2FF; color:#1E3A8A; border-left:3px solid var(--accent); padding-left:9px; }
          .main { flex:1; display:flex; flex-direction:column; }
          .topbar { position:sticky; top:0; z-index:10; background:#fff; border-bottom:1px solid var(--border); height:64px; display:flex; align-items:center; justify-content:space-between; padding:0 24px; }
          .brand { font-weight:800; letter-spacing:.08em; font-size:14px; }
          .breadcrumb { font-size:14px; color:var(--muted); margin-left:8px; }
          .search { flex:1; max-width:420px; margin:0 24px; }
          .search input { width:100%; padding:8px 12px; border:1px solid var(--border); border-radius:12px; }
          .chip { display:inline-flex; align-items:center; gap:6px; padding:6px 12px; border-radius:999px; background:#E7F7ED; color:#166534; font-weight:600; font-size:12px; }
          .top-actions { display:flex; align-items:center; gap:12px; }
          .icon-btn { border:1px solid var(--border); background:#fff; border-radius:12px; padding:6px 10px; font-size:12px; }
          .menu { position:relative; }
          .menu summary { list-style:none; cursor:pointer; border:1px solid var(--border); border-radius:12px; padding:6px 10px; font-size:12px; }
          .menu summary::-webkit-details-marker { display:none; }
          .menu .menu-panel { position:absolute; right:0; top:38px; background:#fff; border:1px solid var(--border); border-radius:12px; padding:8px; min-width:160px; box-shadow:0 12px 24px -18px rgba(15,23,42,.4); }
          .menu .menu-panel a { display:block; padding:8px 10px; border-radius:8px; }
          .menu .menu-panel a:hover { background:#F1F5F9; }
          .content { padding:24px; }
          .card { background:var(--card); border:1px solid var(--border); border-radius:16px; padding:16px; box-shadow:0 8px 20px -18px rgba(15,23,42,.35); }
          .context { display:flex; align-items:center; justify-content:space-between; gap:16px; flex-wrap:wrap; }
          .context .left { min-width:240px; }
          .context label { font-size:12px; color:var(--muted); text-transform:uppercase; letter-spacing:.08em; }
          .context select, .context input { margin-top:6px; padding:8px 10px; border:1px solid var(--border); border-radius:12px; width:100%; }
          .btn { display:inline-flex; align-items:center; justify-content:center; padding:10px 16px; border-radius:12px; font-weight:600; border:1px solid transparent; }
          .btn.primary { background:var(--accent); color:#fff; }
          .btn.outline { border-color:var(--border); background:#fff; color:var(--ink); }
          .chip-row { display:flex; gap:8px; flex-wrap:wrap; }
          .chip-lite { padding:6px 10px; border-radius:999px; border:1px solid var(--border); font-size:12px; color:var(--muted); }
          .kpis { display:grid; grid-template-columns:repeat(12, 1fr); gap:16px; margin-top:16px; }
          .kpi { grid-column: span 3; }
          .kpi .title { font-size:11px; text-transform:uppercase; letter-spacing:.08em; color:var(--muted); }
          .kpi .value { font-size:24px; font-weight:700; margin:6px 0; }
          .kpi .meta { font-size:12px; color:var(--muted); }
          .kpi .action { margin-top:8px; font-size:12px; color:#1d4ed8; }
          .panels { display:grid; grid-template-columns:repeat(12, 1fr); gap:16px; margin-top:16px; }
          .panel-wide { grid-column: span 8; }
          .panel-narrow { grid-column: span 4; }
          .panel-title { font-size:16px; font-weight:700; margin:0 0 8px; }
          .list { display:flex; flex-direction:column; gap:10px; }
          .list-item { padding:10px; border:1px solid var(--border); border-radius:12px; }
          .badge { font-size:11px; padding:3px 8px; border-radius:999px; display:inline-flex; align-items:center; gap:6px; }
          .badge.critical { background:#FEE2E2; color:#991B1B; }
          .badge.warn { background:#FEF3C7; color:#92400E; }
          .badge.info { background:#DBEAFE; color:#1E3A8A; }
          .empty { font-size:12px; color:var(--muted); }
          @media (max-width: 1024px) {
            .sidebar { display:none; }
            .kpi { grid-column: span 6; }
            .panel-wide, .panel-narrow { grid-column: span 12; }
          }
          @media (max-width: 720px) {
            .topbar { padding:0 16px; }
            .search { display:none; }
            .kpi { grid-column: span 12; }
            .context { flex-direction:column; align-items:stretch; }
          }
        </style>
      </head>
      <body>
        <div class="app">
          <aside class="sidebar">
            <div class="brand">ELDERCARE_V2</div>
            <h4>Gestión</h4>
            <nav class="nav">
              <a class="active" href="/dashboard">🏠 Panel</a>
              <a href="/admin/user-new">👤 Pacientes</a>
              <a href="/admin/meds-list">💊 Medicamentos</a>
              <a href="/admin/alerts">🔔 Alertas</a>
              <a href="/admin/dose-requests">🩺 Cambios de dosis</a>
            </nav>
            <h4>Documentos</h4>
            <nav class="nav">
              <a href="/admin/medical-records">📁 Historial médico</a>
              <a href="/admin/import">⬆ Importaciones</a>
            </nav>
            <h4>Sistema</h4>
            <nav class="nav">
              <a href="/admin/settings">⚙ Ajustes</a>
            </nav>
          </aside>
          <div class="main">
            <header class="topbar">
              <div style="display:flex; align-items:center; gap:8px;">
                <div class="brand">ELDERCARE_V2</div>
                <div class="breadcrumb">Panel de control</div>
              </div>
              <div class="search">
                <input placeholder="Buscar paciente, medicamento o alerta" />
              </div>
              <div class="top-actions">
                <span class="chip">● Sincronizado</span>
                <button class="icon-btn">🔔</button>
                <details class="menu">
                  <summary>👤 ${escapeHtml(req.user.name || "Admin")}</summary>
                  <div class="menu-panel">
                    <a href="/admin/user-edit/${safeUserId}">Perfil</a>
                    <a href="/admin/settings">Ajustes</a>
                    <a href="/admin/logout">Cerrar sesión</a>
                  </div>
                </details>
              </div>
            </header>
            <main class="content">
              <div class="card context">
                <div class="left">
                  <label>Paciente activo</label>
                  <form method="GET" action="/dashboard">
                    <select name="user_id">
                      ${
                        usersList.rows.length
                          ? usersList.rows
                              .map(
                                (u) =>
                                  `<option value="${u.id}" ${
                                    u.id === safeUserId ? "selected" : ""
                                  }>${escapeHtml(u.name)} · ${escapeHtml(u.email)}</option>`
                              )
                              .join("")
                          : `<option value="">Sin usuarios</option>`
                      }
                    </select>
                  </form>
                </div>
                <div class="chip-row">
                  <span class="chip-lite">Alertas ${alertsCount.rows[0].count}</span>
                  <span class="chip-lite">Inventario ${medsCount.rows[0].count}</span>
                  <span class="chip-lite">Usuarios ${usersCount.rows[0].count}</span>
                </div>
                <div style="display:flex; gap:10px; align-items:center;">
                  <a class="btn primary" href="/admin/user-edit/${safeUserId}">Ver ficha</a>
                  <details class="menu">
                    <summary class="btn outline">Acciones ▾</summary>
                    <div class="menu-panel">
                      <a href="/admin/user-new">Nuevo paciente</a>
                      <a href="/admin/alerts">Crear alerta</a>
                      <a href="/admin/import">Importar</a>
                      <a href="/admin/medical-records">Ver historial</a>
                    </div>
                  </details>
                </div>
              </div>

              <div class="kpis">
                <div class="card kpi">
                  <div class="title">Sesión activa</div>
                  <div class="value">${escapeHtml(req.user.email || "admin")}</div>
                  <div class="meta">${escapeHtml(req.user.role || "admin")}</div>
                  <div class="action">Usuario actual</div>
                </div>
                <div class="card kpi">
                  <div class="title">Alertas activas</div>
                  <div class="value">${alertsCount.rows[0].count}</div>
                  <div class="meta">Pendientes de revisión</div>
                  <a class="action" href="/admin/alerts">Ver alertas</a>
                </div>
                <div class="card kpi">
                  <div class="title">Inventario total</div>
                  <div class="value">${medsCount.rows[0].count}</div>
                  <div class="meta">Paciente activo</div>
                  <a class="action" href="/admin/meds-list">Gestionar inventario</a>
                </div>
                <div class="card kpi">
                  <div class="title">Usuarios activos</div>
                  <div class="value">${usersCount.rows[0].count}</div>
                  <div class="meta">Familia ${familyId}</div>
                  <a class="action" href="/admin/reminders/run">Recordatorio semanal</a>
                </div>
              </div>

              <div class="panels">
                <div class="card panel-wide">
                  <h2 class="panel-title">Alertas críticas</h2>
                  <div class="list">
                    ${
                      alertsList.rows.length
                        ? alertsList.rows
                            .map((row) => {
                              const level = row.level || "info";
                              const badgeClass =
                                level === "warning"
                                  ? "warn"
                                  : level === "critical"
                                  ? "critical"
                                  : "info";
                              const badgeLabel =
                                level === "warning"
                                  ? "Aviso"
                                  : level === "critical"
                                  ? "Crítico"
                                  : "Info";
                              const meta = [
                                row.med_name || "",
                                row.med_dosage || "",
                                row.dose_time || "",
                                row.alert_date ? formatDateOnlyDisplay(row.alert_date) : "",
                              ]
                                .filter(Boolean)
                                .join(" · ");
                              return `<div class="list-item">
                                <div style="display:flex; justify-content:space-between; align-items:center;">
                                  <strong>${escapeHtml(row.message || "Alerta")}</strong>
                                  <span class="badge ${badgeClass}">${badgeLabel}</span>
                                </div>
                                <div class="meta">${escapeHtml(meta || "Sin detalles")}</div>
                              </div>`;
                            })
                            .join("")
                        : `<div class="empty">No hay alertas críticas en este momento.</div>`
                    }
                  </div>
                </div>
                <div class="card panel-narrow">
                  <h2 class="panel-title">Inventario bajo stock</h2>
                  <div class="list">
                    ${
                      lowStockList.rows.length
                        ? lowStockList.rows
                            .map(
                              (row) => `<div class="list-item">
                                <strong>${escapeHtml(row.name)}</strong>
                                <div class="meta">${escapeHtml(row.dosage || "N/A")} · Stock ${row.current_stock}</div>
                              </div>`
                            )
                            .join("")
                        : `<div class="empty">Sin medicamentos críticos para este paciente.</div>`
                    }
                  </div>
                  <div style="margin-top:10px;">
                    <a class="btn outline" href="/admin/meds-list">Ver inventario</a>
                  </div>
                </div>
              </div>
            </main>
          </div>
        </div>
      </body>
    </html>
  `);

});

// =============================================================================
// ADMIN USERS HTML
// =============================================================================
app.get("/admin/user-new", requireRoleHtml(["admin", "superuser"]), (_req, res) => {
  res.send(`
    <!doctype html>
    <html lang="es">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Nuevo Usuario</title>
        <style>
          body { font-family: Inter, Arial, sans-serif; background:#f5f7fb; margin:0; padding:40px; }
          .card { max-width:520px; margin:0 auto; background:#fff; border-radius:20px; padding:24px; box-shadow:0 20px 40px -30px rgba(15,23,42,.4); }
          h1 { font-size:20px; margin:0 0 8px; }
          label { display:block; font-size:13px; color:#64748b; margin-top:12px; }
          input, select { width:100%; border:1px solid #e2e8f0; border-radius:14px; padding:12px 14px; margin-top:6px; }
          button { width:100%; margin-top:18px; background:#2563eb; color:#fff; border:0; border-radius:14px; padding:12px 14px; font-weight:600; }
          a { color:#2563eb; text-decoration:none; font-size:13px; }
        </style>
      </head>
      <body>
        <div class="card">
          <h1>Nuevo usuario</h1>
          <form method="POST" action="/admin/user-create">
            <label>Nombre</label>
            <input name="first_name" required />
            <label>Apellido</label>
            <input name="last_name" required />
            <label>Fecha de nacimiento</label>
            <input name="birth_date" type="date" />
            <label>Calle</label>
            <input name="street" />
            <label>Número</label>
            <input name="house_number" />
            <label>Código postal</label>
            <input name="postal_code" />
            <label>Ciudad</label>
            <input name="city" />
            <label>Email</label>
            <input name="email" type="email" required />
            <h2 style="margin-top:18px; font-size:14px;">Médico de cabecera</h2>
            <label>Nombre</label>
            <input name="doctor_first_name" />
            <label>Apellido</label>
            <input name="doctor_last_name" />
            <label>Calle</label>
            <input name="doctor_street" />
            <label>Número</label>
            <input name="doctor_house_number" />
            <label>Código postal</label>
            <input name="doctor_postal_code" />
            <label>Ciudad</label>
            <input name="doctor_city" />
            <label>Email</label>
            <input name="doctor_email" type="email" />
            <label>Teléfono</label>
            <input name="doctor_phone" />
            <label>Password temporal</label>
            <input name="password" type="password" value="${DEFAULT_TEMP_PASSWORD}" required />
            <label>Rol</label>
            <select name="role">
              <option value="user">user</option>
              <option value="admin">admin</option>
              <option value="superuser">superuser</option>
            </select>
            <button type="submit">Crear usuario</button>
          </form>
          <p><a href="/dashboard">Volver al dashboard</a></p>
        </div>
      </body>
    </html>
  `);
});

app.post("/admin/user-create", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const {
    first_name,
    last_name,
    birth_date,
    street,
    house_number,
    postal_code,
    city,
    email,
    password,
    role,
    doctor_first_name,
    doctor_last_name,
    doctor_email,
    doctor_phone,
    doctor_street,
    doctor_house_number,
    doctor_postal_code,
    doctor_city,
  } = req.body || {};
  const safeRole = ["admin", "superuser", "user"].includes(role) ? role : "user";
  const finalName = buildUserName(null, first_name, last_name);
  if (!finalName || !email || !password) {
    return res.redirect("/admin/user-new");
  }
  try {
    const tempPassword = password || DEFAULT_TEMP_PASSWORD;
    const hashed = await bcrypt.hash(tempPassword, 10);
    const result = await pool.query(
      `INSERT INTO users (family_id, name, first_name, last_name, birth_date, street, house_number, postal_code, city, email, password_hash, role, must_change_password)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, true)
       RETURNING id`,
      [
        familyId,
        finalName,
        first_name || null,
        last_name || null,
        birth_date || null,
        street || null,
        house_number || null,
        postal_code || null,
        city || null,
        email,
        hashed,
        safeRole,
      ]
    );
    if (
      doctor_first_name ||
      doctor_last_name ||
      doctor_email ||
      doctor_phone ||
      doctor_street ||
      doctor_house_number ||
      doctor_postal_code ||
      doctor_city
    ) {
      await pool.query(
        `INSERT INTO doctors (family_id, user_id, first_name, last_name, email, phone, street, house_number, postal_code, city)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
         ON CONFLICT (family_id, user_id) DO UPDATE SET
           first_name = EXCLUDED.first_name,
           last_name = EXCLUDED.last_name,
           email = EXCLUDED.email,
           phone = EXCLUDED.phone,
           street = EXCLUDED.street,
           house_number = EXCLUDED.house_number,
           postal_code = EXCLUDED.postal_code,
           city = EXCLUDED.city`,
        [
          familyId,
          result.rows[0].id,
          doctor_first_name,
          doctor_last_name,
          doctor_email || null,
          doctor_phone || null,
          doctor_street || null,
          doctor_house_number || null,
          doctor_postal_code || null,
          doctor_city || null,
        ]
      );
    }
    try {
      await sendWelcomeEmail(email, tempPassword);
    } catch (emailError) {
      return res.send(`
        <!doctype html>
        <html lang="es">
          <head>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1" />
            <title>Usuario creado</title>
            <style>
              body { font-family: Inter, Arial, sans-serif; background:#f4f7fb; margin:0; color:#0f172a; }
              .wrap { max-width:720px; margin:0 auto; padding:40px 20px; }
              .card { background:#fff; border-radius:22px; padding:24px; box-shadow:0 24px 48px -30px rgba(15,23,42,.4); }
              a { color:#2563eb; text-decoration:none; font-size:13px; }
            </style>
          </head>
          <body>
            <div class="wrap">
              <div class="card">
                <h1>Usuario creado</h1>
                <p>El usuario fue creado, pero no se pudo enviar el email.</p>
                <p>${escapeHtml(emailError.message)}</p>
                <p><a href="/dashboard">Volver</a></p>
              </div>
            </div>
          </body>
        </html>
      `);
    }
    return res.redirect("/dashboard");
  } catch (error) {
    const isDuplicate = error?.code === "23505";
    if (isDuplicate) {
      try {
        const existing = await pool.query(
          `SELECT id FROM users WHERE family_id = $1 AND email = $2`,
          [familyId, email]
        );
        if (existing.rows[0]?.id) {
          return res.redirect(`/admin/user-edit/${existing.rows[0].id}?exists=1`);
        }
      } catch {
        // si falla la búsqueda, mostramos error estándar
      }
    }
    const message = isDuplicate
      ? "El email ya existe en esta familia."
      : "No se pudo crear el usuario.";
    return res.send(`
      <!doctype html>
      <html lang="es">
        <head>
          <meta charset="utf-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1" />
          <title>Error al crear usuario</title>
          <style>
            body { font-family: Inter, Arial, sans-serif; background:#f4f7fb; margin:0; color:#0f172a; }
            .wrap { max-width:720px; margin:0 auto; padding:40px 20px; }
            .card { background:#fff; border-radius:22px; padding:24px; box-shadow:0 24px 48px -30px rgba(15,23,42,.4); }
            a { color:#2563eb; text-decoration:none; font-size:13px; }
          </style>
        </head>
        <body>
          <div class="wrap">
            <div class="card">
              <h1>Error al crear usuario</h1>
              <p>${message}</p>
              <p>${escapeHtml(error.message)}</p>
              <p><a href="/admin/user-new">Volver</a></p>
            </div>
          </div>
        </body>
      </html>
    `);
  }
});

app.get("/admin/user-edit/:id", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const id = Number(req.params.id);
  const [result, doctorResult] = await Promise.all([
    pool.query(
      `SELECT id, name, first_name, last_name, birth_date, street, house_number, postal_code, city, email, role
       FROM users WHERE id = $1 AND family_id = $2`,
      [id, familyId]
    ),
    pool.query(
      `SELECT * FROM doctors WHERE family_id = $1 AND user_id = $2`,
      [familyId, id]
    ),
  ]);
  if (result.rows.length === 0) {
    return res.redirect("/dashboard");
  }
  const user = result.rows[0];
  const doctor = doctorResult.rows[0] || {};
  res.send(`
    <!doctype html>
    <html lang="es">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Editar Usuario</title>
        <style>
          body { font-family: Inter, Arial, sans-serif; background:#f5f7fb; margin:0; padding:40px; }
          .card { max-width:520px; margin:0 auto; background:#fff; border-radius:20px; padding:24px; box-shadow:0 20px 40px -30px rgba(15,23,42,.4); }
          h1 { font-size:20px; margin:0 0 8px; }
          label { display:block; font-size:13px; color:#64748b; margin-top:12px; }
          input, select { width:100%; border:1px solid #e2e8f0; border-radius:14px; padding:12px 14px; margin-top:6px; }
          button { width:100%; margin-top:18px; background:#2563eb; color:#fff; border:0; border-radius:14px; padding:12px 14px; font-weight:600; }
          a { color:#2563eb; text-decoration:none; font-size:13px; }
        </style>
      </head>
      <body>
        <div class="card">
          <h1>Editar usuario</h1>
          <form method="POST" action="/admin/user-save">
            <input type="hidden" name="id" value="${user.id}" />
            <label>Nombre</label>
            <input name="first_name" value="${escapeHtml(user.first_name || "")}" required />
            <label>Apellido</label>
            <input name="last_name" value="${escapeHtml(user.last_name || "")}" required />
            <label>Fecha de nacimiento</label>
            <input name="birth_date" type="date" value="${
              user.birth_date ? new Date(user.birth_date).toISOString().slice(0, 10) : ""
            }" />
            <label>Calle</label>
            <input name="street" value="${escapeHtml(user.street || "")}" />
            <label>Número</label>
            <input name="house_number" value="${escapeHtml(user.house_number || "")}" />
            <label>Código postal</label>
            <input name="postal_code" value="${escapeHtml(user.postal_code || "")}" />
            <label>Ciudad</label>
            <input name="city" value="${escapeHtml(user.city || "")}" />
            <label>Email</label>
            <input name="email" type="email" value="${escapeHtml(user.email)}" required />
            <label>Rol</label>
            <select name="role">
              <option value="user" ${user.role === "user" ? "selected" : ""}>user</option>
              <option value="admin" ${user.role === "admin" ? "selected" : ""}>admin</option>
              <option value="superuser" ${user.role === "superuser" ? "selected" : ""}>superuser</option>
            </select>
            <h2 style="margin-top:18px; font-size:14px;">Médico de cabecera</h2>
            <label>Nombre</label>
            <input name="doctor_first_name" value="${escapeHtml(doctor.first_name || "")}" />
            <label>Apellido</label>
            <input name="doctor_last_name" value="${escapeHtml(doctor.last_name || "")}" />
            <label>Email</label>
            <input name="doctor_email" type="email" value="${escapeHtml(doctor.email || "")}" />
            <label>Teléfono</label>
            <input name="doctor_phone" value="${escapeHtml(doctor.phone || "")}" />
            <label>Calle</label>
            <input name="doctor_street" value="${escapeHtml(doctor.street || "")}" />
            <label>Número de casa</label>
            <input name="doctor_house_number" value="${escapeHtml(doctor.house_number || "")}" />
            <label>Código postal</label>
            <input name="doctor_postal_code" value="${escapeHtml(doctor.postal_code || "")}" />
            <label>Ciudad</label>
            <input name="doctor_city" value="${escapeHtml(doctor.city || "")}" />
            <button type="submit">Guardar cambios</button>
          </form>
          <p><a href="/dashboard">Volver al dashboard</a></p>
        </div>
      </body>
    </html>
  `);
});

app.post("/admin/user-save", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const {
    id,
    first_name,
    last_name,
    birth_date,
    street,
    house_number,
    postal_code,
    city,
    email,
    role,
    doctor_first_name,
    doctor_last_name,
    doctor_email,
    doctor_phone,
    doctor_street,
    doctor_house_number,
    doctor_postal_code,
    doctor_city,
  } = req.body || {};
  const safeRole = ["admin", "superuser", "user"].includes(role) ? role : "user";
  const finalName = buildUserName(null, first_name, last_name);
  await pool.query(
    `UPDATE users
     SET name = $1,
         first_name = $2,
         last_name = $3,
         birth_date = $4,
         street = $5,
         house_number = $6,
         postal_code = $7,
         city = $8,
         email = $9,
         role = $10
     WHERE id = $11 AND family_id = $12`,
    [
      finalName,
      first_name || null,
      last_name || null,
      birth_date || null,
      street || null,
      house_number || null,
      postal_code || null,
      city || null,
      email,
      safeRole,
      Number(id),
      familyId,
    ]
  );
  if (
    doctor_first_name ||
    doctor_last_name ||
    doctor_email ||
    doctor_phone ||
    doctor_street ||
    doctor_house_number ||
    doctor_postal_code ||
    doctor_city
  ) {
    await pool.query(
      `INSERT INTO doctors (family_id, user_id, first_name, last_name, email, phone, street, house_number, postal_code, city)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
       ON CONFLICT (family_id, user_id) DO UPDATE SET
         first_name = EXCLUDED.first_name,
         last_name = EXCLUDED.last_name,
         email = EXCLUDED.email,
         phone = EXCLUDED.phone,
         street = EXCLUDED.street,
         house_number = EXCLUDED.house_number,
         postal_code = EXCLUDED.postal_code,
         city = EXCLUDED.city`,
      [
        familyId,
        Number(id),
        doctor_first_name || null,
        doctor_last_name || null,
        doctor_email || null,
        doctor_phone || null,
        doctor_street || null,
        doctor_house_number || null,
        doctor_postal_code || null,
        doctor_city || null,
      ]
    );
  }
  res.redirect("/dashboard");
});

// =============================================================================
// ADMIN MEDS HTML (asignación por schedule)
// =============================================================================
app.get("/admin/meds/:id", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const userId = Number(req.params.id);
  const [userResult, medsResult, schedulesResult] = await Promise.all([
    pool.query(`SELECT id, name, email FROM users WHERE id = $1 AND family_id = $2`, [
      userId,
      familyId,
    ]),
    pool.query(
      `SELECT id, name, dosage FROM medicines WHERE family_id = $1 AND user_id = $2 ORDER BY name ASC`,
      [familyId, userId]
    ),
    pool.query(
      `SELECT s.id, s.dose_time, s.frequency, s.start_date, s.end_date, m.name AS medicine_name
       FROM schedules s
       JOIN medicines m ON m.id = s.medicine_id
       WHERE s.user_id = $1 AND m.family_id = $2
       ORDER BY s.id DESC`,
      [userId, familyId]
    ),
  ]);
  if (userResult.rows.length === 0) {
    return res.redirect("/dashboard");
  }
  const user = userResult.rows[0];
  res.send(`
    <!doctype html>
    <html lang="es">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Medicinas del usuario</title>
        <style>
          body { font-family: Inter, Arial, sans-serif; background:#f5f7fb; margin:0; padding:40px; }
          .card { max-width:720px; margin:0 auto 18px; background:#fff; border-radius:20px; padding:24px; box-shadow:0 20px 40px -30px rgba(15,23,42,.4); }
          h1 { font-size:20px; margin:0 0 8px; }
          label { display:block; font-size:13px; color:#64748b; margin-top:12px; }
          input, select { width:100%; border:1px solid #e2e8f0; border-radius:14px; padding:12px 14px; margin-top:6px; }
          button { width:100%; margin-top:18px; background:#2563eb; color:#fff; border:0; border-radius:14px; padding:12px 14px; font-weight:600; }
          table { width:100%; border-collapse:collapse; margin-top:12px; }
          th, td { text-align:left; padding:10px 8px; font-size:13px; }
          tr + tr td { border-top:1px solid #e2e8f0; }
          a { color:#2563eb; text-decoration:none; font-size:13px; }
        </style>
      </head>
      <body>
        <div class="card">
          <h1>Medicinas de ${escapeHtml(user.name)}</h1>
          <p>${escapeHtml(user.email)}</p>
          <form method="POST" action="/admin/meds-add/${user.id}">
            <label>Medicina</label>
            <select name="medicine_id" required>
              ${
                medsResult.rows.length
                  ? medsResult.rows
                      .map(
                        (med) =>
                          `<option value="${med.id}">${escapeHtml(med.name)} · ${escapeHtml(
                            med.dosage
                          )}</option>`
                      )
                      .join("")
                  : `<option value="">No hay medicinas</option>`
              }
            </select>
            <label>Hora</label>
            <input name="dose_time" type="time" value="08:00" required />
            <label>Frecuencia</label>
            <input name="frequency" placeholder="Diario" required />
            <label>Inicio (opcional)</label>
            <input name="start_date" type="date" />
            <label>Fin (opcional)</label>
            <input name="end_date" type="date" />
            <button type="submit">Asignar medicina</button>
          </form>
        </div>

        <div class="card">
          <h1>Programaciones activas</h1>
          <table>
            <thead>
              <tr>
                <th>Medicina</th>
                <th>Hora</th>
                <th>Frecuencia</th>
                <th>Desde</th>
                <th>Hasta</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              ${
                schedulesResult.rows.length
                  ? schedulesResult.rows
                      .map(
                        (row) => `
                  <tr>
                    <td>${escapeHtml(row.medicine_name)}</td>
                    <td>${escapeHtml(row.dose_time)}</td>
                    <td>${escapeHtml(row.frequency)}</td>
                    <td>${row.start_date ? escapeHtml(row.start_date) : "-"}</td>
                    <td>${row.end_date ? escapeHtml(row.end_date) : "-"}</td>
                    <td><a href="/admin/meds-del/${row.id}/${user.id}">Eliminar</a></td>
                  </tr>`
                      )
                      .join("")
                  : `<tr><td colspan="6">Sin programaciones</td></tr>`
              }
            </tbody>
          </table>
          <p><a href="/dashboard">Volver al dashboard</a></p>
        </div>
      </body>
    </html>
  `);
});

app.post("/admin/meds-add/:id", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const userId = Number(req.params.id);
  const { medicine_id, dose_time, frequency, start_date, end_date } = req.body || {};
  const med = await pool.query(
    `SELECT id FROM medicines WHERE id = $1 AND family_id = $2 AND user_id = $3`,
    [Number(medicine_id), familyId, userId]
  );
  if (med.rows.length === 0) {
    return res.redirect(`/admin/meds/${userId}`);
  }
  await pool.query(
    `INSERT INTO schedules (medicine_id, user_id, dose_time, frequency, start_date, end_date)
     VALUES ($1, $2, $3, $4, $5, $6)`,
    [Number(medicine_id), userId, dose_time, frequency, start_date || null, end_date || null]
  );
  res.redirect(`/admin/meds/${userId}`);
});

app.get("/admin/meds-del/:mid/:uid", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const scheduleId = Number(req.params.mid);
  const userId = Number(req.params.uid);
  await pool.query(
    `DELETE FROM schedules s
     USING medicines m, users u
     WHERE s.id = $1 AND s.user_id = $2
       AND s.medicine_id = m.id AND u.id = s.user_id
       AND m.family_id = $3 AND u.family_id = $3`,
    [scheduleId, userId, familyId]
  );
  res.redirect(`/admin/meds/${userId}`);
});

// =============================================================================
// ADMIN MEDICINES CRUD (editable manual)
// =============================================================================
app.get("/admin/meds-list", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const query = (req.query?.q || "").trim();
  const userId = Number(req.query?.user_id || 0);
  const reviewOnly = req.query?.review === "1";
  const deletedCount = Number(req.query?.deleted || 0);
  const showDeleted = req.query?.reset === "1";
  const users = await pool.query(
    `SELECT id, name, email FROM users WHERE family_id = $1 ORDER BY name ASC`,
    [familyId]
  );
  const params = [familyId];
  let where = "WHERE family_id = $1";
  if (query) {
    params.push(`%${query}%`);
    where += " AND (name ILIKE $2 OR dosage ILIKE $2)";
  }
  if (userId) {
    params.push(userId);
    const idx = params.length;
    where += ` AND user_id = $${idx}`;
  }
  if (reviewOnly) {
    where += " AND (current_stock = 0 OR dosage = 'N/A' OR expiration_date IS NULL)";
  }
  const meds = await pool.query(
    `SELECT id, name, dosage, current_stock, expiration_date
     FROM medicines
     ${where}
     ORDER BY name ASC`,
    params
  );
  res.send(`
    <!doctype html>
    <html lang="es">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Medicamentos</title>
        <style>
          body { font-family: Inter, Arial, sans-serif; background:#f5f7fb; margin:0; padding:40px; }
          .card { max-width:980px; margin:0 auto; background:#fff; border-radius:20px; padding:24px; box-shadow:0 20px 40px -30px rgba(15,23,42,.4); }
          h1 { font-size:20px; margin:0 0 8px; }
          table { width:100%; border-collapse:collapse; margin-top:12px; }
          th, td { text-align:left; padding:10px 8px; font-size:13px; }
          tr + tr td { border-top:1px solid #e2e8f0; }
          a { color:#2563eb; text-decoration:none; font-size:13px; }
          .actions { margin-top:12px; display:flex; gap:10px; }
          .btn { display:inline-flex; align-items:center; justify-content:center; padding:8px 14px; border-radius:12px; text-decoration:none; font-weight:600; background:#2563eb; color:#fff; }
          .btn.secondary { background:#e2e8f0; color:#0f172a; }
        </style>
      </head>
      <body>
        <div class="card">
          <h1>Medicamentos</h1>
          ${
            showDeleted
              ? `<p style="margin:6px 0 10px; color:#0f172a;">Se borraron ${Number.isFinite(
                  deletedCount
                )
                  ? deletedCount
                  : 0} medicamentos.</p>`
              : ""
          }
          <div class="actions">
            <a class="btn" href="/admin/meds-new">➕ Nuevo medicamento</a>
            <a class="btn secondary" href="/dashboard">← Volver</a>
          </div>
          <form method="GET" action="/admin/meds-list" style="margin-top:16px;">
            <input name="q" value="${escapeHtml(query)}" placeholder="Buscar por nombre o dosis" style="width:100%; border:1px solid #e2e8f0; border-radius:14px; padding:12px 14px;" />
            <select name="user_id" style="width:100%; margin-top:10px; border:1px solid #e2e8f0; border-radius:14px; padding:12px 14px;">
              <option value="">Todos los usuarios</option>
              ${
                users.rows
                  .map(
                    (u) =>
                      `<option value="${u.id}" ${u.id === userId ? "selected" : ""}>${escapeHtml(
                        u.name
                      )} · ${escapeHtml(u.email)}</option>`
                  )
                  .join("")
              }
            </select>
            <label style="display:block; margin-top:10px; font-size:12px; color:#64748b;">
              <input type="checkbox" name="review" value="1" ${reviewOnly ? "checked" : ""} />
              Mostrar solo pendientes de revisión
            </label>
            <button class="btn" type="submit" style="margin-top:10px;">Filtrar</button>
          </form>
          <table>
            <thead>
              <tr>
                <th>Nombre</th>
                <th>Dosis</th>
                <th>Stock</th>
                <th>Caducidad</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              ${
                meds.rows.length
                  ? meds.rows
                      .map(
                        (row) => `
                <tr>
                  <td>${escapeHtml(row.name)}</td>
                  <td>${escapeHtml(row.dosage)}</td>
                  <td>${escapeHtml(row.current_stock)}</td>
                  <td>${row.expiration_date ? escapeHtml(row.expiration_date) : "-"}</td>
                  <td>
                    <a href="/admin/meds-edit/${row.id}">Editar</a> ·
                    <a href="/admin/meds-delete/${row.id}">Eliminar</a>
                  </td>
                </tr>`
                      )
                      .join("")
                  : `<tr><td colspan="5">Sin medicamentos</td></tr>`
              }
            </tbody>
          </table>
        </div>
      </body>
    </html>
  `);
});

app.get("/admin/meds-new", requireRoleHtml(["admin", "superuser"]), async (_req, res) => {
  const users = await pool.query(
    `SELECT id, name, email FROM users WHERE family_id = $1 ORDER BY name ASC`,
    [_req.user.family_id]
  );
  res.send(`
    <!doctype html>
    <html lang="es">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Nuevo medicamento</title>
        <style>
          body { font-family: Inter, Arial, sans-serif; background:#f5f7fb; margin:0; padding:40px; }
          .card { max-width:520px; margin:0 auto; background:#fff; border-radius:20px; padding:24px; box-shadow:0 20px 40px -30px rgba(15,23,42,.4); }
          h1 { font-size:20px; margin:0 0 8px; }
          label { display:block; font-size:13px; color:#64748b; margin-top:12px; }
          input { width:100%; border:1px solid #e2e8f0; border-radius:14px; padding:12px 14px; margin-top:6px; }
          button { width:100%; margin-top:18px; background:#2563eb; color:#fff; border:0; border-radius:14px; padding:12px 14px; font-weight:600; }
          a { color:#2563eb; text-decoration:none; font-size:13px; }
        </style>
      </head>
      <body>
        <div class="card">
          <h1>Nuevo medicamento</h1>
          <form method="POST" action="/admin/meds-save">
            <label>Paciente</label>
            <select name="user_id" style="width:100%; border:1px solid #e2e8f0; border-radius:14px; padding:12px 14px; margin-top:6px;">
              ${
                users.rows.length
                  ? users.rows
                      .map(
                        (u) =>
                          `<option value="${u.id}">${escapeHtml(u.name)} · ${escapeHtml(
                            u.email
                          )}</option>`
                      )
                      .join("")
                  : `<option value="">Sin usuarios</option>`
              }
            </select>
            <label>Nombre</label>
            <input name="name" required />
            <label>Dosis</label>
            <input name="dosage" required />
            <label>Stock</label>
            <input name="current_stock" type="number" value="0" min="0" required />
            <label>Caducidad</label>
            <input name="expiration_date" type="date" />
            <button type="submit">Guardar</button>
          </form>
          <p><a href="/admin/meds-list">Volver</a></p>
        </div>
      </body>
    </html>
  `);
});

app.get("/admin/meds-edit/:id", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const id = Number(req.params.id);
  const result = await pool.query(
    `SELECT id, name, dosage, current_stock, expiration_date, user_id
     FROM medicines
     WHERE id = $1 AND family_id = $2`,
    [id, familyId]
  );
  if (result.rows.length === 0) {
    return res.redirect("/admin/meds-list");
  }
  const med = result.rows[0];
  res.send(`
    <!doctype html>
    <html lang="es">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Editar medicamento</title>
        <style>
          body { font-family: Inter, Arial, sans-serif; background:#f5f7fb; margin:0; padding:40px; }
          .card { max-width:520px; margin:0 auto; background:#fff; border-radius:20px; padding:24px; box-shadow:0 20px 40px -30px rgba(15,23,42,.4); }
          h1 { font-size:20px; margin:0 0 8px; }
          label { display:block; font-size:13px; color:#64748b; margin-top:12px; }
          input { width:100%; border:1px solid #e2e8f0; border-radius:14px; padding:12px 14px; margin-top:6px; }
          button { width:100%; margin-top:18px; background:#2563eb; color:#fff; border:0; border-radius:14px; padding:12px 14px; font-weight:600; }
          a { color:#2563eb; text-decoration:none; font-size:13px; }
        </style>
      </head>
      <body>
        <div class="card">
          <h1>Editar medicamento</h1>
          <form method="POST" action="/admin/meds-save">
            <input type="hidden" name="id" value="${med.id}" />
            <label>ID de usuario (paciente)</label>
            <input name="user_id" value="${escapeHtml(med.user_id || "")}" required />
            <label>Nombre</label>
            <input name="name" value="${escapeHtml(med.name)}" required />
            <label>Dosis</label>
            <input name="dosage" value="${escapeHtml(med.dosage)}" required />
            <label>Stock</label>
            <input name="current_stock" type="number" min="0" value="${escapeHtml(med.current_stock)}" required />
            <label>Caducidad</label>
            <input name="expiration_date" type="date" value="${med.expiration_date || ""}" />
            <button type="submit">Guardar cambios</button>
          </form>
          <p><a href="/admin/meds-list">Volver</a></p>
        </div>
      </body>
    </html>
  `);
});

app.post("/admin/meds-save", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const { id, name, dosage, current_stock, expiration_date, user_id } = req.body || {};
  const userId = Number(user_id);
  if (!name || !dosage || !Number.isFinite(userId)) {
    return res.redirect("/admin/meds-list");
  }
  if (id) {
    await pool.query(
      `UPDATE medicines
       SET name = $1, dosage = $2, current_stock = $3, expiration_date = $4, user_id = $5
       WHERE id = $6 AND family_id = $7`,
      [
        name,
        dosage,
        Number(current_stock || 0),
        expiration_date || null,
        userId,
        Number(id),
        familyId,
      ]
    );
    await logMedicineAudit(familyId, req.user.sub, Number(id), "update", "Edición manual");
  } else {
    const created = await pool.query(
      `INSERT INTO medicines (family_id, user_id, name, dosage, current_stock, expiration_date)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id`,
      [familyId, userId, name, dosage, Number(current_stock || 0), expiration_date || null]
    );
    await logMedicineAudit(
      familyId,
      req.user.sub,
      created.rows[0].id,
      "create",
      "Creación manual"
    );
  }
  res.redirect("/admin/meds-list");
});

app.get("/admin/meds-delete/:id", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const id = Number(req.params.id);
  await logMedicineAudit(familyId, req.user.sub, id, "delete", "Eliminación manual");
  await pool.query(`DELETE FROM medicines WHERE id = $1 AND family_id = $2`, [
    id,
    familyId,
  ]);
  res.redirect("/admin/meds-list");
});

// =============================================================================
// FAMILIES CRUD
// =============================================================================
app.post("/api/families", async (req, res) => {
  const { name } = req.body || {};
  if (!name) {
    return res.status(400).json({ error: "name es requerido" });
  }
  try {
    const result = await pool.query(
      `INSERT INTO families (name) VALUES ($1) RETURNING id, name, created_at`,
      [name]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/families", requireRole(["superuser"]), async (_req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, name, created_at FROM families ORDER BY id DESC`
    );
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/families/me", requireAuth, async (req, res) => {
  const familyId = req.user.family_id;
  try {
    const result = await pool.query(
      `SELECT id, name, created_at FROM families WHERE id = $1`,
      [familyId]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "familia no encontrada" });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put("/api/families/:id", requireRole(["superuser"]), async (req, res) => {
  const id = Number(req.params.id);
  const { name } = req.body || {};
  if (!Number.isFinite(id) || !name) {
    return res.status(400).json({ error: "id y name son requeridos" });
  }
  try {
    const result = await pool.query(
      `UPDATE families SET name = $1 WHERE id = $2 RETURNING id, name, created_at`,
      [name, id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "familia no encontrada" });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete("/api/families/:id", requireRole(["superuser"]), async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) {
    return res.status(400).json({ error: "id inválido" });
  }
  try {
    const result = await pool.query(
      `DELETE FROM families WHERE id = $1 RETURNING id`,
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "familia no encontrada" });
    }
    res.json({ ok: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// =============================================================================
// USERS CRUD
// =============================================================================
app.get("/api/users", requireRole(["admin", "superuser"]), async (req, res) => {
  const familyId = resolveFamilyScope(req);
  if (!familyId) {
    return res.status(400).json({ error: "family_id es requerido" });
  }
  try {
    const result = await pool.query(
      `SELECT id, family_id, name, first_name, last_name, street, house_number, postal_code, city, email, role, created_at
       FROM users
       WHERE family_id = $1
       ORDER BY id DESC`,
      [familyId]
    );
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/users", requireRole(["admin", "superuser"]), async (req, res) => {
  const familyId = resolveFamilyScope(req);
  const {
    name,
    first_name,
    last_name,
    street,
    house_number,
    postal_code,
    city,
    email,
    password,
    role,
  } = req.body || {};
  const safeRole = ["admin", "superuser", "user"].includes(role) ? role : "user";
  const finalName = buildUserName(name, first_name, last_name);
  if (!familyId || !finalName || !email || !password) {
    return res
      .status(400)
      .json({ error: "family_id, nombre, email y password son requeridos" });
  }
  try {
    const tempPassword = password || DEFAULT_TEMP_PASSWORD;
    const hashed = await bcrypt.hash(tempPassword, 10);
    const result = await pool.query(
      `INSERT INTO users (family_id, name, first_name, last_name, street, house_number, postal_code, city, email, password_hash, role)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
       RETURNING id, family_id, name, first_name, last_name, email, role, created_at, must_change_password`,
      [
        familyId,
        finalName,
        first_name || null,
        last_name || null,
        street || null,
        house_number || null,
        postal_code || null,
        city || null,
        email,
        hashed,
        safeRole,
      ]
    );
    await pool.query(
      `UPDATE users SET must_change_password = true WHERE id = $1`,
      [result.rows[0].id]
    );
    await sendWelcomeEmail(email, tempPassword);
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put("/api/users/:id", requireRole(["admin", "superuser"]), async (req, res) => {
  const familyId = resolveFamilyScope(req);
  const id = Number(req.params.id);
  const {
    name,
    first_name,
    last_name,
    street,
    house_number,
    postal_code,
    city,
    email,
    role,
  } = req.body || {};
  const safeRole = ["admin", "superuser", "user"].includes(role) ? role : null;
  const finalName = buildUserName(name, first_name, last_name);
  if (!familyId || !Number.isFinite(id) || !finalName || !email || !safeRole) {
    return res
      .status(400)
      .json({ error: "family_id, nombre, email y role son requeridos" });
  }
  try {
    const result = await pool.query(
      `UPDATE users
       SET name = $1,
           first_name = $2,
           last_name = $3,
           street = $4,
           house_number = $5,
           postal_code = $6,
           city = $7,
           email = $8,
           role = $9
       WHERE id = $10 AND family_id = $11
       RETURNING id, family_id, name, first_name, last_name, email, role, created_at`,
      [
        finalName,
        first_name || null,
        last_name || null,
        street || null,
        house_number || null,
        postal_code || null,
        city || null,
        email,
        safeRole,
        id,
        familyId,
      ]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "usuario no encontrado" });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete("/api/users/:id", requireRole(["admin", "superuser"]), async (req, res) => {
  const familyId = resolveFamilyScope(req);
  const id = Number(req.params.id);
  if (!familyId || !Number.isFinite(id)) {
    return res.status(400).json({ error: "family_id e id requeridos" });
  }
  try {
    const result = await pool.query(
      `DELETE FROM users WHERE id = $1 AND family_id = $2 RETURNING id`,
      [id, familyId]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "usuario no encontrado" });
    }
    res.json({ ok: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// =============================================================================
// MEDICINES CRUD
// =============================================================================
app.get("/api/medicines", requireAuth, async (req, res) => {
  const familyId = getFamilyId(req);
  const userId = Number(req.query.user_id || req.query.userId || req.user?.sub);
  if (!familyId) {
    return res.status(400).json({ error: "family_id es requerido" });
  }
  if (!Number.isFinite(userId)) {
    return res.status(400).json({ error: "user_id es requerido" });
  }

  try {
    const result = await pool.query(
      `SELECT id, family_id, name, dosage, current_stock, expiration_date, created_at
       FROM medicines
       WHERE family_id = $1 AND user_id = $2
       ORDER BY name ASC`,
      [familyId, userId]
    );
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/medicines/:id", requireAuth, async (req, res) => {
  const familyId = getFamilyId(req);
  const userId = Number(req.query.user_id || req.query.userId || req.user?.sub);
  const id = Number(req.params.id);
  if (!familyId) {
    return res.status(400).json({ error: "family_id es requerido" });
  }
  if (!Number.isFinite(userId)) {
    return res.status(400).json({ error: "user_id es requerido" });
  }
  if (!Number.isFinite(id)) {
    return res.status(400).json({ error: "id inválido" });
  }

  try {
    const result = await pool.query(
      `SELECT id, family_id, name, dosage, current_stock, expiration_date, created_at
       FROM medicines
       WHERE id = $1 AND family_id = $2 AND user_id = $3`,
      [id, familyId, userId]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "medicamento no encontrado" });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/medicines", requireRole(["admin", "superuser"]), async (req, res) => {
  const familyId = getFamilyId(req);
  const { name, dosage, current_stock, expiration_date, user_id } = req.body || {};
  const userId = Number(user_id);

  if (!familyId || !name || !dosage || !Number.isFinite(userId)) {
    return res
      .status(400)
      .json({ error: "family_id, user_id, name y dosage son requeridos" });
  }

  try {
    const result = await pool.query(
      `INSERT INTO medicines (family_id, user_id, name, dosage, current_stock, expiration_date)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id, family_id, user_id, name, dosage, current_stock, expiration_date, created_at`,
      [
        familyId,
        userId,
        name,
        dosage,
        Number(current_stock || 0),
        expiration_date || null,
      ]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put("/api/medicines/:id", requireRole(["admin", "superuser"]), async (req, res) => {
  const familyId = getFamilyId(req);
  const id = Number(req.params.id);
  const { name, dosage, current_stock, expiration_date, user_id } = req.body || {};
  const userId = Number(user_id);

  if (!familyId || !name || !dosage || !Number.isFinite(userId)) {
    return res
      .status(400)
      .json({ error: "family_id, user_id, name y dosage son requeridos" });
  }
  if (!Number.isFinite(id)) {
    return res.status(400).json({ error: "id inválido" });
  }

  try {
    const result = await pool.query(
      `UPDATE medicines
       SET name = $1,
           dosage = $2,
           current_stock = $3,
           expiration_date = $4,
           user_id = $5
       WHERE id = $6 AND family_id = $7
       RETURNING id, family_id, user_id, name, dosage, current_stock, expiration_date, created_at`,
      [
        name,
        dosage,
        Number(current_stock || 0),
        expiration_date || null,
        userId,
        id,
        familyId,
      ]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "medicamento no encontrado" });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete("/api/medicines/:id", requireRole(["admin", "superuser"]), async (req, res) => {
  const familyId = getFamilyId(req);
  const id = Number(req.params.id);
  const userId = Number(req.query.user_id || req.query.userId || req.body?.user_id);
  if (!familyId) {
    return res.status(400).json({ error: "family_id es requerido" });
  }
  if (!Number.isFinite(userId)) {
    return res.status(400).json({ error: "user_id es requerido" });
  }
  if (!Number.isFinite(id)) {
    return res.status(400).json({ error: "id inválido" });
  }

  try {
    const result = await pool.query(
      `DELETE FROM medicines
       WHERE id = $1 AND family_id = $2 AND user_id = $3
       RETURNING id`,
      [id, familyId, userId]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "medicamento no encontrado" });
    }
    res.json({ ok: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// =============================================================================
// SCHEDULES CRUD
// =============================================================================
app.get("/api/schedules", requireAuth, async (req, res) => {
  const familyId = getFamilyId(req);
  if (!familyId) {
    return res.status(400).json({ error: "family_id es requerido" });
  }
  try {
    const result = await pool.query(
      `SELECT s.id, s.medicine_id, s.user_id, s.dose_time, s.frequency, s.start_date, s.end_date, s.created_at
       FROM schedules s
       JOIN medicines m ON m.id = s.medicine_id
       JOIN users u ON u.id = s.user_id
       WHERE m.family_id = $1 AND u.family_id = $1 AND m.user_id = s.user_id
       ORDER BY s.id DESC`,
      [familyId]
    );
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/schedules", requireRole(["admin", "superuser"]), async (req, res) => {
  const familyId = getFamilyId(req);
  const { medicine_id, user_id, dose_time, frequency, start_date, end_date } = req.body || {};
  if (!familyId || !medicine_id || !user_id || !dose_time || !frequency) {
    return res.status(400).json({
      error: "family_id, medicine_id, user_id, dose_time y frequency son requeridos",
    });
  }
  try {
    const med = await pool.query(
      `SELECT id FROM medicines WHERE id = $1 AND family_id = $2 AND user_id = $3`,
      [Number(medicine_id), familyId, Number(user_id)]
    );
    if (med.rows.length === 0) {
      return res.status(404).json({ error: "medicamento no encontrado" });
    }
    const user = await pool.query(
      `SELECT id FROM users WHERE id = $1 AND family_id = $2`,
      [Number(user_id), familyId]
    );
    if (user.rows.length === 0) {
      return res.status(404).json({ error: "usuario no encontrado" });
    }

    const result = await pool.query(
      `INSERT INTO schedules (medicine_id, user_id, dose_time, frequency, start_date, end_date)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id, medicine_id, user_id, dose_time, frequency, start_date, end_date, created_at`,
      [Number(medicine_id), Number(user_id), dose_time, frequency, start_date || null, end_date || null]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put("/api/schedules/:id", requireRole(["admin", "superuser"]), async (req, res) => {
  const familyId = getFamilyId(req);
  const id = Number(req.params.id);
  const { medicine_id, user_id, dose_time, frequency, start_date, end_date } = req.body || {};
  if (!familyId || !Number.isFinite(id) || !medicine_id || !user_id || !dose_time || !frequency) {
    return res.status(400).json({
      error: "family_id, medicine_id, user_id, dose_time y frequency son requeridos",
    });
  }
  try {
    const schedule = await pool.query(
      `SELECT s.id
       FROM schedules s
       JOIN medicines m ON m.id = s.medicine_id
       JOIN users u ON u.id = s.user_id
       WHERE s.id = $1 AND m.family_id = $2 AND u.family_id = $2`,
      [id, familyId]
    );
    if (schedule.rows.length === 0) {
      return res.status(404).json({ error: "programación no encontrada" });
    }

    const result = await pool.query(
      `UPDATE schedules
       SET medicine_id = $1, user_id = $2, dose_time = $3, frequency = $4,
           start_date = $5, end_date = $6
       WHERE id = $7
       RETURNING id, medicine_id, user_id, dose_time, frequency, start_date, end_date, created_at`,
      [Number(medicine_id), Number(user_id), dose_time, frequency, start_date || null, end_date || null, id]
    );
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete("/api/schedules/:id", requireRole(["admin", "superuser"]), async (req, res) => {
  const familyId = getFamilyId(req);
  const id = Number(req.params.id);
  if (!familyId || !Number.isFinite(id)) {
    return res.status(400).json({ error: "family_id e id requeridos" });
  }
  try {
    const result = await pool.query(
      `DELETE FROM schedules s
       USING medicines m, users u
       WHERE s.id = $1 AND s.medicine_id = m.id AND s.user_id = u.id
         AND m.family_id = $2 AND u.family_id = $2
       RETURNING s.id`,
      [id, familyId]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "programación no encontrada" });
    }
    res.json({ ok: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// =============================================================================
// DOSE LOGS (registro de tomas)
// =============================================================================
app.get("/api/dose-logs", requireAuth, async (req, res) => {
  const scheduleId = Number(req.query.schedule_id || req.query.scheduleId);
  const familyId = getFamilyId(req);
  if (!Number.isFinite(scheduleId)) {
    return res.status(400).json({ error: "schedule_id es requerido" });
  }
  if (!familyId) {
    return res.status(400).json({ error: "family_id es requerido" });
  }

  try {
    const result = await pool.query(
      `SELECT id, schedule_id, taken_at, status
       FROM dose_logs dl
       JOIN schedules s ON s.id = dl.schedule_id
       JOIN medicines m ON m.id = s.medicine_id
       JOIN users u ON u.id = s.user_id
       WHERE dl.schedule_id = $1 AND m.family_id = $2 AND u.family_id = $2
       ORDER BY taken_at DESC`,
      [scheduleId, familyId]
    );
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/dose-logs", requireAuth, async (req, res) => {
  const { schedule_id, taken_at, status } = req.body || {};
  const familyId = getFamilyId(req);
  if (!schedule_id || !status) {
    return res
      .status(400)
      .json({ error: "schedule_id y status son requeridos" });
  }
  if (!familyId) {
    return res.status(400).json({ error: "family_id es requerido" });
  }

  try {
    const schedule = await pool.query(
      `SELECT s.id
       FROM schedules s
       JOIN medicines m ON m.id = s.medicine_id
       JOIN users u ON u.id = s.user_id
       WHERE s.id = $1 AND m.family_id = $2 AND u.family_id = $2`,
      [Number(schedule_id), familyId]
    );
    if (schedule.rows.length === 0) {
      return res.status(404).json({ error: "programación no encontrada" });
    }
    const result = await pool.query(
      `INSERT INTO dose_logs (schedule_id, taken_at, status)
       VALUES ($1, COALESCE($2, NOW()), $3)
       RETURNING id, schedule_id, taken_at, status`,
      [Number(schedule_id), taken_at || null, status]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// =============================================================================
// MOBILE APP SUPPORT (meds by date + toggle)
// =============================================================================
app.get("/api/meds-by-date", requireAuth, async (req, res) => {
  const familyId = getFamilyId(req);
  const userId = Number(req.query.user_id || req.query.userId);
  const date = req.query.date;
  if (!familyId || !Number.isFinite(userId) || !date) {
    return res
      .status(400)
      .json({ error: "family_id, user_id y date son requeridos" });
  }

  try {
    await pool.query(
      `INSERT INTO schedules (medicine_id, user_id, dose_time, frequency, days_of_week)
       SELECT m.id, m.user_id, '08:00', '1', '1234567'
       FROM medicines m
       WHERE m.family_id = $1 AND m.user_id = $2
         AND NOT EXISTS (
           SELECT 1 FROM schedules s
           WHERE s.medicine_id = m.id AND s.user_id = m.user_id
         )`,
      [familyId, userId]
    );
    const dayToken = (() => {
      const day = new Date(date).getDay();
      const map = [7, 1, 2, 3, 4, 5, 6];
      return String(map[day]);
    })();
    const result = await pool.query(
      `SELECT
       s.id AS schedule_id,
       s.dose_time,
       s.frequency,
       m.name AS medicine_name,
       m.dosage,
       m.current_stock,
       s.days_of_week,
       dcr.requested_dosage,
       dcr.effective_date,
        COALESCE(
          (
            SELECT dl.status
            FROM dose_logs dl
            WHERE dl.schedule_id = s.id
              AND dl.taken_at::date = $3::date
            ORDER BY dl.taken_at DESC
            LIMIT 1
          ),
          'missed'
        ) AS last_status
       FROM schedules s
       JOIN medicines m ON m.id = s.medicine_id
       JOIN users u ON u.id = s.user_id
       LEFT JOIN LATERAL (
         SELECT requested_dosage, effective_date
         FROM dose_change_requests
         WHERE schedule_id = s.id AND status = 'pending'
         ORDER BY created_at DESC
         LIMIT 1
       ) dcr ON true
       WHERE s.user_id = $1 AND m.family_id = $2 AND u.family_id = $2
         AND m.user_id = s.user_id
         AND POSITION($4 IN COALESCE(s.days_of_week, '1234567')) > 0
         AND (s.start_date IS NULL OR $3::date >= s.start_date)
         AND (s.end_date IS NULL OR $3::date <= s.end_date)
       ORDER BY s.dose_time ASC`,
      [userId, familyId, date, dayToken]
    );

    const data = result.rows.map((row) => ({
      id: row.schedule_id,
      nombre: row.medicine_name,
      dosis: row.dosage,
      frecuencia: row.frequency,
      hora: row.dose_time,
      stock: row.current_stock,
      estado: row.last_status === "taken" ? "tomado" : "pendiente",
      pending_dose: row.requested_dosage ? true : false,
      requested_dosage: row.requested_dosage || null,
      effective_date: row.effective_date || null,
    }));

    res.json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/meds-toggle", requireAuth, async (req, res) => {
  const { schedule_id, status, family_id, date } = req.body || {};
  const familyId = Number(family_id || getFamilyId(req));
  const scheduleId = Number(schedule_id);
  const safeStatus = status === "tomado" ? "tomado" : "pendiente";
  const day = date || new Date().toISOString().slice(0, 10);
  const today = new Date().toISOString().slice(0, 10);

  if (!familyId || !Number.isFinite(scheduleId)) {
    return res.status(400).json({ error: "family_id y schedule_id son requeridos" });
  }
  if (day > today) {
    return res.status(400).json({ error: "no se puede confirmar tomas futuras" });
  }
  if (safeStatus !== "tomado") {
    return res.status(400).json({ error: "no se permite deshacer la toma" });
  }

  try {
    await pool.query("BEGIN");
    const schedule = await pool.query(
      `SELECT s.id, s.medicine_id, m.current_stock, m.user_id
       FROM schedules s
       JOIN medicines m ON m.id = s.medicine_id
       JOIN users u ON u.id = s.user_id
       WHERE s.id = $1 AND m.family_id = $2 AND u.family_id = $2 AND m.user_id = s.user_id`,
      [scheduleId, familyId]
    );
    if (schedule.rows.length === 0) {
      await pool.query("ROLLBACK");
      return res.status(404).json({ error: "programación no encontrada" });
    }

    const lastLog = await pool.query(
      `SELECT status
       FROM dose_logs
       WHERE schedule_id = $1 AND taken_at::date = $2::date
       ORDER BY taken_at DESC
       LIMIT 1`,
      [scheduleId, day]
    );
    const lastStatus = lastLog.rows[0]?.status || "missed";
    const desiredStatus = "taken";

    if (lastStatus === desiredStatus) {
      await pool.query("ROLLBACK");
      return res.json({ ok: true, status: safeStatus, stock: schedule.rows[0].current_stock });
    }

    const previousStock = schedule.rows[0].current_stock;
    if (lastStatus === "taken") {
      await pool.query("ROLLBACK");
      return res.json({ ok: true, status: "tomado", stock: previousStock });
    }
    const newStock = Math.max(0, previousStock - 1);

    await pool.query(
      `UPDATE medicines SET current_stock = $1 WHERE id = $2`,
      [newStock, schedule.rows[0].medicine_id]
    );

    await pool.query(
      `INSERT INTO dose_logs (schedule_id, taken_at, status)
       VALUES ($1, ($2)::date + CURRENT_TIME, $3)`,
      [scheduleId, day, desiredStatus]
    );

    await pool.query("COMMIT");
    if (previousStock > 10 && newStock <= 10) {
      const medRow = await pool.query(
        `SELECT name, dosage FROM medicines WHERE id = $1`,
        [schedule.rows[0].medicine_id]
      );
      const userRow = await pool.query(
        `SELECT id, name, email FROM users WHERE id = $1`,
        [req.user.sub]
      );
      const doctorRow = await pool.query(
        `SELECT email FROM doctors WHERE family_id = $1 AND user_id = $2`,
        [familyId, req.user.sub]
      );
      const medName = medRow.rows[0]?.name || "Medicamento";
      const patientName = userRow.rows[0]?.name || "Paciente";
      const emailSubject = "Stock bajo de medicamento";
      const emailBody = `<p>${escapeHtml(
        patientName
      )} tiene stock bajo de <strong>${escapeHtml(
        medName
      )}</strong> (${newStock} unidades).</p>`;
      await pool.query(
        `INSERT INTO alerts (family_id, user_id, type, level, message, med_name, med_dosage, alert_date)
         VALUES ($1, $2, 'low_stock', 'warning', $3, $4, $5, $6)`,
        [
          familyId,
          req.user.sub,
          `Stock bajo: ${medName} (${newStock})`,
          medName,
          medRow.rows[0]?.dosage || "N/A",
          new Date().toISOString().slice(0, 10),
        ]
      );
      await sendUserEmail(userRow.rows[0]?.email, emailSubject, emailBody);
      if (doctorRow.rows[0]?.email) {
        await sendUserEmail(doctorRow.rows[0]?.email, emailSubject, emailBody);
      }
      if (ADMIN_EMAIL) {
        await sendAdminAlertEmail(emailSubject, emailBody);
      }
    }
    res.json({ ok: true, status: safeStatus, stock: newStock });
  } catch (error) {
    await pool.query("ROLLBACK");
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/dose-change-requests", requireAuth, async (req, res) => {
  const familyId = getFamilyId(req);
  const scheduleId = Number(req.body?.schedule_id);
  const requestedDosage = String(req.body?.new_dosage || "").trim();
  const effectiveDate = normalizeDateOnly(req.body?.effective_date);
  if (!familyId || !Number.isFinite(scheduleId) || !requestedDosage) {
    return res.status(400).json({ error: "family_id, schedule_id y new_dosage son requeridos" });
  }
  try {
    const sched = await pool.query(
      `SELECT s.id, s.user_id, m.id AS medicine_id, m.dosage
       FROM schedules s
       JOIN medicines m ON m.id = s.medicine_id
       WHERE s.id = $1 AND m.family_id = $2`,
      [scheduleId, familyId]
    );
    if (!sched.rows.length) {
      return res.status(404).json({ error: "programación no encontrada" });
    }
    const row = sched.rows[0];
    if (Number(row.user_id) !== Number(req.user.sub)) {
      return res.status(403).json({ error: "sin permiso" });
    }
    await pool.query(
      `INSERT INTO dose_change_requests
       (family_id, user_id, schedule_id, medicine_id, current_dosage, requested_dosage, effective_date)
       VALUES ($1, $2, $3, $4, $5, $6, $7)`,
      [
        familyId,
        row.user_id,
        scheduleId,
        row.medicine_id,
        row.dosage || null,
        requestedDosage,
        effectiveDate || null,
      ]
    );
    res.json({ ok: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// =============================================================================
// IMPORT API
// =============================================================================
app.post("/api/import-meds", requireRole(["admin", "superuser"]), async (req, res) => {
  const familyId = getFamilyId(req);
  const { file_path, user_id, use_ocr, skip_name_check } = req.body || {};
  const userId = Number(user_id);
  if (!familyId || !file_path || !Number.isFinite(userId)) {
    return res
      .status(400)
      .json({ error: "family_id, file_path y user_id son requeridos" });
  }
  try {
    const result = await importMedsFromPdf(
      file_path,
      familyId,
      userId,
      !!use_ocr,
      skip_name_check === "1"
    );
    res.json({ ok: true, ...result });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete("/api/meds-reset", requireRole(["admin", "superuser"]), async (req, res) => {
  const familyId = getFamilyId(req);
  const userId = Number(req.body?.user_id);
  const confirm = String(req.body?.confirm || "").trim();
  if (!familyId) {
    return res.status(400).json({ error: "family_id es requerido" });
  }
  if (confirm !== "RESET") {
    return res.status(400).json({ error: "confirm debe ser RESET" });
  }
  if (!Number.isFinite(userId)) {
    return res.status(400).json({ error: "user_id es requerido" });
  }
  const snapshotResult = await pool.query(
    `SELECT id, name, dosage, current_stock, expiration_date, import_batch_id
     FROM medicines
     WHERE family_id = $1 AND user_id = $2
     ORDER BY id`,
    [familyId, userId]
  );
  const snapshot = snapshotResult.rows || [];
  await pool.query(
    `DELETE FROM dose_logs
     WHERE schedule_id IN (SELECT id FROM schedules WHERE user_id = $1)`,
    [userId]
  );
  await pool.query(`DELETE FROM schedules WHERE user_id = $1`, [userId]);
  await pool.query(`DELETE FROM medicines WHERE family_id = $1 AND user_id = $2`, [
    familyId,
    userId,
  ]);
  await pool.query(
    `INSERT INTO deletion_logs (family_id, user_id, deleted_count, snapshot)
     VALUES ($1, $2, $3, $4)`,
    [familyId, userId, snapshot.length, JSON.stringify(snapshot)]
  );
  await pool.query(`DELETE FROM alerts WHERE family_id = $1 AND user_id = $2`, [
    familyId,
    userId,
  ]);
  res.json({ ok: true });
});

// =============================================================================
// ALERTS API
// =============================================================================
app.get("/api/alerts", requireAuth, async (req, res) => {
  const familyId = getFamilyId(req);
  if (!familyId) {
    return res.status(400).json({ error: "family_id es requerido" });
  }
  try {
    const result = await pool.query(
      `SELECT id, type, level, message, created_at, med_name, med_dosage, dose_time, alert_date, schedule_id
       FROM alerts
       WHERE family_id = $1
         AND (user_id = $2 OR user_id IS NULL)
         AND read_at IS NULL
       ORDER BY created_at DESC`,
      [familyId, req.user.sub]
    );
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/alerts/read", requireAuth, async (req, res) => {
  const { alert_id } = req.body || {};
  const familyId = getFamilyId(req);
  if (!alert_id || !familyId) {
    return res.status(400).json({ error: "alert_id y family_id requeridos" });
  }
  await pool.query(
    `UPDATE alerts SET read_at = NOW()
     WHERE id = $1 AND family_id = $2 AND (user_id = $3 OR user_id IS NULL)`,
    [Number(alert_id), familyId, req.user.sub]
  );
  res.json({ ok: true });
});

// =============================================================================
// DOCTOR (info del médico de cabecera)
// =============================================================================
app.get("/api/doctor", requireAuth, async (req, res) => {
  const familyId = getFamilyId(req);
  const userId = Number(req.query.user_id || req.query.userId || req.user?.sub);
  if (!familyId || !Number.isFinite(userId)) {
    return res.status(400).json({ error: "family_id y user_id son requeridos" });
  }
  const result = await pool.query(
    `SELECT first_name, last_name, email, phone, street, house_number, postal_code, city
     FROM doctors
     WHERE family_id = $1 AND user_id = $2`,
    [familyId, userId]
  );
  if (result.rows.length === 0) {
    return res.status(404).json({ error: "médico no encontrado" });
  }
  res.json(result.rows[0]);
});

// =============================================================================
// PDF CRÍTICOS
// =============================================================================
app.get("/admin/meds-critical/pdf", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const userId = Number(req.query.user_id || req.query.userId || req.user.sub);
  if (!Number.isFinite(userId)) {
    return res.redirect("/dashboard");
  }
  const patient = await pool.query(
    `SELECT name FROM users WHERE id = $1 AND family_id = $2`,
    [userId, familyId]
  );
  const meds = await pool.query(
    `SELECT name, dosage, current_stock
     FROM medicines
     WHERE family_id = $1 AND user_id = $2 AND current_stock <= 10
     ORDER BY current_stock ASC, name ASC`,
    [familyId, userId]
  );

  res.setHeader("Content-Type", "application/pdf");
  res.setHeader(
    "Content-Disposition",
    `attachment; filename="medicamentos_criticos_${userId}.pdf"`
  );

  const doc = new PDFDocument({ margin: 40 });
  doc.pipe(res);
  doc.fontSize(18).text("Medicamentos críticos", { align: "left" });
  doc.moveDown(0.5);
  doc.fontSize(12).text(`Paciente: ${patient.rows[0]?.name || "Paciente"}`);
  doc.text(`Fecha: ${formatDateOnlyDisplay(new Date())}`);
  doc.moveDown();
  if (!meds.rows.length) {
    doc.text("Sin medicamentos críticos (stock > 10).");
  } else {
    meds.rows.forEach((med) => {
      doc
        .fontSize(12)
        .text(`${med.name} · ${med.dosage || "N/A"} · Stock ${med.current_stock}`);
    });
  }
  doc.end();
});

// =============================================================================
// PUSH NOTIFICATIONS
// =============================================================================
app.get("/api/push/vapid", (_req, res) => {
  res.json({ publicKey: pushKeys.publicKey });
});

app.post("/api/push/subscribe", requireAuth, async (req, res) => {
  const familyId = getFamilyId(req);
  const sub = req.body || {};
  if (!familyId || !sub.endpoint || !sub.keys?.p256dh || !sub.keys?.auth) {
    return res.status(400).json({ error: "subscription inválida" });
  }
  await pool.query(
    `INSERT INTO push_subscriptions (user_id, family_id, endpoint, p256dh, auth)
     VALUES ($1, $2, $3, $4, $5)
     ON CONFLICT (user_id, endpoint) DO NOTHING`,
    [req.user.sub, familyId, sub.endpoint, sub.keys.p256dh, sub.keys.auth]
  );
  res.json({ ok: true });
});

app.post("/api/push/test", requireAuth, async (req, res) => {
  const familyId = getFamilyId(req);
  await sendPushToFamily(familyId, {
    title: "Recordatorio",
    body: "Tienes tomas pendientes.",
  });
  res.json({ ok: true });
});

// =============================================================================
// DAILY CHECKOUT (envío de mail cuando el plan del día se completa)
// =============================================================================
app.post("/api/daily-checkout", requireAuth, async (req, res) => {
  const { user_id, date, family_id } = req.body || {};
  const familyId = Number(family_id || getFamilyId(req));
  const userId = Number(user_id || req.user.sub);
  const day = date || new Date().toISOString().slice(0, 10);

  if (!familyId || !userId) {
    return res.status(400).json({ error: "family_id y user_id son requeridos" });
  }

  try {
    const dayToken = String((() => {
      const d = new Date(day).getDay();
      const map = [7, 1, 2, 3, 4, 5, 6];
      return map[d];
    })());

    const schedules = await pool.query(
      `SELECT s.id
       FROM schedules s
       JOIN medicines m ON m.id = s.medicine_id
       JOIN users u ON u.id = s.user_id
       WHERE s.user_id = $1 AND m.family_id = $2 AND u.family_id = $2
         AND POSITION($3 IN COALESCE(s.days_of_week, '1234567')) > 0
         AND (s.start_date IS NULL OR $4::date >= s.start_date)
         AND (s.end_date IS NULL OR $4::date <= s.end_date)`,
      [userId, familyId, dayToken, day]
    );

    if (schedules.rows.length === 0) {
      return res.json({ ok: true, message: "Sin programaciones para hoy" });
    }

    const taken = await pool.query(
      `SELECT COUNT(*) FROM dose_logs
       WHERE schedule_id = ANY($1) AND taken_at::date = $2::date AND status = 'taken'`,
      [schedules.rows.map((s) => s.id), day]
    );

    const total = schedules.rows.length;
    const takenCount = Number(taken.rows[0].count || 0);
    if (takenCount < total) {
      await sendPushToUser(userId, {
        title: "Tomas pendientes",
        body: `Te faltan ${total - takenCount} toma(s) hoy.`,
      });
      return res.json({ ok: false, message: "Plan incompleto" });
    }

    const existing = await pool.query(
      `SELECT id FROM daily_checkouts WHERE user_id = $1 AND day = $2::date`,
      [userId, day]
    );
    if (existing.rows.length > 0) {
      return res.json({ ok: true, message: "Checkout ya enviado" });
    }

    await pool.query(
      `INSERT INTO daily_checkouts (user_id, family_id, day)
       VALUES ($1, $2, $3::date)`,
      [userId, familyId, day]
    );

    const userResult = await pool.query(
      `SELECT email, name FROM users WHERE id = $1`,
      [userId]
    );

    const userEmail = userResult.rows[0]?.email;
    const userName = userResult.rows[0]?.name;
    const subject = "Plan diario completado";
    const html = `<p>${escapeHtml(
      userName || "Paciente"
    )} completó el plan del día ${day}.</p>`;

    if (mailTransport && userEmail) {
      await mailTransport.sendMail({
        from: process.env.SMTP_USER,
        to: userEmail,
        subject,
        html,
      });
    }
    if (ADMIN_EMAIL) {
      await sendAdminAlertEmail(subject, html);
    }

    res.json({ ok: true, message: "Checkout enviado" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

async function generateAlertsForFamily(familyId) {
  const lowStock = await pool.query(
    `SELECT id, name, dosage, current_stock, user_id
     FROM medicines
     WHERE family_id = $1 AND current_stock <= 10`,
    [familyId]
  );
  const today = new Date().toISOString().slice(0, 10);
  await pool.query(
    `DELETE FROM alerts
     WHERE family_id = $1 AND type = 'dose_due' AND alert_date = $2::date`,
    [familyId, today]
  );
  const dayToken = String((() => {
    const d = new Date(today).getDay();
    const map = [7, 1, 2, 3, 4, 5, 6];
    return map[d];
  })());
  const dueSchedules = await pool.query(
      `SELECT s.id, s.user_id, s.dose_time, u.name AS user_name, m.name AS med_name, m.dosage
     FROM schedules s
     JOIN users u ON u.id = s.user_id
     JOIN medicines m ON m.id = s.medicine_id
     WHERE u.family_id = $1 AND m.family_id = $1
       AND m.user_id = s.user_id
       AND POSITION($2 IN COALESCE(s.days_of_week, '1234567')) > 0
       AND (s.start_date IS NULL OR $3::date >= s.start_date)
       AND (s.end_date IS NULL OR $3::date <= s.end_date)`,
    [familyId, dayToken, today]
  );

  let created = 0;
  for (const med of lowStock.rows) {
    await pool.query(
      `INSERT INTO alerts (family_id, user_id, type, level, message, med_name, med_dosage, alert_date)
       VALUES ($1, $2, 'low_stock', 'warning', $3, $4, $5, $6)`,
      [
        familyId,
        med.user_id,
        `Stock bajo: ${med.name} (${med.current_stock})`,
        med.name,
        med.dosage || "N/A",
        new Date().toISOString().slice(0, 10),
      ]
    );
    created += 1;
  }

  for (const row of dueSchedules.rows) {
    const exists = await pool.query(
      `SELECT 1 FROM dose_logs
       WHERE schedule_id = $1 AND taken_at::date = $2::date AND status = 'taken'`,
      [row.id, today]
    );
    if (exists.rows.length === 0) {
      await pool.query(
        `INSERT INTO alerts (family_id, user_id, type, level, message, med_name, med_dosage, dose_time, alert_date, schedule_id)
         VALUES ($1, $2, 'dose_due', 'info', $3, $4, $5, $6, $7, $8)`,
        [
          familyId,
          row.user_id,
          `Toma pendiente: ${row.med_name} a las ${row.dose_time}`,
          row.med_name,
          row.dosage || "N/A",
          row.dose_time,
          today,
          row.id,
        ]
      );
      await sendPushToUser(row.user_id, {
        title: "Recordatorio de medicación",
        body: `Toma pendiente: ${row.med_name} a las ${row.dose_time}`,
      });
      created += 1;
    }
  }
  return created;
}

async function runAlertsJob() {
  try {
    const families = await pool.query(`SELECT id FROM families`);
    for (const row of families.rows) {
      await generateAlertsForFamily(row.id);
    }
  } catch (error) {
    console.error("ERROR: job alertas:", error.message);
  }
}

app.get("/admin/alerts/run", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const userId = Number(req.query?.user_id);
  const where = Number.isFinite(userId) ? "family_id = $1 AND user_id = $2" : "family_id = $1";
  const args = Number.isFinite(userId) ? [familyId, userId] : [familyId];
  const medicines = await pool.query(
    `SELECT id, name, dosage, current_stock, user_id
     FROM medicines
     WHERE ${where} AND current_stock <= $${args.length + 1}
     ORDER BY current_stock ASC`,
    [...args, LOW_STOCK_THRESHOLD]
  );
  for (const med of medicines.rows) {
    const message = `Stock bajo: ${med.name} (${med.dosage || "N/A"}) · ${med.current_stock}`;
    await pool.query(
      `INSERT INTO alerts (family_id, user_id, type, level, message)
       VALUES ($1, $2, 'stock_low', 'warning', $3)`,
      [familyId, med.user_id || null, message]
    );
  }
  if (medicines.rows.length) {
    const pdfBuffer = await buildCriticalMedsPdf(medicines.rows, {
      title: "Medicamentos críticos (stock bajo)",
    });
    await sendAdminAlertEmail(
      "Alertas de stock bajo",
      `<p>Se generaron ${medicines.rows.length} alertas de stock bajo.</p>
       <p>Adjunto: PDF con medicamentos críticos.</p>`,
      [
        {
          filename: "medicamentos_criticos.pdf",
          content: pdfBuffer,
        },
      ]
    );
  }
  return res.redirect("/admin/alerts");
});

app.post("/admin/alerts/run", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const created = await generateAlertsForFamily(familyId);
  await sendAdminAlertEmail(
    "Alertas de medicación",
    `<p>Se generaron ${created} alertas para la familia ${familyId}.</p>`
  );
  res.redirect("/admin/alerts");
});

app.get("/admin/alerts/test-email", requireRoleHtml(["admin", "superuser"]), async (_req, res) => {
  if (!mailTransport || !ADMIN_EMAIL) {
    return res.send(`
      <html lang="es"><body style="font-family:Inter,Arial,sans-serif; padding:24px;">
        <h2>SMTP no configurado</h2>
        <p>Faltan SMTP_HOST/SMTP_USER/SMTP_PASS o ADMIN_EMAIL.</p>
        <p><a href="/admin/alerts">Volver</a></p>
      </body></html>
    `);
  }
  try {
    const familyId = _req.user.family_id;
    const meds = await pool.query(
      `SELECT name, dosage, current_stock
       FROM medicines
       WHERE family_id = $1 AND current_stock <= $2
       ORDER BY current_stock ASC`,
      [familyId, LOW_STOCK_THRESHOLD]
    );
    const attachments = meds.rows.length
      ? [
          {
            filename: "medicamentos_criticos.pdf",
            content: await buildCriticalMedsPdf(meds.rows, {
              title: "Medicamentos críticos (prueba)",
            }),
          },
        ]
      : undefined;
    await sendAdminAlertEmail(
      "Prueba de correo",
      `<p>Este es un correo de prueba del sistema de alertas.</p>
       <p>Adjunto: PDF si hay medicamentos críticos.</p>`,
      attachments
    );
    return res.send(`
      <html lang="es"><body style="font-family:Inter,Arial,sans-serif; padding:24px;">
        <h2>Correo enviado</h2>
        <p>Se envió un email de prueba a ${ADMIN_EMAIL}.</p>
        <p><a href="/admin/alerts">Volver</a></p>
      </body></html>
    `);
  } catch (error) {
    return res.send(`
      <html lang="es"><body style="font-family:Inter,Arial,sans-serif; padding:24px;">
        <h2>Error al enviar</h2>
        <p>${escapeHtml(error.message)}</p>
        <p><a href="/admin/alerts">Volver</a></p>
      </body></html>
    `);
  }
});

app.get("/admin/alerts", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const users = await pool.query(
    `SELECT id, name, email FROM users WHERE family_id = $1 ORDER BY name ASC`,
    [familyId]
  );
  const alerts = await pool.query(
    `SELECT id, type, level, message, created_at, read_at
     FROM alerts
     WHERE family_id = $1
     ORDER BY created_at DESC
     LIMIT 50`,
    [familyId]
  );
  res.send(`
    <!doctype html>
    <html lang="es">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Alertas</title>
        <style>
          body { font-family: Inter, Arial, sans-serif; background:#f5f7fb; margin:0; padding:40px; }
          .card { max-width:900px; margin:0 auto; background:#fff; border-radius:20px; padding:24px; box-shadow:0 20px 40px -30px rgba(15,23,42,.4); }
          h1 { font-size:20px; margin:0 0 8px; }
          table { width:100%; border-collapse:collapse; margin-top:12px; }
          th, td { text-align:left; padding:10px 8px; font-size:13px; }
          tr + tr td { border-top:1px solid #e2e8f0; }
          .tag { padding:4px 10px; border-radius:999px; font-size:12px; font-weight:600; background:#e2e8f0; }
          .tag.warn { background:#fee2e2; color:#b91c1c; }
          .tag.info { background:#dbeafe; color:#1d4ed8; }
          a { color:#2563eb; text-decoration:none; font-size:13px; }
          .actions { margin-top:12px; display:flex; gap:10px; }
          .btn { display:inline-flex; align-items:center; justify-content:center; padding:8px 14px; border-radius:12px; text-decoration:none; font-weight:600; background:#2563eb; color:#fff; }
          .btn.secondary { background:#e2e8f0; color:#0f172a; }
        </style>
      </head>
      <body>
        <div class="card">
          <h1>Alertas</h1>
          <div class="actions">
            <a class="btn" href="/admin/alerts/run">⚠ Generar alertas</a>
            <a class="btn secondary" href="/admin/alerts/test-email">✉ Probar email</a>
            <a class="btn secondary" href="/dashboard">← Volver</a>
          </div>
          <form method="POST" action="/admin/alerts/clear" style="margin-top:12px; display:flex; gap:10px; align-items:center;">
            <select name="user_id" style="border:1px solid #e2e8f0; border-radius:12px; padding:8px 10px;">
              <option value="">Todas las alertas</option>
              ${
                users.rows.length
                  ? users.rows
                      .map(
                        (u) =>
                          `<option value="${u.id}">${escapeHtml(u.name)} · ${escapeHtml(
                            u.email
                          )}</option>`
                      )
                      .join("")
                  : `<option value="">Sin usuarios</option>`
              }
            </select>
            <button class="btn secondary" type="submit">Borrar alertas</button>
          </form>
          <table>
            <thead>
              <tr>
                <th>Tipo</th>
                <th>Mensaje</th>
                <th>Estado</th>
                <th>Fecha</th>
              </tr>
            </thead>
            <tbody>
              ${
                alerts.rows.length
                  ? alerts.rows
                      .map(
                        (row) => `
                <tr>
                  <td>${escapeHtml(row.type)}</td>
                  <td>${escapeHtml(row.message)}</td>
                  <td><span class="tag ${
                    row.level === "warning" ? "warn" : "info"
                  }">${row.read_at ? "Leída" : "Nueva"}</span></td>
                  <td>${formatDateTime(row.created_at)}</td>
                </tr>`
                      )
                      .join("")
                  : `<tr><td colspan="4">Sin alertas</td></tr>`
              }
            </tbody>
          </table>
        </div>
      </body>
    </html>
  `);
});

app.get("/admin/dose-requests", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const requests = await pool.query(
    `SELECT r.id, r.requested_dosage, r.effective_date, r.created_at,
            u.name AS user_name, u.email AS user_email,
            m.name AS med_name, m.dosage AS current_dosage,
            s.dose_time
     FROM dose_change_requests r
     JOIN users u ON u.id = r.user_id
     JOIN medicines m ON m.id = r.medicine_id
     JOIN schedules s ON s.id = r.schedule_id
     WHERE r.family_id = $1 AND r.status = 'pending'
     ORDER BY r.created_at DESC`,
    [familyId]
  );
  res.send(`
    <!doctype html>
    <html lang="es">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Cambios de dosis</title>
        <style>
          body { font-family: Inter, Arial, sans-serif; background:#f5f7fb; margin:0; padding:40px; }
          .card { max-width:980px; margin:0 auto; background:#fff; border-radius:20px; padding:24px; box-shadow:0 20px 40px -30px rgba(15,23,42,.4); }
          h1 { font-size:20px; margin:0 0 8px; }
          table { width:100%; border-collapse:collapse; margin-top:12px; }
          th, td { text-align:left; padding:10px 8px; font-size:13px; }
          tr + tr td { border-top:1px solid #e2e8f0; }
          .btn { display:inline-flex; align-items:center; justify-content:center; padding:8px 14px; border-radius:12px; text-decoration:none; font-weight:600; background:#2563eb; color:#fff; border:0; }
          .btn.secondary { background:#e2e8f0; color:#0f172a; }
          .btn.danger { background:#ef4444; color:#fff; }
          .actions { margin-top:12px; display:flex; gap:10px; }
        </style>
      </head>
      <body>
        <div class="card">
          <h1>Solicitudes de cambio de dosis</h1>
          <div class="actions">
            <a class="btn secondary" href="/dashboard">← Volver</a>
          </div>
          <table>
            <thead>
              <tr>
                <th>Paciente</th>
                <th>Medicamento</th>
                <th>Dosis actual</th>
                <th>Nueva dosis</th>
                <th>Fecha efectiva</th>
                <th>Hora</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              ${
                requests.rows.length
                  ? requests.rows
                      .map(
                        (row) => `
                <tr>
                  <td>${escapeHtml(row.user_name)} · ${escapeHtml(row.user_email || "")}</td>
                  <td>${escapeHtml(row.med_name)}</td>
                  <td>${escapeHtml(row.current_dosage || "N/A")}</td>
                  <td>${escapeHtml(row.requested_dosage)}</td>
                  <td>${row.effective_date ? formatDateOnlyDisplay(row.effective_date) : "-"}</td>
                  <td>${escapeHtml(row.dose_time || "-")}</td>
                  <td>
                    <form method="POST" action="/admin/dose-requests/${row.id}/approve" style="display:inline;">
                      <button class="btn" type="submit">Aprobar</button>
                    </form>
                    <form method="POST" action="/admin/dose-requests/${row.id}/reject" style="display:inline; margin-left:6px;">
                      <button class="btn danger" type="submit">Rechazar</button>
                    </form>
                  </td>
                </tr>`
                      )
                      .join("")
                  : `<tr><td colspan="7">Sin solicitudes pendientes</td></tr>`
              }
            </tbody>
          </table>
        </div>
      </body>
    </html>
  `);
});

app.get("/admin/medical-records", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const userId = Number(req.query?.user_id || 0);
  const users = await pool.query(
    `SELECT id, name, email FROM users WHERE family_id = $1 ORDER BY name ASC`,
    [familyId]
  );
  const params = [familyId];
  let where = "WHERE family_id = $1";
  if (userId) {
    params.push(userId);
    where += ` AND user_id = $${params.length}`;
  }
  const records = await pool.query(
    `SELECT id, user_id, title, record_date, created_at
     FROM medical_records
     ${where}
     ORDER BY created_at DESC
     LIMIT 100`,
    params
  );
  res.send(`
    <!doctype html>
    <html lang="es">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Historial médico</title>
        <style>
          body { font-family: Inter, Arial, sans-serif; background:#f5f7fb; margin:0; padding:40px; }
          .card { max-width:980px; margin:0 auto; background:#fff; border-radius:20px; padding:24px; box-shadow:0 20px 40px -30px rgba(15,23,42,.4); margin-bottom:18px; }
          h1 { font-size:20px; margin:0 0 8px; }
          table { width:100%; border-collapse:collapse; margin-top:12px; }
          th, td { text-align:left; padding:10px 8px; font-size:13px; }
          tr + tr td { border-top:1px solid #e2e8f0; }
          .btn { display:inline-flex; align-items:center; justify-content:center; padding:8px 14px; border-radius:12px; text-decoration:none; font-weight:600; background:#2563eb; color:#fff; border:0; }
          .btn.secondary { background:#e2e8f0; color:#0f172a; }
          input, select { border:1px solid #e2e8f0; border-radius:12px; padding:8px 10px; }
          .row { display:flex; gap:10px; flex-wrap:wrap; }
          .note { font-size:12px; color:#64748b; margin-top:6px; }
        </style>
      </head>
      <body>
        <div class="card">
          <h1>Subir PDF médico</h1>
          <form method="POST" action="/admin/medical-records" enctype="multipart/form-data">
            <div class="row">
              <select name="user_id">
                ${
                  users.rows.length
                    ? users.rows
                        .map(
                          (u) =>
                            `<option value="${u.id}">${escapeHtml(u.name)} · ${escapeHtml(
                              u.email
                            )}</option>`
                        )
                        .join("")
                    : `<option value="">Sin usuarios</option>`
                }
              </select>
              <input name="title" placeholder="Título (ej. Análisis de sangre)" required />
              <input name="record_date" placeholder="Fecha (YYYY-MM-DD)" />
              <input name="file" type="file" accept="application/pdf" required />
              <button class="btn" type="submit">⬆ Guardar</button>
            </div>
            <p class="note">Solo PDF. Se guardará en el historial del paciente.</p>
          </form>
        </div>
        <div class="card">
          <h1>Historial médico</h1>
          <form method="GET" action="/admin/medical-records" class="row">
            <select name="user_id">
              <option value="">Todos los usuarios</option>
              ${
                users.rows.length
                  ? users.rows
                      .map(
                        (u) =>
                          `<option value="${u.id}" ${u.id === userId ? "selected" : ""}>${escapeHtml(
                            u.name
                          )} · ${escapeHtml(u.email)}</option>`
                      )
                      .join("")
                  : `<option value="">Sin usuarios</option>`
              }
            </select>
            <button class="btn secondary" type="submit">🔎 Filtrar</button>
            <a class="btn secondary" href="/dashboard">← Volver</a>
          </form>
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Paciente</th>
                <th>Título</th>
                <th>Fecha</th>
                <th>Creado</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              ${
                records.rows.length
                  ? records.rows
                      .map(
                        (row) => `
                <tr>
                  <td>${row.id}</td>
                  <td>${row.user_id}</td>
                  <td>${escapeHtml(row.title)}</td>
                  <td>${row.record_date ? formatDateOnlyDisplay(row.record_date) : "-"}</td>
                  <td>${formatDateTime(row.created_at)}</td>
                  <td><a class="btn secondary" href="/admin/medical-records/${row.id}/download">Descargar</a></td>
                </tr>`
                      )
                      .join("")
                  : `<tr><td colspan="6">Sin registros</td></tr>`
              }
            </tbody>
          </table>
        </div>
      </body>
    </html>
  `);
});

app.post(
  "/admin/medical-records",
  requireRoleHtml(["admin", "superuser"]),
  upload.single("file"),
  async (req, res) => {
    const familyId = req.user.family_id;
    const userId = Number(req.body?.user_id);
    const title = String(req.body?.title || "").trim();
    const recordDate = normalizeDateOnly(req.body?.record_date);
    if (!Number.isFinite(userId) || !title || !req.file?.path) {
      return res.redirect("/admin/medical-records");
    }
    const fileName = `${Date.now()}_${safeFilename(req.file.originalname)}`;
    const targetPath = path.join(medicalRecordsDir, fileName);
    try {
      fs.renameSync(req.file.path, targetPath);
    } catch {
      fs.copyFileSync(req.file.path, targetPath);
      fs.unlinkSync(req.file.path);
    }
    await pool.query(
      `INSERT INTO medical_records (family_id, user_id, title, record_date, file_path)
       VALUES ($1, $2, $3, $4, $5)`,
      [familyId, userId, title, recordDate || null, targetPath]
    );
    res.redirect("/admin/medical-records");
  }
);

app.get("/admin/medical-records/:id/download", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const recordId = Number(req.params.id);
  if (!Number.isFinite(recordId)) {
    return res.redirect("/admin/medical-records");
  }
  const record = await pool.query(
    `SELECT title, file_path
     FROM medical_records
     WHERE id = $1 AND family_id = $2`,
    [recordId, familyId]
  );
  if (!record.rows.length) {
    return res.redirect("/admin/medical-records");
  }
  const filePath = record.rows[0].file_path;
  res.download(filePath, safeFilename(`${record.rows[0].title}.pdf`));
});

app.post("/admin/dose-requests/:id/approve", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const requestId = Number(req.params.id);
  if (!Number.isFinite(requestId)) {
    return res.redirect("/admin/dose-requests");
  }
  const request = await pool.query(
    `SELECT id, medicine_id, requested_dosage
     FROM dose_change_requests
     WHERE id = $1 AND family_id = $2 AND status = 'pending'`,
    [requestId, familyId]
  );
  if (!request.rows.length) {
    return res.redirect("/admin/dose-requests");
  }
  const row = request.rows[0];
  await pool.query(`UPDATE medicines SET dosage = $1 WHERE id = $2`, [
    row.requested_dosage,
    row.medicine_id,
  ]);
  await pool.query(`UPDATE dose_change_requests SET status = 'approved' WHERE id = $1`, [
    requestId,
  ]);
  res.redirect("/admin/dose-requests");
});

app.post("/admin/dose-requests/:id/reject", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const requestId = Number(req.params.id);
  if (!Number.isFinite(requestId)) {
    return res.redirect("/admin/dose-requests");
  }
  await pool.query(
    `UPDATE dose_change_requests SET status = 'rejected'
     WHERE id = $1 AND family_id = $2 AND status = 'pending'`,
    [requestId, familyId]
  );
  res.redirect("/admin/dose-requests");
});

app.get("/admin/settings", requireRoleHtml(["admin", "superuser"]), (req, res) => {
  const emergency = req.query?.emergency === "1";
  res.send(`
    <!doctype html>
    <html lang="es">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Ajustes</title>
        <style>
          body { font-family: Inter, Arial, sans-serif; background:#f5f7fb; margin:0; padding:40px; }
          .card { max-width:900px; margin:0 auto; background:#fff; border-radius:20px; padding:24px; box-shadow:0 20px 40px -30px rgba(15,23,42,.4); }
          h1 { font-size:20px; margin:0 0 8px; }
          .note { font-size:13px; color:#64748b; margin-top:6px; }
          .btn { display:inline-flex; align-items:center; justify-content:center; padding:10px 16px; border-radius:12px; text-decoration:none; font-weight:600; background:#2563eb; color:#fff; }
          .btn.secondary { background:#e2e8f0; color:#0f172a; }
          .btn.disabled { background:#e5e7eb; color:#9ca3af; pointer-events:none; }
          label { display:flex; align-items:center; gap:10px; margin-top:12px; font-size:13px; color:#0f172a; }
        </style>
      </head>
      <body>
        <div class="card">
          <h1>Ajustes</h1>
          <p class="note">Opciones avanzadas desactivadas por defecto.</p>
          <form method="GET" action="/admin/settings">
            <label>
              <input type="checkbox" name="emergency" value="1" ${emergency ? "checked" : ""} />
              Habilitar modo emergencia (ver logs de borrado)
            </label>
            <button class="btn secondary" type="submit" style="margin-top:10px;">✅ Aplicar</button>
          </form>
          <p class="note">Por seguridad, los logs de borrado se muestran solo en emergencias.</p>
          <div style="margin-top:16px; display:flex; gap:10px;">
            <a class="btn ${emergency ? "" : "disabled"}" href="/admin/logs">📜 Mirar logs</a>
            <a class="btn secondary" href="/dashboard">← Volver</a>
          </div>
        </div>
      </body>
    </html>
  `);
});

app.get("/admin/logs", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const userId = Number(req.query?.user_id || 0);
  const from = String(req.query?.from || "").trim();
  const to = String(req.query?.to || "").trim();
  const users = await pool.query(
    `SELECT id, name, email FROM users WHERE family_id = $1 ORDER BY name ASC`,
    [familyId]
  );
  const params = [familyId];
  let where = "WHERE l.family_id = $1";
  if (userId) {
    params.push(userId);
    where += ` AND l.user_id = $${params.length}`;
  }
  if (from) {
    params.push(from);
    where += ` AND l.deleted_at >= $${params.length}::timestamptz`;
  }
  if (to) {
    params.push(to);
    where += ` AND l.deleted_at <= $${params.length}::timestamptz`;
  }
  const logs = await pool.query(
    `SELECT l.id, l.user_id, l.deleted_count, l.deleted_at, u.name AS user_name, u.email AS user_email
     FROM deletion_logs l
     LEFT JOIN users u ON u.id = l.user_id
     ${where}
     ORDER BY l.deleted_at DESC
     LIMIT 100`,
    params
  );
  res.send(`
    <!doctype html>
    <html lang="es">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Logs de borrado</title>
        <style>
          body { font-family: Inter, Arial, sans-serif; background:#f5f7fb; margin:0; padding:40px; }
          .card { max-width:980px; margin:0 auto; background:#fff; border-radius:20px; padding:24px; box-shadow:0 20px 40px -30px rgba(15,23,42,.4); }
          h1 { font-size:20px; margin:0 0 8px; }
          table { width:100%; border-collapse:collapse; margin-top:12px; }
          th, td { text-align:left; padding:10px 8px; font-size:13px; }
          tr + tr td { border-top:1px solid #e2e8f0; }
          .actions { margin-top:12px; display:flex; gap:10px; align-items:center; }
          .btn { display:inline-flex; align-items:center; justify-content:center; padding:8px 14px; border-radius:12px; text-decoration:none; font-weight:600; background:#2563eb; color:#fff; }
          .btn.secondary { background:#e2e8f0; color:#0f172a; }
          input, select { border:1px solid #e2e8f0; border-radius:12px; padding:8px 10px; }
        </style>
      </head>
      <body>
        <div class="card">
          <h1>Logs de borrado</h1>
          <form method="GET" action="/admin/logs" class="actions">
            <select name="user_id">
              <option value="">Todos los usuarios</option>
              ${
                users.rows
                  .map(
                    (u) =>
                      `<option value="${u.id}" ${u.id === userId ? "selected" : ""}>${escapeHtml(
                        u.name
                      )} · ${escapeHtml(u.email)}</option>`
                  )
                  .join("")
              }
            </select>
            <input name="from" placeholder="Desde (YYYY-MM-DD)" value="${escapeHtml(from)}" />
            <input name="to" placeholder="Hasta (YYYY-MM-DD)" value="${escapeHtml(to)}" />
            <button class="btn" type="submit">Buscar</button>
            <a class="btn secondary" href="/admin/settings?emergency=1">← Volver</a>
          </form>
          <p style="margin-top:10px; color:#64748b; font-size:12px;">
            Restaurar reemplaza la medicación actual del paciente por el snapshot.
          </p>
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Paciente</th>
                <th>Borrados</th>
                <th>Fecha</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              ${
                logs.rows.length
                  ? logs.rows
                      .map(
                        (row) => `
                <tr>
                  <td>${row.id}</td>
                  <td>${row.user_name ? `${escapeHtml(row.user_name)} · ${escapeHtml(row.user_email || "")}` : "-"}</td>
                  <td>${row.deleted_count}</td>
                  <td>${formatDateTime(row.deleted_at)}</td>
                  <td>
                    ${
                      row.user_id
                        ? `<form method="POST" action="/admin/logs/restore" style="margin:0;">
                             <input type="hidden" name="log_id" value="${row.id}" />
                             <button class="btn secondary" type="submit">Reimportar</button>
                           </form>`
                        : ""
                    }
                  </td>
                </tr>`
                      )
                      .join("")
                  : `<tr><td colspan="4">Sin logs</td></tr>`
              }
            </tbody>
          </table>
        </div>
      </body>
    </html>
  `);
});

app.post("/admin/logs/restore", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const logId = Number(req.body?.log_id);
  if (!Number.isFinite(logId)) {
    return res.redirect("/admin/logs");
  }
  const logResult = await pool.query(
    `SELECT id, user_id, snapshot
     FROM deletion_logs
     WHERE id = $1 AND family_id = $2`,
    [logId, familyId]
  );
  if (!logResult.rows.length || !logResult.rows[0].user_id) {
    return res.redirect("/admin/logs");
  }
  const userId = Number(logResult.rows[0].user_id);
  const snapshot = Array.isArray(logResult.rows[0].snapshot)
    ? logResult.rows[0].snapshot
    : [];
  await pool.query(
    `DELETE FROM dose_logs
     WHERE schedule_id IN (SELECT id FROM schedules WHERE user_id = $1)`,
    [userId]
  );
  await pool.query(`DELETE FROM schedules WHERE user_id = $1`, [userId]);
  await pool.query(`DELETE FROM medicines WHERE family_id = $1 AND user_id = $2`, [
    familyId,
    userId,
  ]);
  for (const med of snapshot) {
    await pool.query(
      `INSERT INTO medicines (family_id, user_id, name, dosage, current_stock, expiration_date, import_batch_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7)`,
      [
        familyId,
        userId,
        med.name || "Medicamento",
        med.dosage || "N/A",
        Number(med.current_stock || 0),
        med.expiration_date || null,
        med.import_batch_id || null,
      ]
    );
  }
  return res.redirect(`/admin/meds-list?reset=1&deleted=0&user_id=${userId}`);
});

app.post("/admin/alerts/clear", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const rawUserId = String(req.body?.user_id || "").trim();
  const userId = Number(rawUserId);
  if (rawUserId && Number.isFinite(userId) && userId > 0) {
    await pool.query(`DELETE FROM alerts WHERE family_id = $1 AND user_id = $2`, [
      familyId,
      userId,
    ]);
  } else {
    await pool.query(`DELETE FROM alerts WHERE family_id = $1`, [familyId]);
  }
  res.redirect("/admin/alerts");
});

app.get("/admin/reminders/run", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const now = new Date();
  const weekStart = new Date(now);
  weekStart.setDate(now.getDate() - ((now.getDay() + 6) % 7));
  weekStart.setHours(0, 0, 0, 0);
  const isoWeek = weekStart.toISOString().slice(0, 10);

  const existing = await pool.query(
    `SELECT id FROM weekly_reminders WHERE family_id = $1 AND week_start = $2::date`,
    [familyId, isoWeek]
  );
  if (existing.rows.length === 0) {
    await pool.query(
      `INSERT INTO weekly_reminders (family_id, week_start) VALUES ($1, $2::date)`,
      [familyId, isoWeek]
    );
    await pool.query(
      `INSERT INTO alerts (family_id, type, level, message, alert_date)
       VALUES ($1, 'weekly_review', 'info', $2, $3)`,
      [familyId, "Revisión semanal de stock y caducidades recomendada.", isoWeek]
    );
    await sendAdminAlertEmail(
      "Recordatorio semanal",
      "<p>Revisión semanal de stock y caducidades recomendada.</p>"
    );
  }
  res.redirect("/admin/alerts");
});

app.get("/admin/import", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const users = await pool.query(
    `SELECT id, name, email FROM users WHERE family_id = $1 ORDER BY name ASC`,
    [req.user.family_id]
  );
  const resetDeleted = Number(req.query?.deleted || 0);
  const showReset = req.query?.reset === "1";
  res.send(`
    <!doctype html>
    <html lang="es">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Importar medicamentos</title>
        <style>
          body { font-family: Inter, Arial, sans-serif; background:#f4f7fb; margin:0; color:#0f172a; }
          header { padding:28px 20px; background:linear-gradient(120deg,#0f172a 0%, #1d4ed8 60%, #14b8a6 100%); color:#fff; }
          header .wrap { max-width:820px; margin:0 auto; display:flex; align-items:center; justify-content:space-between; }
          header h1 { margin:0; font-size:20px; }
          header p { margin:6px 0 0; font-size:12px; opacity:.8; }
          .wrap { max-width:820px; margin:0 auto; padding:24px 20px 40px; }
          .card { background:#fff; border-radius:22px; padding:24px; box-shadow:0 24px 48px -30px rgba(15,23,42,.4); margin-bottom:18px; }
          h1 { font-size:20px; margin:0 0 8px; }
          label { display:block; font-size:13px; color:#64748b; margin-top:12px; }
          input { width:100%; border:1px solid #e2e8f0; border-radius:14px; padding:12px 14px; margin-top:6px; }
          button { width:100%; margin-top:18px; background:#2563eb; color:#fff; border:0; border-radius:14px; padding:12px 14px; font-weight:600; }
          a { color:#2563eb; text-decoration:none; font-size:13px; }
          .note { font-size:12px; color:#64748b; margin-top:8px; }
          .danger { background:#ef4444; }
          .row { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
        </style>
      </head>
      <body>
        <header>
          <div class="wrap">
            <div>
              <h1>Importación de medicamentos</h1>
              <p>Sube la receta y genera tomas automáticamente.</p>
            </div>
            <div>Familia #${req.user.family_id}</div>
          </div>
        </header>
        <div class="wrap">
          ${
            showReset
              ? `<div class="card" style="border:1px solid #e2e8f0;">
                   <h1>Reset completado</h1>
                   <p>Se borraron ${Number.isFinite(resetDeleted) ? resetDeleted : 0} medicamentos.</p>
                 </div>`
              : ""
          }
          <div class="card">
            <h1>Importar desde PDF</h1>
            <form method="POST" action="/admin/import" enctype="multipart/form-data">
              <label>Archivo PDF (desde tu PC)</label>
              <input name="file" type="file" accept=".pdf" />
              <label>Ruta del archivo (dentro del contenedor)</label>
              <input name="file_path" value="" />
              <div class="row">
                <div>
                  <label>Paciente</label>
                  <select name="user_id" style="width:100%; border:1px solid #e2e8f0; border-radius:14px; padding:12px 14px; margin-top:6px;">
                    ${
                      users.rows.length
                        ? users.rows
                            .map(
                              (u) =>
                                `<option value="${u.id}" ${
                                  u.id === req.user.sub ? "selected" : ""
                                }>${escapeHtml(u.name)} · ${escapeHtml(u.email)}</option>`
                            )
                            .join("")
                        : `<option value="">Sin usuarios</option>`
                    }
                  </select>
                </div>
                <div>
                  <label>Modo OCR</label>
                  <input name="use_ocr" type="checkbox" value="1" />
                </div>
                <div>
                  <label>Omitir verificación de nombre (solo test)</label>
                  <input name="skip_name_check" type="checkbox" value="1" />
                </div>
              </div>
              <button type="submit">⬆ Importar</button>
            </form>
            <p class="note">Los horarios se asignan a 08:00 / 14:00 / 20:00 / 22:00 según columnas Mo/Mi/Ab/Na.</p>
            <p class="note">Si subes archivo, la ruta interna no es necesaria.</p>
            <p class="note"><a href="/admin/import-scan">📷 Escanear desde foto (imagen)</a></p>
          </div>
          <div class="card">
            <h1>Reset de medicación</h1>
            <p class="note">Borra TODOS los medicamentos del paciente seleccionado. Esta acción es irreversible.</p>
            <form method="POST" action="/admin/meds-reset">
              <label>Paciente</label>
              <select name="user_id" style="width:100%; border:1px solid #e2e8f0; border-radius:14px; padding:12px 14px; margin-top:6px;">
                ${
                  users.rows.length
                    ? users.rows
                        .map(
                          (u) =>
                            `<option value="${u.id}" ${
                              u.id === req.user.sub ? "selected" : ""
                            }>${escapeHtml(u.name)} · ${escapeHtml(u.email)}</option>`
                        )
                        .join("")
                    : `<option value="">Sin usuarios</option>`
                }
              </select>
              <label>Escribe RESET para confirmar</label>
              <input name="confirm" placeholder="RESET" required />
              <button class="danger" type="submit">🧹 Borrar medicamentos</button>
            </form>
          </div>
          <div class="card">
            <h1>Reset global (toda la familia)</h1>
            <p class="note">Borra TODOS los medicamentos, schedules, tomas y alertas de la familia. Esta acción es irreversible.</p>
            <form method="POST" action="/admin/meds-reset-all">
              <label>Escribe RESET-TODO para confirmar</label>
              <input name="confirm" placeholder="RESET-TODO" required />
              <button class="danger" type="submit">🧹 Borrar todo</button>
            </form>
          </div>
          <p><a href="/dashboard">Volver</a></p>
        </div>
      </body>
    </html>
  `);
});

app.get("/admin/import-scan", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const users = await pool.query(
    `SELECT id, name, email FROM users WHERE family_id = $1 ORDER BY name ASC`,
    [req.user.family_id]
  );
  res.send(`
    <!doctype html>
    <html lang="es">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Escanear desde imagen</title>
        <style>
          body { font-family: Inter, Arial, sans-serif; background:#f4f7fb; margin:0; color:#0f172a; }
          header { padding:28px 20px; background:linear-gradient(120deg,#0f172a 0%, #1d4ed8 60%, #14b8a6 100%); color:#fff; }
          header .wrap { max-width:820px; margin:0 auto; display:flex; align-items:center; justify-content:space-between; }
          header h1 { margin:0; font-size:20px; }
          header p { margin:6px 0 0; font-size:12px; opacity:.8; }
          .wrap { max-width:820px; margin:0 auto; padding:24px 20px 40px; }
          .card { background:#fff; border-radius:22px; padding:24px; box-shadow:0 24px 48px -30px rgba(15,23,42,.4); margin-bottom:18px; }
          h1 { font-size:20px; margin:0 0 8px; }
          label { display:block; font-size:13px; color:#64748b; margin-top:12px; }
          input, select { width:100%; border:1px solid #e2e8f0; border-radius:14px; padding:12px 14px; margin-top:6px; }
          button { width:100%; margin-top:18px; background:#2563eb; color:#fff; border:0; border-radius:14px; padding:12px 14px; font-weight:600; }
          a { color:#2563eb; text-decoration:none; font-size:13px; }
          .note { font-size:12px; color:#64748b; margin-top:8px; }
          .row { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
        </style>
      </head>
      <body>
        <header>
          <div class="wrap">
            <div>
              <h1>Escanear desde imagen</h1>
              <p>Sube una foto o escaneo del medicamento.</p>
            </div>
            <div>Familia #${req.user.family_id}</div>
          </div>
        </header>
        <div class="wrap">
          <div class="card">
            <h1>Importar desde imagen</h1>
            <form method="POST" action="/admin/import-scan" enctype="multipart/form-data">
              <label>Imagen (JPG/PNG)</label>
              <input name="file" type="file" accept="image/*" />
              <label>Paciente</label>
              <select name="user_id">
                ${
                  users.rows.length
                    ? users.rows
                        .map(
                          (u) =>
                            `<option value="${u.id}" ${
                              u.id === req.user.sub ? "selected" : ""
                            }>${escapeHtml(u.name)} · ${escapeHtml(u.email)}</option>`
                        )
                        .join("")
                    : `<option value="">Sin usuarios</option>`
                }
              </select>
              <div class="row">
                <div>
                  <label>Fecha de nacimiento (DD.MM.AAAA)</label>
                  <input name="birth_date" placeholder="02.02.2026" />
                </div>
                <div>
                  <label>OCR rápido</label>
                  <input name="fast_ocr" type="checkbox" value="1" checked />
                </div>
                <div>
                  <label>Omitir verificación de nombre (solo test)</label>
                  <input name="skip_name_check" type="checkbox" value="1" />
                </div>
                <div>
                  <label>Solo previsualizar (no guardar)</label>
                  <input name="preview_only" type="checkbox" value="1" />
                </div>
              </div>
              <button type="submit">🧾 Procesar imagen</button>
            </form>
            <p class="note">Si falla el nombre, puedes probar con la fecha de nacimiento.</p>
          </div>
          <p><a href="/admin/import">← Volver</a></p>
        </div>
      </body>
    </html>
  `);
});

app.post(
  "/admin/import-scan",
  requireRoleHtml(["admin", "superuser"]),
  upload.single("file"),
  async (req, res) => {
    const familyId = req.user.family_id;
    const userId = Number(req.body?.user_id || req.user.sub);
    const skipNameCheck = req.body?.skip_name_check === "1";
    const previewOnly = req.body?.preview_only === "1";
    const fastOcr = req.body?.fast_ocr !== "0";
    const birthDate = normalizeDateOnly(req.body?.birth_date);
    if (!familyId || !Number.isFinite(userId) || !req.file?.path) {
      return res.redirect("/admin/import-scan");
    }
    try {
      const userResult = await pool.query(
        `SELECT id, name, first_name, last_name, birth_date FROM users WHERE id = $1 AND family_id = $2`,
        [userId, familyId]
      );
      const user = userResult.rows[0];
      const text = fastOcr
        ? await runOcrOnImage(req.file.path, { lang: "deu+eng", psm: "6", oem: "1" })
        : await runOcrOnImageBest(req.file.path);
      const rawLines = (text || "")
        .split(/\r?\n/)
        .map((line) => line.trim())
        .filter((line) => line.length > 2);
      const lines = filterOcrLines(rawLines);
      const detectedText = filterOcrLinesForDisplay(rawLines).join("\n").slice(0, 300);
      const nameCandidate = extractMedicineName(lines);
      const dosage = extractDosage(lines);
      const qtyMatch = text.match(/(\d+)\s*(Stk|Tbl|Kapsel|Caps|Pcs|ml)\b/i);
      const qty = qtyMatch ? Number(qtyMatch[1]) : 0;
      let validatedByBirthDate = false;
      if (!skipNameCheck && (!user || !patientNameMatches(text, user))) {
        if (birthDate && user?.birth_date) {
          validatedByBirthDate = normalizeDateOnly(user.birth_date) === birthDate;
        }
        if (!validatedByBirthDate) {
          return res.send(`
            <html lang="es"><body style="font-family:Inter,Arial,sans-serif; padding:24px;">
              <h2>Nombre del paciente no coincide</h2>
              <p>Texto detectado:</p>
              <pre>${escapeHtml(detectedText || "Sin texto")}</pre>
              <p><a href="/admin/import-scan">Volver</a></p>
            </body></html>
          `);
        }
      }
      let medResult = null;
      if (!previewOnly) {
        medResult = await upsertMedicineForUser({
          familyId,
          userId,
          name: nameCandidate,
          dosage,
          qty,
          expiryDate: null,
          batchId: null,
        });
      }
      return res.send(`
        <html lang="es"><body style="font-family:Inter,Arial,sans-serif; padding:24px;">
          <h2>${previewOnly ? "Previsualización" : "Importación completada"}</h2>
          <p><strong>Nombre:</strong> ${escapeHtml(nameCandidate)}</p>
          <p><strong>Dosis:</strong> ${escapeHtml(dosage)}</p>
          <p><strong>Cantidad:</strong> ${qty}</p>
          ${medResult ? `<p><strong>Acción:</strong> ${medResult.action}</p>` : ""}
          <p><strong>Texto detectado:</strong></p>
          <pre>${escapeHtml(detectedText || "Sin texto")}</pre>
          <p><a href="/admin/import-scan">Volver</a></p>
        </body></html>
      `);
    } catch (error) {
      return res.send(`
        <html lang="es"><body style="font-family:Inter,Arial,sans-serif; padding:24px;">
          <h2>Error al procesar</h2>
          <p>${escapeHtml(error.message)}</p>
          <p><a href="/admin/import-scan">Volver</a></p>
        </body></html>
      `);
    }
  }
);

app.post(
  "/admin/import",
  requireRoleHtml(["admin", "superuser"]),
  upload.single("file"),
  async (req, res) => {
  const familyId = req.user.family_id;
  const filePath = req.file?.path || req.body?.file_path;
  const userId = Number(req.body?.user_id || req.user.sub);
  const useOcr = req.body?.use_ocr === "1";
  const skipNameCheck = req.body?.skip_name_check === "1";
  if (!filePath || !userId) {
    return res.redirect("/admin/import");
  }
  try {
    const result = await importMedsFromPdf(
      filePath,
      familyId,
      userId,
      useOcr,
      skipNameCheck
    );
    res.send(`
      <!doctype html>
      <html lang="es">
        <head>
          <meta charset="utf-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1" />
          <title>Importación completa</title>
          <style>
            body { font-family: Inter, Arial, sans-serif; background:#f4f7fb; margin:0; color:#0f172a; }
            .wrap { max-width:720px; margin:0 auto; padding:40px 20px; }
            .card { background:#fff; border-radius:22px; padding:24px; box-shadow:0 24px 48px -30px rgba(15,23,42,.4); }
            a { color:#2563eb; text-decoration:none; font-size:13px; }
            .pill { display:inline-block; background:#111827; color:#fff; padding:6px 12px; border-radius:999px; font-size:12px; }
          </style>
        </head>
        <body>
          <div class="wrap">
            <div class="card">
              <h1>Importación completa</h1>
              <p><span class="pill">${result.inserted} medicamentos</span></p>
              <p>Advertencias: ${result.warnings}</p>
              <p><a href="/admin/meds-list?review=1">Revisar posibles errores</a></p>
              <p><a href="/dashboard">Volver</a></p>
            </div>
          </div>
        </body>
      </html>
    `);
  } catch (error) {
    res.send(`
      <!doctype html>
      <html lang="es">
        <head>
          <meta charset="utf-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1" />
          <title>Error importación</title>
          <style>
            body { font-family: Inter, Arial, sans-serif; background:#f4f7fb; margin:0; color:#0f172a; }
            .wrap { max-width:720px; margin:0 auto; padding:40px 20px; }
            .card { background:#fff; border-radius:22px; padding:24px; box-shadow:0 24px 48px -30px rgba(15,23,42,.4); }
            a { color:#2563eb; text-decoration:none; font-size:13px; }
          </style>
        </head>
        <body>
          <div class="wrap">
            <div class="card">
              <h1>Error al importar</h1>
              <p>${escapeHtml(error.message)}</p>
              <p><a href="/admin/import">Volver</a></p>
            </div>
          </div>
        </body>
      </html>
    `);
  }
});

app.post(
  "/api/import-scan-validate",
  requireRole(["admin", "superuser", "user"]),
  upload.single("file"),
  async (req, res) => {
    const familyId = getFamilyId(req);
    const userId = Number(req.body?.user_id);
    const skipNameCheck = req.body?.skip_name_check === "1";
    const debugOcr = req.body?.debug_ocr === "1";
    const fastOcr = req.body?.fast_ocr !== "0";
    const birthDate = normalizeDateOnly(req.body?.birth_date);
    if (!familyId || !Number.isFinite(userId) || !req.file?.path) {
      return res.status(400).json({ error: "family_id, user_id y file son requeridos" });
    }
    try {
      if (skipNameCheck) {
        return res.json({ ok: true, match: true });
      }
      const userResult = await pool.query(
        `SELECT id, name, first_name, last_name, birth_date FROM users WHERE id = $1 AND family_id = $2`,
        [userId, familyId]
      );
      const user = userResult.rows[0];
      const text = fastOcr
        ? await runOcrOnImage(req.file.path, { lang: "deu+eng", psm: "6", oem: "1" })
        : await runOcrOnImageBest(req.file.path);
      const rawLines = (text || "")
        .split(/\r?\n/)
        .map((line) => line.trim())
        .filter((line) => line.length > 2);
      const filteredLines = filterOcrLinesForDisplay(rawLines);
      const detectedText = filteredLines.join("\n").slice(0, 300);
      let match = !!user && patientNameMatches(text, user);
      let validatedByBirthDate = false;
      if (!match && birthDate && user?.birth_date) {
        validatedByBirthDate =
          normalizeDateOnly(user.birth_date) === birthDate;
        if (validatedByBirthDate) match = true;
      }
      return res.json({
        ok: true,
        match,
        validated_by_birth_date: validatedByBirthDate,
        detected_text: detectedText,
        detected_text_full: debugOcr ? text || "" : undefined,
      });
    } catch (error) {
      return res.status(500).json({ error: error.message });
    }
  }
);

app.post(
  "/api/import-scan",
  requireRole(["admin", "superuser", "user"]),
  upload.single("file"),
  async (req, res) => {
    const familyId = getFamilyId(req);
    const userId = Number(req.body?.user_id);
    const skipNameCheck = req.body?.skip_name_check === "1";
    const fastImport = req.body?.fast_import === "1";
    const fastImportOcr = req.body?.fast_import_ocr === "1";
    const debugOcr = req.body?.debug_ocr === "1";
    const fastOcr = req.body?.fast_ocr !== "0";
    const birthDate = normalizeDateOnly(req.body?.birth_date);
    if (!familyId || !Number.isFinite(userId) || !req.file?.path) {
      return res.status(400).json({ error: "family_id, user_id y file son requeridos" });
    }
    try {
      if (fastImport && !fastImportOcr && !debugOcr) {
        const medResult = await upsertMedicineForUser({
          familyId,
          userId,
          name: "Medicamento escaneado",
          dosage: "N/A",
          qty: 0,
          expiryDate: null,
          batchId: null,
        });
        await ensureDefaultScheduleForMedicine({
          familyId,
          userId,
          medicineId: medResult.id,
        });
        return res.json({
          ok: true,
          action: medResult.action,
          medicine_id: medResult.id,
          extracted: { name: "Medicamento escaneado", dosage: "N/A", qty: 0 },
        });
      }
      const userResult = await pool.query(
        `SELECT id, name, first_name, last_name, birth_date FROM users WHERE id = $1 AND family_id = $2`,
        [userId, familyId]
      );
      const user = userResult.rows[0];
      const text = fastOcr
        ? await runOcrOnImage(req.file.path, { lang: "deu+eng", psm: "6", oem: "1" })
        : await runOcrOnImageBest(req.file.path);
      const rawLines = text
        .split(/\r?\n/)
        .map((line) => line.trim())
        .filter((line) => line.length > 2);
      const lines = filterOcrLines(rawLines);
      const detectedText = filterOcrLinesForDisplay(rawLines).join("\n").slice(0, 300);
      const nameCandidate = extractMedicineName(lines);
      const dosage = extractDosage(lines);
      const qtyMatch = text.match(/(\d+)\s*(Stk|Tbl|Kapsel|Caps|Pcs|ml)\b/i);
      const qty = qtyMatch ? Number(qtyMatch[1]) : 0;
      if (fastImport) {
        const medResult = await upsertMedicineForUser({
          familyId,
          userId,
          name: nameCandidate,
          dosage,
          qty,
          expiryDate: null,
          batchId: null,
        });
        await ensureDefaultScheduleForMedicine({
          familyId,
          userId,
          medicineId: medResult.id,
        });
        return res.json({
          ok: true,
          action: medResult.action,
          medicine_id: medResult.id,
          extracted: { name: nameCandidate, dosage, qty },
          detected_text_full: debugOcr ? text || "" : undefined,
        });
      }
      let validatedByBirthDate = false;
      if (!skipNameCheck && (!user || !patientNameMatches(text, user))) {
        if (birthDate && user?.birth_date) {
          validatedByBirthDate =
            normalizeDateOnly(user.birth_date) === birthDate;
        }
        if (!validatedByBirthDate) {
          return res.status(400).json({
            error: "Nombre de paciente no coincide o no se encontró en la etiqueta.",
            detected_text: detectedText,
            detected_text_full: debugOcr ? text || "" : undefined,
          });
        }
      }
      const nameLine = nameCandidate;

      const medResult = await upsertMedicineForUser({
        familyId,
        userId,
        name: nameLine,
        dosage,
        qty,
        expiryDate: null,
        batchId: null,
      });
      await ensureDefaultScheduleForMedicine({
        familyId,
        userId,
        medicineId: medResult.id,
      });

      res.json({
        ok: true,
        action: medResult.action,
        medicine_id: medResult.id,
        extracted: { name: nameLine, dosage, qty },
        validated_by_birth_date: validatedByBirthDate,
        detected_text_full: debugOcr ? text || "" : undefined,
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
);

app.post("/admin/meds-reset", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const userId = Number(req.body?.user_id);
  const confirm = String(req.body?.confirm || "").trim();
  if (confirm !== "RESET") {
    return res.redirect("/admin/import");
  }
  if (!Number.isFinite(userId)) {
    return res.redirect("/admin/import");
  }
  const snapshotResult = await pool.query(
    `SELECT id, name, dosage, current_stock, expiration_date, import_batch_id
     FROM medicines
     WHERE family_id = $1 AND user_id = $2
     ORDER BY id`,
    [familyId, userId]
  );
  const snapshot = snapshotResult.rows || [];
  await pool.query(
    `DELETE FROM dose_logs
     WHERE schedule_id IN (SELECT id FROM schedules WHERE user_id = $1)`,
    [userId]
  );
  await pool.query(`DELETE FROM schedules WHERE user_id = $1`, [userId]);
  const result = await pool.query(`DELETE FROM medicines WHERE family_id = $1 AND user_id = $2`, [
    familyId,
    userId,
  ]);
  await pool.query(
    `INSERT INTO deletion_logs (family_id, user_id, deleted_count, snapshot)
     VALUES ($1, $2, $3, $4)`,
    [familyId, userId, result.rowCount || 0, JSON.stringify(snapshot)]
  );
  await pool.query(`DELETE FROM alerts WHERE family_id = $1 AND user_id = $2`, [
    familyId,
    userId,
  ]);
  res.redirect(
    `/admin/meds-list?reset=1&deleted=${result.rowCount || 0}&user_id=${userId}`
  );
});

app.post("/admin/meds-reset-all", requireRoleHtml(["admin", "superuser"]), async (req, res) => {
  const familyId = req.user.family_id;
  const confirm = String(req.body?.confirm || "").trim();
  if (confirm !== "RESET-TODO") {
    return res.redirect("/admin/import");
  }
  const snapshotResult = await pool.query(
    `SELECT id, user_id, name, dosage, current_stock, expiration_date, import_batch_id
     FROM medicines
     WHERE family_id = $1
     ORDER BY id`,
    [familyId]
  );
  const snapshot = snapshotResult.rows || [];
  const deletedCount = snapshot.length;
  await pool.query(
    `DELETE FROM dose_logs
     WHERE schedule_id IN (
       SELECT id FROM schedules WHERE user_id IN (SELECT id FROM users WHERE family_id = $1)
     )`,
    [familyId]
  );
  await pool.query(`DELETE FROM schedules WHERE user_id IN (SELECT id FROM users WHERE family_id = $1)`, [
    familyId,
  ]);
  await pool.query(`DELETE FROM medicines WHERE family_id = $1`, [familyId]);
  await pool.query(
    `INSERT INTO deletion_logs (family_id, user_id, deleted_count, snapshot)
     VALUES ($1, NULL, $2, $3)`,
    [familyId, deletedCount, JSON.stringify(snapshot)]
  );
  await pool.query(`DELETE FROM alerts WHERE family_id = $1`, [familyId]);
  res.redirect(`/admin/meds-list?reset=1&deleted=${deletedCount}`);
});

const port = Number(process.env.PORT || 4000);
app.listen(port, "0.0.0.0", () => {
  console.log(`Backend escuchando en puerto ${port}`);
});

// Job automático de alertas (cada 5 minutos, modo test)
setInterval(runAlertsJob, 5 * 60 * 1000);
